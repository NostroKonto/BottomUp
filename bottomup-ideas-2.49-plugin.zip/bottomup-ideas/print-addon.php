<?php
/**
 * Compatibility loader.
 * The print addon implementation lives in /includes/print-addon.php.
 */
if (!defined('ABSPATH')) { exit; }
require_once plugin_dir_path(__FILE__) . 'includes/print-addon.php';
