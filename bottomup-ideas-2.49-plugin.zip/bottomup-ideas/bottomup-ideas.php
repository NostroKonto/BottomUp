<?php
/**
 * Plugin Name: Bottom Up Ideas
 * Description: Backend-only Ideenmanagement mit SK-Bewertung (Tabs + Gänseblümchen) und Ideenliste mit Filtern & Pagination.
 * Version: 2.49
 * Author: ChatGPT
 */
if (!defined('ABSPATH')) exit;

if(!defined('BU_IDEAS_VERSION')) define('BU_IDEAS_VERSION', '2.49');
if(!defined('BU_IDEAS_FILE')) define('BU_IDEAS_FILE', __FILE__);
if(!defined('BU_IDEAS_DIR')) define('BU_IDEAS_DIR', plugin_dir_path(__FILE__));

require_once BU_IDEAS_DIR . 'includes/print-addon.php';

// Traits (Module)
require_once BU_IDEAS_DIR . 'includes/traits/trait-bu-ideas-votes.php';
require_once BU_IDEAS_DIR . 'includes/traits/trait-bu-ideas-versions.php';
require_once BU_IDEAS_DIR . 'includes/traits/trait-bu-ideas-tasks.php';
require_once BU_IDEAS_DIR . 'includes/traits/trait-bu-ideas-print.php';
require_once BU_IDEAS_DIR . 'includes/traits/trait-bu-ideas-export.php';
require_once BU_IDEAS_DIR . 'includes/traits/trait-bu-ideas-pm.php';
require_once BU_IDEAS_DIR . 'includes/traits/trait-bu-ideas-kiosk.php';

// Core class
require_once BU_IDEAS_DIR . 'includes/class-bu-ideas.php';

// Extra admin hooks / helpers
require_once BU_IDEAS_DIR . 'includes/admin-extras.php';


// Cron setup/cleanup (favorite deadline checks)
register_activation_hook(__FILE__, function(){
    if (class_exists('BU_Ideas')){
        BU_Ideas::ensure_deadline_cron();
    }
});
register_deactivation_hook(__FILE__, function(){
    if (function_exists('wp_clear_scheduled_hook')){
        wp_clear_scheduled_hook('bu_check_favorite_deadlines');
    }
});

BU_Ideas::init();