<?php
if (!defined('ABSPATH')) exit;

if (!class_exists('BU_Ideas_Print_Integrated')) :
final class BU_Ideas_Print_Integrated {

    const CPT = 'bu_idea';

    public static function init(){
        add_action('admin_menu', array(__CLASS__,'menu'));
        add_filter('post_row_actions', array(__CLASS__,'row_actions_icons'), 20, 2);
        add_action('edit_form_top', array(__CLASS__,'edit_top_print_button'));
        add_action('admin_notices', array(__CLASS__,'view_print_notice'));
        add_action('admin_notices', array(__CLASS__,'view_stats_panel'));
        add_action('admin_enqueue_scripts', array(__CLASS__,'enqueue'));
        // add_action('add_meta_boxes', array(__CLASS__,'add_level_metabox')); // disabled duplicate Ebene metabox
        // add_action('save_post', array(__CLASS__,'save_level_metabox')); // disabled with metabox
    }

    public static function menu(){
        add_submenu_page(null,'Druckansicht','Druckansicht','edit_posts','bottomup_print',array(__CLASS__,'render_print'));
    }

    public static function enqueue($hook){
        $base = plugin_dir_url(dirname(__FILE__)); // plugin root URL
        if (isset($_GET['page']) && $_GET['page']==='bottomup_print') {
            wp_enqueue_style('bui-print', $base . 'assets/css/print.css', array(), '1.0.8');
        }
        $is_native_list = ($hook==='edit.php' && isset($_GET['post_type']) && $_GET['post_type']===self::CPT);
        $is_custom = (isset($_GET['page']) && in_array($_GET['page'], array('bottomup_ideas','bottomup_view','bottomup_dashboard'), true));
        if ($is_native_list || $is_custom) {
            wp_enqueue_style('dashicons');
            wp_enqueue_style('bui-icons', $base . 'assets/css/admin-icons.css', array('dashicons'), '1.0.8');
            wp_enqueue_script('bui-icons', $base . 'assets/js/icons.js', array('jquery'), '1.0.8', true);
        }
    }

    public static function row_actions_icons($actions, $post){
        if (!is_object($post) || empty($post->post_type) || $post->post_type !== self::CPT) return $actions;
        $view_admin = add_query_arg(array('page'=>'bottomup_view','post'=>$post->ID), admin_url('admin.php'));
        $actions['view'] = '<a class="bui-icon-link" href="'.esc_url($view_admin).'"><span class="dashicons dashicons-visibility"></span><span class="screen-reader-text">'.esc_html__('Ansehen','bottomup-ideas').'</span></a>';
        if (isset($actions['edit'])) {
            $edit_url = get_edit_post_link($post->ID, '');
            $actions['edit'] = '<a class="bui-icon-link" href="'.esc_url($edit_url).'"><span class="dashicons dashicons-edit"></span><span class="screen-reader-text">'.esc_html__('Bearbeiten','bottomup-ideas').'</span></a>';
        }
        $print_url = add_query_arg(array('action'=>'bottomup_print_idea','post'=>$post->ID), admin_url('admin-post.php'));
        $actions['bui_print'] = '<a class="bui-icon-link" href="'.esc_url($print_url).'"><span class="dashicons dashicons-media-document"></span><span class="screen-reader-text">'.esc_html__('Drucken','bottomup-ideas').'</span></a>';
        return $actions;
    }

    public static function edit_top_print_button($post){
        if ($post->post_type !== self::CPT) return;
        $url = add_query_arg(array('action'=>'bottomup_print_idea','post'=>$post->ID), admin_url('admin-post.php'));
        echo '<div class="bui-print-top" style="margin:10px 0"><a class="button" href="'.esc_url($url).'">🖨 Drucken</a></div>';
    }

    public static function view_print_notice(){
        if (!current_user_can('edit_posts')) return;
        if (!isset($_GET['page']) || $_GET['page']!=='bottomup_view') return;
        $pid = isset($_GET['post']) ? intval($_GET['post']) : 0;
        if (!$pid) return;
        $args_print = array('action'=>'bottomup_print_idea','post'=>$pid);
        if (isset($_GET['ret'])) {
            $args_print['ret'] = sanitize_text_field(wp_unslash($_GET['ret']));
        }
        $url_print = add_query_arg($args_print, admin_url('admin-post.php'));
        if (class_exists('BU_Ideas') && method_exists('BU_Ideas','get_back_url')) {
            $url_list = BU_Ideas::get_back_url();
        } else {
            $url_list  = admin_url('admin.php?page=bottomup_ideas');
        }
        $url_edit  = get_edit_post_link($pid, '');
        echo '<div class="notice notice-info bui-print-hide" style="display:flex;align-items:center;gap:8px;">';
        echo '<strong>Aktionen:</strong> ';
        echo '<a class="button" href="'.esc_url($url_list).'">← Zurück zur Liste</a>';
        echo '<a class="button" href="'.esc_url($url_print).'">🖨 Drucken</a>';
        echo '<a class="button button-primary" href="'.esc_url($url_edit).'">Bearbeiten</a>';
        echo '</div>';
        echo '<style>
@media print {
  /* hide WP admin chrome */
  #wpadminbar, #adminmenumain, #adminmenuwrap, #wpfooter, #screen-meta, #screen-meta-links, .notice, .update-nag { display:none !important; }
  #wpcontent, #wpbody, #wpbody-content { margin:0 !important; padding:0 !important; }
  body.wp-admin { background:#fff !important; }
  .wrap { margin:0 !important; }
  .bui-print-hide{display:none!important}
}
</style>';
    }

    public static function view_stats_panel(){
        if (!isset($_GET['page']) || $_GET['page']!=='bottomup_view') return;
        $pid = isset($_GET['post']) ? intval($_GET['post']) : 0;
        if (!$pid) return;
        $avg  = self::calc_avg_sk($pid);
        if (is_null($avg)) { $avg = self::avg_from_postmeta($pid, array('bu_sk_avg','_bu_sk_avg','bu_sk_scores','_bu_sk_scores','sk_avg','_sk_avg')); }
        $cnts = self::count_votes($pid);
        if ($cnts['yes']===0 && $cnts['no']===0) {
            $cnts = self::votes_from_postmeta($pid, array('bu_votes_yes','_bu_votes_yes','votes_yes','_votes_yes'), array('bu_votes_no','_bu_votes_no','votes_no','_votes_no'));
        }
        // Kategorie & Ebene für die Leseansicht mit anzeigen
        if (class_exists('BU_Ideas')) {
            $cats = wp_get_post_terms($pid, BU_Ideas::TAX_CAT, array('fields'=>'names'));
            $lvls = wp_get_post_terms($pid, BU_Ideas::TAX_LVL, array('fields'=>'names'));
        } else {
            $cats = $lvls = array();
        }
        echo '<div class="notice notice-info bui-print-hide" style="display:flex;flex-wrap:wrap;gap:16px;align-items:center">';
        echo '<strong>SK-Ø:</strong> '.(is_null($avg)?'–':esc_html(number_format($avg,2,',','.')));
        echo '<span style="margin-left:12px"><strong>Ja/Nein:</strong> '.intval($cnts['yes']).' / '.intval($cnts['no']).'</span>';
        if (!empty($cats)) {
            echo '<span style="margin-left:12px"><strong>Kategorie:</strong> '.esc_html(implode(', ', $cats)).'</span>';
        }
        if (!empty($lvls)) {
            echo '<span style="margin-left:12px"><strong>Ebene:</strong> '.esc_html(implode(', ', $lvls)).'</span>';
        }
        echo '</div>';
    }

    public static function render_print(){
        if (!current_user_can('edit_posts')) wp_die(__('Keine Berechtigung.','bottomup-ideas'));
        $pid = isset($_GET['post']) ? intval($_GET['post']) : 0;
        if (!$pid) { echo '<div class="wrap"><h1>Fehler</h1><p>Kein Beitrag angegeben.</p></div>'; return; }
        $url = add_query_arg(array('action'=>'bottomup_print_idea','post'=>$pid), admin_url('admin-post.php'));
        wp_safe_redirect($url);
        exit;

        $p = get_post($pid);
        if (!$p || $p->post_type !== self::CPT) { echo '<div class="wrap"><h1>Fehler</h1><p>Beitrag nicht gefunden.</p></div>'; return; }

        $sum = self::first_nonempty_meta($pid, array('bu_summary','_bu_summary','bu_summary_text','_bu_summary_text','summary'));
        if ($sum === '') { $sum = get_the_excerpt($pid); }

        $pro = self::first_list($pid, array(
            array('bu_pro_1','bu_pro_2','bu_pro_3'),
            array('_bu_pro_1','_bu_pro_2','_bu_pro_3'),
            array('pro_1','pro_2','pro_3'),
            array('pro1','pro2','pro3'),
            array('bu_pros'), array('_bu_pros')
        ), 3);

        $con = self::first_list($pid, array(
            array('bu_con_1','bu_con_2','bu_con_3'),
            array('_bu_con_1','_bu_con_2','_bu_con_3'),
            array('con_1','con_2','con_3'),
            array('con1','con2','con3'),
            array('bu_cons'), array('_bu_cons')
        ), 3);

        $avg  = self::calc_avg_sk($pid);
        if (is_null($avg)) { $avg = self::avg_from_postmeta($pid, array('bu_sk_avg','_bu_sk_avg','bu_sk_scores','_bu_sk_scores')); }

        $cnts = self::count_votes($pid);
        if ($cnts['yes']===0 && $cnts['no']===0) {
            $cnts = self::votes_from_postmeta($pid, array('bu_votes_yes','_bu_votes_yes'), array('bu_votes_no','_bu_votes_no'));
        }

        $date = substr($p->post_date, 0, 10);

        echo '<div class="wrap bui-print-root">';
        $pdf_title = $pid . ' - ' . get_the_title($pid);
        echo '<h1>'.esc_html(get_the_title($pid)).'</h1>';
        echo '<script>document.title = ' . wp_json_encode($pdf_title) . ';</script>';
        echo '<p class="bui-controls bui-print-hide" style="margin-bottom:12px">';
        if (class_exists('BU_Ideas') && method_exists('BU_Ideas','get_back_url')) {
            $back_url = BU_Ideas::get_back_url();
        } else {
            $back_url = admin_url('admin.php?page=bottomup_ideas');
        }
        echo '<a class="button" href="'.esc_url($back_url).'">← Zurück zur Liste</a> ';
        echo '<button class="button" onclick="window.print()">Drucken</button> ';
        echo '<a class="button button-primary" href="'.esc_url(get_edit_post_link($pid,'')).'">Bearbeiten</a>';
        echo '</p>';

        ?>
        <div class="bui-print-card">
          <p class="meta">Erstelldatum: <?php echo esc_html($date); ?></p>

          <div class="grid">
            <div class="box">
              <h3>Zusammenfassung</h3>
              <div><?php echo nl2br(esc_html($sum)); ?></div>
            </div>

            <div class="box">
              <h3>SK-Wert & Abstimmung</h3>
              <div>
                SK-Wert (Ø): <?php echo is_null($avg) ? '–' : esc_html(number_format($avg,2,',','.')); ?><br/>
                Ja: <?php echo intval($cnts['yes']); ?> / Nein: <?php echo intval($cnts['no']); ?>
              </div>
            </div>

            <div class="box">
              <h3>Vorteile</h3>
              <ul>
                <li><?php echo esc_html($pro[0]); ?></li>
                <li><?php echo esc_html($pro[1]); ?></li>
                <li><?php echo esc_html($pro[2]); ?></li>
              </ul>
            </div>

            <div class="box">
              <h3>Nachteile</h3>
              <ul>
                <li><?php echo esc_html($con[0]); ?></li>
                <li><?php echo esc_html($con[1]); ?></li>
                <li><?php echo esc_html($con[2]); ?></li>
              </ul>
            </div>
          </div>
        </div>
        <?php
        echo '</div>';
    }

    private static function first_nonempty_meta($post_id, $keys){
        foreach ($keys as $k){
            $v = get_post_meta($post_id, $k, true);
            if (is_string($v)) { $v = trim($v); }
            if (!empty($v)) return $v;
        }
        return '';
    }

    private static function first_list($post_id, $key_groups, $len){
        foreach ($key_groups as $group){
            if (count($group)===$len && is_string($group[0]) && !in_array('bu_pros',$group,true) && !in_array('bu_cons',$group,true)){
                $vals = array();
                foreach ($group as $k){
                    $v = get_post_meta($post_id, $k, true);
                    if (is_string($v)) $v = trim($v);
                    $vals[] = $v;
                }
                if (implode('', $vals) !== '') return $vals;
            }
        }
        foreach ($key_groups as $group){
            foreach ($group as $k){
                $raw = get_post_meta($post_id, $k, true);
                if (!$raw) continue;
                if (is_string($raw)) {
                    $t = trim($raw);
                    if (preg_match('/^\[.*\]$/', $t)) {
                        $arr = json_decode($t, true);
                        if (is_array($arr) && !empty($arr)) {
                            $arr = array_values(array_map('strval', $arr));
                            while (count($arr)<$len) $arr[]='';
                            return array_slice($arr,0,$len);
                        }
                    } else {
                        $parts = array_map('trim', explode(',', $t));
                        if (count($parts)>=1) {
                            while (count($parts)<$len) $parts[]='';
                            return array_slice($parts,0,$len);
                        }
                    }
                } elseif (is_array($raw)) {
                    $arr = array_values($raw);
                    while (count($arr)<$len) $arr[]='';
                    return array_slice($arr,0,$len);
                }
            }
        }
        return array('','','');
    }

    private static function calc_avg_sk($post_id){
        global $wpdb;
        $rows = $wpdb->get_col( $wpdb->prepare(
            "SELECT um.meta_value FROM {$wpdb->usermeta} um WHERE um.meta_key = %s OR um.meta_key LIKE %s",
            'bu_sk_'.$post_id, $wpdb->esc_like('bu_sk_'.$post_id)
        ));
        $vals = array();
        foreach ((array)$rows as $v) {
            if ($v !== '' && $v !== null) $vals[] = floatval($v);
        }
        if (!$vals) return null;
        return array_sum($vals)/count($vals);
    }

    private static function avg_from_postmeta($post_id, $keys){
        foreach ($keys as $k){
            $v = get_post_meta($post_id, $k, true);
            if ($v === '' || $v === null) continue;
            if (is_numeric($v)) return floatval($v);
            if (is_string($v)) {
                $vtrim = trim($v);
                if (preg_match('/^\[.*\]$/', $vtrim)) {
                    $arr = json_decode($vtrim, true);
                    if (is_array($arr) && !empty($arr)) {
                        $nums = array();
                        foreach ($arr as $n) if (is_numeric($n)) $nums[] = floatval($n);
                        if ($nums) return array_sum($nums)/count($nums);
                    }
                } else {
                    $parts = array_map('trim', explode(',', $vtrim));
                    $nums = array();
                    foreach ($parts as $p) if ($p !== '' && is_numeric($p)) $nums[] = floatval($p);
                    if ($nums) return array_sum($nums)/count($nums);
                }
            }
        }
        return null;
    }

    private static function count_votes($post_id){
        global $wpdb;
        $yes = $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key=%s AND meta_value='yes'",
            'bu_yn_'.$post_id
        ));
        $no  = $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key=%s AND meta_value='no'",
            'bu_yn_'.$post_id
        ));
        return array('yes'=>intval($yes), 'no'=>intval($no));
    }

    private static function votes_from_postmeta($post_id, $yes_keys, $no_keys){
        $yes = 0; $no = 0;
        foreach ($yes_keys as $k){
            $v = get_post_meta($post_id, $k, true);
            if (is_numeric($v)) { $yes = max($yes, intval($v)); }
        }
        foreach ($no_keys as $k){
            $v = get_post_meta($post_id, $k, true);
            if (is_numeric($v)) { $no = max($no, intval($v)); }
        }
        return array('yes'=>$yes, 'no'=>$no);
    }

    // ---- Level Metabox (side) ----
    public static function add_level_metabox(){
        add_meta_box('bu_level_side','Ebene','BU_Ideas_Print_Integrated::level_meta_box','bu_idea','side','high');
    }
    public static function level_meta_box($post){
        $val = get_post_meta($post->ID, 'bu_level', true);
        if (!$val && taxonomy_exists('bu_level')){
            $terms = wp_get_post_terms($post->ID, 'bu_level', array('fields'=>'slugs'));
            if (is_array($terms) && !empty($terms)) $val = $terms[0];
        }
        $opts = array('national'=>'National','kanton'=>'Kanton','stadt'=>'Stadt','lokal'=>'Lokal');
        echo '<p><select name="bu_level_side" id="bu_level_side" style="width:100%">';
        foreach($opts as $slug=>$label){
            $sel = selected($val,$slug,false);
            echo '<option value="'.esc_attr($slug).'" '.$sel.'>'.esc_html($label).'</option>';
        }
        echo '</select></p>';
        wp_nonce_field('bu_level_side_save','bu_level_side_nonce');
    }
    public static function save_level_metabox($post_id){
        if (!isset($_POST['bu_level_side_nonce']) || !wp_verify_nonce($_POST['bu_level_side_nonce'],'bu_level_side_save')) return;
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (!current_user_can('edit_post', $post_id)) return;
        if (!isset($_POST['bu_level_side'])) return;
        $val = sanitize_text_field($_POST['bu_level_side']);
        update_post_meta($post_id, 'bu_level', $val);
        if (taxonomy_exists('bu_level')){
            wp_set_object_terms($post_id, $val, 'bu_level', false);
        }
    }
}
BU_Ideas_Print_Integrated::init();
endif;
