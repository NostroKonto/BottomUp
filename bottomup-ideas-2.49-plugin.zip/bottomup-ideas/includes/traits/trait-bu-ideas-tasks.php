<?php
if (!defined('ABSPATH')) exit;

trait BU_Ideas_Tasks_Trait {
    /*** Tasks (Trello-ähnlich) ***/
    public static function render_tasks_overview(){
        if (!current_user_can('read')) wp_die('Keine Berechtigung.');
        $lvl = isset($_GET['level']) ? sanitize_text_field($_GET['level']) : '';
        $fav_on = (isset($_GET['fav']) && $_GET['fav']=='1');
        $arch_on = (isset($_GET['arch']) && $_GET['arch']=='1');
        $cat = isset($_GET['cat']) ? sanitize_text_field($_GET['cat']) : '';
        $act = isset($_GET['act']) ? sanitize_text_field($_GET['act']) : '';

        echo '<div class="wrap"><h1>Tasks</h1>';
        self::kiosk_top_links();
        self::render_tabs('tasks', $lvl);

        echo '<script>window.BU_TASKS_URL='.wp_json_encode(admin_url('admin.php?page=bottomup_tasks')).';</script>';

        // Tasks: gleiche 3-stufige Filterlogik wie bei Ideen (Ebene via Tabs + darunter Kategorien + Vorstösse/Aktionen)
        self::render_ideas_button_filters($lvl, $cat, $act, $fav_on, $arch_on, 'bottomup_tasks');

        // Ideen anhand der Filter (Ebene/Kategorie/Aktion/Favoriten/Archiv) holen und daraus Task-Summaries berechnen
        $idea_items = self::query_ideas($lvl, $cat, $act, $fav_on, $arch_on);
        $idea_ids = array_map(function($it){ return intval($it['id']); }, $idea_items);

        // Task-Summaries für alle gefilterten Ideen in einem Query holen
        $counts = [];
        foreach ($idea_ids as $iid){
            $counts[$iid] = ['todo'=>0,'doing'=>0,'done'=>0];
        }
        if (!empty($idea_ids)){
            $q = new WP_Query([
                'post_type'      => self::CPT_TASK,
                'post_status'    => 'publish',
                'posts_per_page' => -1,
                'fields'         => 'ids',
                'no_found_rows'  => true,
                'meta_query'     => [
                    [
                        'key'     => self::TASK_META_IDEA,
                        'value'   => $idea_ids,
                        'compare' => 'IN',
                    ]
                ],
            ]);
            if (!empty($q->posts) && is_array($q->posts)){
                update_meta_cache('post', $q->posts);
            }
            foreach ($q->posts as $tid){
                $iid = intval(get_post_meta($tid, self::TASK_META_IDEA, true));
                $st  = sanitize_key(get_post_meta($tid, self::TASK_META_STATUS, true));
                if (!isset($counts[$iid])) $counts[$iid] = ['todo'=>0,'doing'=>0,'done'=>0];
                if (!in_array($st, ['todo','doing','done'], true)) $st = 'todo';
                $counts[$iid][$st] += 1;
            }
        }

        echo '<div class="bu-list-controls">';
        echo '  <label style="margin-right:8px;">Anzeige:</label>';
        echo '  <select id="bu-tasks-per-page" class="bu-per-page">';
        echo '    <option value="10">10 / Seite</option>';
        echo '    <option value="20">20 / Seite</option>';
        echo '    <option value="50">50 / Seite</option>';
        echo '  </select> ';
        echo '  <button type="button" id="bu-tasks-reset" class="button">Filter zurücksetzen</button>';
        echo '</div>';

        echo '<div id="bu-tasks-container" data-ssr="1">';
        echo '<table class="widefat striped bu-table bu-tasks-table">';
        echo '<thead>';
        echo '<tr>';
        echo '<th style="width:90px;">ID Idee</th>';
        echo '<th>Titel Idee</th>';
        echo '<th style="width:260px;">Taskstatus</th>';
        echo '<th style="width:110px;">Runden #</th>';
        echo '<th style="width:120px;">Aktionen</th>';
        echo '</tr>';
        echo '<tr class="bu-filters-row">';
        echo '<td><input type="search" class="bu-task-filter" data-name="id" placeholder="ID"></td>';
        echo '<td><input type="search" class="bu-task-filter" data-name="title" placeholder="Titel enthält..."></td>';
        echo '<td></td><td></td><td></td>';
        echo '</tr>';
        echo '</thead><tbody>';

        if (empty($idea_items)){
            echo '<tr><td colspan="5">Keine Ideen gefunden.</td></tr>';
        } else {
            foreach ($idea_items as $it){
                $iid = intval($it['id']);
                $title = $it['title'];
                $c = isset($counts[$iid]) ? $counts[$iid] : ['todo'=>0,'doing'=>0,'done'=>0];
                $summary = 'ToDo:'.intval($c['todo']).' / Doing:'.intval($c['doing']).' / Done:'.intval($c['done']);

                $open_url = esc_url(add_query_arg(['page'=>'bottomup_tasks_board','idea'=>$iid], admin_url('admin.php')));
                echo '<tr data-id="'.intval($iid).'" data-title="'.esc_attr(strtolower($title)).'">';
                echo '<td>'.intval($iid).'</td>';
                echo '<td>'.esc_html($title).'</td>';
                echo '<td>'.esc_html($summary).'</td>';
                $round = self::get_round_current($iid);
                echo '<td><span class="bu-round-badge" title="Runde #'.intval($round).'">'.intval($round).'</span></td>';
                echo '<td><a class="button button-small" href="'.$open_url.'">Öffnen</a></td>';
                echo '</tr>';
            }
        }

        echo '</tbody></table>';
        echo '<div class="tablenav bottom"><div class="tablenav-pages bu-tasks-pager"></div></div>';
        echo '</div>'; // container
        echo '</div>'; // wrap
    }
    public static function render_tasks_board(){
        if (!current_user_can('read')) wp_die('Keine Berechtigung.');
        $iid = isset($_GET['idea']) ? intval($_GET['idea']) : 0;
        if (!$iid) wp_die('Fehlende Idee.');

        $idea = get_post($iid);
        if (!$idea || $idea->post_type !== self::CPT) wp_die('Idee nicht gefunden.');

        $fav = in_array($iid, self::get_user_favorites(), true);

        $readonly = self::is_idea_archived($iid);


        echo '<div class="wrap bu-board-wrap" data-readonly="'.($readonly?1:0).'">';
        self::kiosk_top_links();
        echo '<div class="bu-board-top">';
        if ($readonly){
            echo '<div class="notice notice-warning bu-readonly-notice" style="margin:10px 0 0;"><p><strong>Hinweis:</strong> Diese Idee ist archiviert. Tasks sind schreibgeschützt (nur Anzeige).</p></div>';
        }

        echo '<div class="bu-board-top-left"><a href="'.esc_url(admin_url('admin.php?page=bottomup_tasks')).'">← Zurück</a></div>';
        $round = self::get_round_current($iid);
        $round_badge = ' <span class="bu-round-badge" title="Runde #'.intval($round).'">Runde #'.intval($round).'</span>';
        $dl = self::get_round_deadline($iid, $round);
        if ($dl){
            $dl_txt = self::fmt_round_deadline($dl);
            if ($dl_txt){
                $expired = self::deadline_is_expired($dl);
                $cls = $expired ? ' bu-deadline-expired' : '';
                $title = $expired ? ' title="verstrichen"' : '';
                $round_badge .= ' <span class="bu-round-deadline'.$cls.'"'.$title.' style="margin-left:6px;color:#444">Runde #'.intval($round).' läuft bis '.esc_html($dl_txt).'</span>';
            }
        }

        echo '<div class="bu-board-top-center">#'.intval($iid).' – '.esc_html(get_the_title($iid)).($fav ? ' <span class="bu-fav-star bu-fav-on" title="Favorit">★</span>' : ' <span class="bu-fav-star" title="Kein Favorit">★</span>').$round_badge.'</div>';
        echo '<div class="bu-board-top-right"></div>';
        echo '</div>';

        // Tasks laden
        $tasks = new WP_Query([
            'post_type'      => self::CPT_TASK,
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'orderby'        => 'meta_value_num',
            'meta_key'       => self::TASK_META_ORDER,
            'order'          => 'ASC',
            'meta_query'     => [
                [
                    'key'   => self::TASK_META_IDEA,
                    'value' => $iid,
                ]
            ],
        ]);
        $cols = ['todo'=>[], 'doing'=>[], 'done'=>[]];
        foreach ($tasks->posts as $t){
            $st = sanitize_key(get_post_meta($t->ID, self::TASK_META_STATUS, true));
            if (!in_array($st, ['todo','doing','done'], true)) $st='todo';
            $cols[$st][] = $t;
        }

        $users = get_users(['fields'=>['ID','display_name']]);

        echo '<div class="bu-board" data-idea="'.intval($iid).'">';
        foreach (['todo'=>'ToDo','doing'=>'Doing','done'=>'Done'] as $key=>$label){
            echo '<div class="bu-col" data-status="'.esc_attr($key).'">';
            echo '<div class="bu-col-head"><span>'.esc_html($label).'</span>';
            if ($key==='todo' && !$readonly) echo '<button type="button" class="button button-small bu-task-add" data-status="'.esc_attr($key).'">+ Task</button>';
            echo '</div>';
            echo '<div class="bu-col-body" data-status="'.esc_attr($key).'">';
            foreach ($cols[$key] as $t){
                self::render_task_card($t, $iid, $users, $readonly);
            }
            echo '</div></div>';
        }
        echo '</div>'; // board

        echo '</div>'; // wrap
    }
    private static function render_task_card($t, $iid, $users){
        $tid = intval($t->ID);
        $title = $t->post_title;
        $desc = $t->post_content;
        $st = sanitize_key(get_post_meta($tid, self::TASK_META_STATUS, true));
        if (!in_array($st, ['todo','doing','done'], true)) $st='todo';
        $due = sanitize_text_field(get_post_meta($tid, self::TASK_META_DUE, true)); // dd.mm.yyyy
        $ass = intval(get_post_meta($tid, self::TASK_META_ASSIGNEE, true));
        $check = get_post_meta($tid, self::TASK_META_CHECKLIST, true);
        $attach = get_post_meta($tid, self::TASK_META_ATTACH, true);
        $comments = get_post_meta($tid, self::TASK_META_COMMENTS, true);

        echo '<div class="bu-card" data-task="'.intval($tid).'" data-status="'.esc_attr($st).'">';
        echo '<div class="bu-card-title" draggable="true" data-task="'.intval($tid).'">'.esc_html($title).'</div>';

        echo '<div class="bu-card-top" draggable="true" data-task="'.intval($tid).'">';
        echo '<div class="bu-card-top-left">';
        $created = get_post_time('d.m.Y', false, $t);
        if ($created) echo '<span class="bu-badge" title="Erstelldatum: '.esc_attr($created).'">🕒 '.esc_html($created).'</span>';

        // Fälligkeit immer als dd.mm.yyyy anzeigen
        $due_disp = $due;
        if ($due_disp && preg_match('/^\d{4}-\d{2}-\d{2}$/', $due_disp)){
            $dt = DateTime::createFromFormat('Y-m-d', $due_disp);
            if ($dt) $due_disp = $dt->format('d.m.Y');
        }
        if ($due_disp) echo '<span class="bu-badge" title="Fälligkeit: '.esc_attr($due_disp).'">📅 '.esc_html($due_disp).'</span>';
        if ($ass) {
            $u = get_user_by('id',$ass);
            if ($u){
                $pm = esc_url(self::pm_url($iid, $ass, $tid));
                echo '<span class="bu-badge">👤 '.esc_html($u->display_name).' <a href="'.$pm.'" title="Private Nachricht"><span class="dashicons dashicons-email"></span></a></span>';
            }
        }
        echo '</div>';
        echo '<button type="button" class="button button-small bu-task-open" data-task="'.intval($tid).'">Bearbeiten</button>';
        echo '</div>';

        // Detail Panel (initial hidden)
        echo '<div class="bu-task-panel" style="display:none" data-task="'.intval($tid).'">';

        echo '<div class="bu-task-row">';
        echo '<label style="flex:1;">Status<br><select class="bu-task-field" data-field="status">';
        foreach (['todo'=>'ToDo','doing'=>'Doing','done'=>'Done'] as $k=>$lab){
            echo '<option value="'.esc_attr($k).'"'.selected($st,$k,false).'>'.esc_html($lab).'</option>';
        }
        echo '</select></label>';
        echo '<label style="flex:1;">Fällig<br><input type="text" class="bu-task-field" data-field="due" value="'.esc_attr($due_disp ? $due_disp : $due).'" placeholder="31.12.2025" /></label>';
        echo '<label style="flex:1;">Zuständig<br><select class="bu-task-field" data-field="assignee">';
        echo '<option value="">–</option>';
        foreach ($users as $u){
            echo '<option value="'.intval($u->ID).'"'.selected($ass,$u->ID,false).'>'.esc_html($u->display_name).'</option>';
        }
        echo '</select></label>';
        echo '</div>';

        echo '<label>Titel<br><input type="text" class="widefat bu-task-field" data-field="title" value="'.esc_attr($title).'" /></label><br>';
        echo '<label>Beschreibung<br><textarea class="widefat bu-task-field" data-field="desc" rows="4">'.esc_textarea($desc).'</textarea></label><br>';

        echo '<label>Checklist (eine Zeile = ein Punkt, "[x] " = erledigt)<br>';
        $check_text = '';
        if ($check){
            $arr = json_decode($check, true);
            if (is_array($arr)){
                $lines=[];
                foreach ($arr as $it){
                    $lines[] = (!empty($it['done']) ? '[x] ' : '[ ] ') . ($it['text'] ?? '');
                }
                $check_text = implode("\n",$lines);
            }
        }
        echo '<textarea class="widefat bu-task-field" data-field="checklist" rows="4">'.esc_textarea($check_text).'</textarea></label><br>';

        echo '<label>Attachments (eine URL pro Zeile)<br>';
        $att_text = '';
        if ($attach){
            $arr = json_decode($attach, true);
            if (is_array($arr)) $att_text = implode("\n",$arr);
        }
        echo '<textarea class="widefat bu-task-field" data-field="attach" rows="3">'.esc_textarea($att_text).'</textarea></label><br>';

        echo '<div class="bu-task-comments">';
        echo '<div class="bu-task-comments-list">';
        if ($comments){
            $arr = json_decode($comments, true);
            if (is_array($arr)){
                foreach ($arr as $c){
                    $who = esc_html($c['user'] ?? '');
                    $cuid = intval($c['uid'] ?? 0);
                    $pm_icon = '';
                    if ($cuid){
                        $pm_url = esc_url(self::pm_url($iid, $cuid, $tid));
                        $pm_icon = ' <a href="'.$pm_url.'" title="Private Nachricht"><span class="dashicons dashicons-email"></span></a>';
                    }
                    $raw_ts = (string)($c['ts'] ?? '');
                    $ts = $raw_ts;
                    if (preg_match('/^(\d{4})-(\d{2})-(\d{2})/', $raw_ts, $m)){
                        $ts = $m[3].'.'.$m[2].'.'.$m[1].substr($raw_ts, 10);
                    }
                    $ts  = esc_html($ts);
                    $txt = esc_html($c['text'] ?? '');
                    echo '<div class="bu-comment"><div class="bu-comment-meta">'.$who.$pm_icon.' · '.$ts.'</div><div class="bu-comment-text">'.$txt.'</div></div>';
                }
            }
        }
        echo '</div>';
        echo '<textarea class="widefat bu-task-comment-text" rows="2" placeholder="Kommentar hinzufügen…"></textarea>';
        echo '<button type="button" class="button button-small bu-task-add-comment" data-task="'.intval($tid).'">Kommentar speichern</button>';
        echo '</div>';

        echo '<div class="bu-task-panel-actions">';
        echo '<button type="button" class="button button-primary bu-task-save" data-task="'.intval($tid).'">Speichern</button> ';
        echo '<button type="button" class="button bu-task-cancel" data-task="'.intval($tid).'">Schließen</button>';
        echo '</div>';

        echo '</div>'; // panel
        echo '</div>'; // card
    }
    private static function tasks_check_nonce(){
        if (!current_user_can('read')) wp_send_json_error(['message'=>'Keine Berechtigung.'], 403);
        $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';
        if (!wp_verify_nonce($nonce, 'bu_tasks')) wp_send_json_error(['message'=>'Ungültiger Nonce.'], 403);
    }
    public static function ajax_task_create(){
        self::tasks_check_nonce();
        $iid = intval($_POST['idea'] ?? 0);
        $status = sanitize_key($_POST['status'] ?? 'todo');
        if (!in_array($status,['todo','doing','done'], true)) $status='todo';
        if (!$iid) wp_send_json_error(['message'=>'Fehlende Idee.'], 400);
        if (self::is_idea_archived($iid)) wp_send_json_error(['message'=>'Idee ist archiviert – Tasks sind schreibgeschützt.'], 403);

        $title = sanitize_text_field($_POST['title'] ?? 'Neuer Task');
        $tid = wp_insert_post([
            'post_type'   => self::CPT_TASK,
            'post_status' => 'publish',
            'post_title'  => $title,
            'post_content'=> '',
        ], true);
        if (is_wp_error($tid)) wp_send_json_error(['message'=>$tid->get_error_message()], 500);

        update_post_meta($tid, self::TASK_META_IDEA, $iid);
        update_post_meta($tid, self::TASK_META_STATUS, $status);
        update_post_meta($tid, self::TASK_META_ORDER, time());

        // Benachrichtigung: Neuer Task bei Favoriten-Tasks
        if ($iid){
            $st_lab = self::fav_task_status_label($status);
            self::notify_favorite_watchers_task_event(
                $iid,
                $tid,
                'create',
                'Neuer Task erstellt (Status: '.$st_lab.')',
                get_current_user_id()
            );
        }

        wp_send_json_success(['task_id'=>$tid]);
    }
    public static function ajax_task_update(){
        self::tasks_check_nonce();
        $tid = intval($_POST['task'] ?? 0);
        if (!$tid) wp_send_json_error(['message'=>'Fehlender Task.'], 400);
        $iid = intval(get_post_meta($tid, self::TASK_META_IDEA, true));
        if ($iid && self::is_idea_archived($iid)) wp_send_json_error(['message'=>'Idee ist archiviert – Tasks sind schreibgeschützt.'], 403);

        $field = sanitize_key($_POST['field'] ?? '');
        $value = wp_unslash($_POST['value'] ?? '');

        if ($field === 'title'){
            $old_title = get_the_title($tid);
            $new_title = sanitize_text_field($value);
            wp_update_post(['ID'=>$tid,'post_title'=>$new_title]);
            if ($iid && $old_title !== $new_title){
                self::notify_favorite_watchers_task_event($iid, $tid, "content", 'Titel geändert.', get_current_user_id());
            }
        } elseif ($field === 'desc'){
            $old_desc = (string)get_post_field('post_content', $tid);
            $new_desc = wp_kses_post($value);
            wp_update_post(['ID'=>$tid,'post_content'=>$new_desc]);
            if ($iid && $old_desc !== $new_desc){
                self::notify_favorite_watchers_task_event($iid, $tid, "content", 'Beschreibung/Inhalt geändert.', get_current_user_id());
            }
        } elseif ($field === 'due'){
            $old_due = (string)get_post_meta($tid, self::TASK_META_DUE, true);
            $v = sanitize_text_field($value);
            if ($v===''){
                update_post_meta($tid, self::TASK_META_DUE, '');
                if ($iid && $old_due !== ''){
                    self::notify_favorite_watchers_task_event($iid, $tid, 'due', 'Datum entfernt.', get_current_user_id());
                }
            } elseif (preg_match('/^\d{4}-\d{2}-\d{2}$/', $v)){
                $dt = DateTime::createFromFormat('Y-m-d', $v);
                if ($dt) $v = $dt->format('d.m.Y');
                update_post_meta($tid, self::TASK_META_DUE, $v);
                if ($iid && $old_due !== $v){
                    self::notify_favorite_watchers_task_event($iid, $tid, 'due', 'Datum gesetzt/geändert: '.$v, get_current_user_id());
                }
            } elseif (preg_match('/^\d{2}\.\d{2}\.\d{4}$/', $v)){
                update_post_meta($tid, self::TASK_META_DUE, $v);
                if ($iid && $old_due !== $v){
                    self::notify_favorite_watchers_task_event($iid, $tid, 'due', 'Datum gesetzt/geändert: '.$v, get_current_user_id());
                }
            } else {
                wp_send_json_error(['message'=>'Ungültiges Datumsformat (dd.mm.yyyy).'], 400);
            }
        } elseif ($field === 'assignee'){
            $old = (string)get_post_meta($tid, self::TASK_META_ASSIGNEE, true);
            $new = (string)intval($value);
            update_post_meta($tid, self::TASK_META_ASSIGNEE, intval($value));
            if ($iid && $old !== $new){
                self::notify_favorite_watchers_task_event($iid, $tid, 'other', 'Zuständigkeit geändert.', get_current_user_id());
            }
        } elseif ($field === 'status'){
            $old = sanitize_key(get_post_meta($tid, self::TASK_META_STATUS, true));
            if (!in_array($old,['todo','doing','done'], true)) $old='todo';

            $st = sanitize_key($value);
            if (!in_array($st,['todo','doing','done'], true)) $st='todo';

            update_post_meta($tid, self::TASK_META_STATUS, $st);

            // Benachrichtigung: Task-Bewegung auf Favoriten-Tasks (pro User granular)
            if ($iid && $old !== $st){
                self::notify_favorite_watchers_task_moved($iid, $tid, $old, $st, get_current_user_id());
            }
        } elseif ($field === 'checklist'){
            // Parse lines into JSON
            $lines = array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $value)));
            $arr=[];
            foreach ($lines as $ln){
                $done = false;
                if (preg_match('/^\[(x|X)\]\s*/', $ln)){
                    $done = true;
                    $ln = preg_replace('/^\[(x|X)\]\s*/','',$ln);
                } elseif (preg_match('/^\[\s\]\s*/', $ln)){
                    $ln = preg_replace('/^\[\s\]\s*/','',$ln);
                }
                $arr[] = ['text'=>$ln,'done'=>$done];
            }
            $old = (string)get_post_meta($tid, self::TASK_META_CHECKLIST, true);
            $new = wp_json_encode($arr);
            update_post_meta($tid, self::TASK_META_CHECKLIST, $new);
            if ($iid && $old !== $new){
                self::notify_favorite_watchers_task_event($iid, $tid, 'other', 'Checkliste geändert.', get_current_user_id());
            }
        } elseif ($field === 'attach'){
            $lines = array_values(array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $value))));
            $old = (string)get_post_meta($tid, self::TASK_META_ATTACH, true);
            $new = wp_json_encode($lines);
            update_post_meta($tid, self::TASK_META_ATTACH, $new);
            if ($iid && $old !== $new){
                self::notify_favorite_watchers_task_event($iid, $tid, 'other', 'Anhänge/Links geändert.', get_current_user_id());
            }
        } else {
            wp_send_json_error(['message'=>'Unbekanntes Feld.'], 400);
        }

        wp_send_json_success(['ok'=>1]);
    }
    public static function ajax_task_reorder(){
        self::tasks_check_nonce();
        $payload = isset($_POST['payload']) ? wp_unslash($_POST['payload']) : '';
        $data = json_decode($payload, true);
        if (!is_array($data)) wp_send_json_error(['message'=>'Ungültige Daten.'], 400);

        $iid = intval($_POST['idea'] ?? 0);
        if (!$iid){
            foreach (['todo','doing','done'] as $st){
                if (empty($data[$st]) || !is_array($data[$st])) continue;
                foreach ($data[$st] as $tid_tmp){
                    $tid_tmp = intval($tid_tmp);
                    if ($tid_tmp){ $iid = intval(get_post_meta($tid_tmp, self::TASK_META_IDEA, true)); break 2; }
                }
            }
        }
        if ($iid && self::is_idea_archived($iid)) wp_send_json_error(['message'=>'Idee ist archiviert – Tasks sind schreibgeschützt.'], 403);


        foreach (['todo','doing','done'] as $st){
            if (empty($data[$st]) || !is_array($data[$st])) continue;
            $order = 1;
            foreach ($data[$st] as $tid){
                $tid = intval($tid);
                if (!$tid) continue;

                $old = sanitize_key(get_post_meta($tid, self::TASK_META_STATUS, true));
                if (!in_array($old,['todo','doing','done'], true)) $old='todo';

                update_post_meta($tid, self::TASK_META_STATUS, $st);
                update_post_meta($tid, self::TASK_META_ORDER, $order);

                // Benachrichtigung: Task-Bewegung auf Favoriten-Ideen (pro User granular)
                if ($iid && $old !== $st){
                    self::notify_favorite_watchers_task_moved($iid, $tid, $old, $st, get_current_user_id());
                }

                $order++;
            }
        }
        wp_send_json_success(['ok'=>1]);
    }
    public static function ajax_task_add_comment(){
        self::tasks_check_nonce();
        $tid = intval($_POST['task'] ?? 0);
        $text = sanitize_textarea_field($_POST['text'] ?? '');
        if (!$tid || $text==='') wp_send_json_error(['message'=>'Fehlende Daten.'], 400);
        $iid = intval(get_post_meta($tid, self::TASK_META_IDEA, true));
        if ($iid && self::is_idea_archived($iid)) wp_send_json_error(['message'=>'Idee ist archiviert – Tasks sind schreibgeschützt.'], 403);

        $cur = get_post_meta($tid, self::TASK_META_COMMENTS, true);
        $arr = [];
        if ($cur){
            $tmp = json_decode($cur, true);
            if (is_array($tmp)) $arr = $tmp;
        }
        $u = wp_get_current_user();
        $arr[] = [
            'uid'  => $u ? intval($u->ID) : 0,
            'user' => $u ? $u->display_name : '',
            'ts'   => current_time('d.m.Y H:i'),
            'text' => $text,
        ];
        update_post_meta($tid, self::TASK_META_COMMENTS, wp_json_encode($arr));

        // Benachrichtigung: Kommentar bei Favoriten-Tasks
        if ($iid){
            $excerpt = trim(preg_replace('/\s+/', ' ', (string)$text));
            if (function_exists('mb_substr')){
                if (mb_strlen($excerpt) > 180) $excerpt = mb_substr($excerpt, 0, 180).'…';
            } else {
                if (strlen($excerpt) > 180) $excerpt = substr($excerpt, 0, 180).'…';
            }
            self::notify_favorite_watchers_task_event($iid, $tid, 'comment', 'Neuer Kommentar: '.$excerpt, get_current_user_id());
        }
        wp_send_json_success(['ok'=>1]);
    }
    public static function ajax_task_toggle_check(){
        self::tasks_check_nonce();
        // optional: could implement per-item toggle later
        wp_send_json_success(['ok'=>1]);
    }

}
