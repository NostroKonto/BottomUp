<?php
if (!defined('ABSPATH')) exit;

trait BU_Ideas_Print_Trait {
    public static function print_url($pid){
        $pid = intval($pid);
        return add_query_arg(['action'=>'bottomup_print_idea','post'=>$pid], admin_url('admin-post.php'));
    }
        public static function handle_print_idea(){
        if (!current_user_can('read')) wp_die('Keine Berechtigung.');
        $pid = isset($_GET['post']) ? intval($_GET['post']) : 0;
        if (!$pid || get_post_type($pid)!==self::CPT) wp_die('Ungültige ID.');

        $p = get_post($pid);
        $title = get_the_title($pid);
        $doc_title = 'Idee '.$pid.' – '.$title;

        $sum = get_post_meta($pid,self::META_SUMMARY,true);
        $pro = [
            get_post_meta($pid,self::META_PRO1,true),
            get_post_meta($pid,self::META_PRO2,true),
            get_post_meta($pid,self::META_PRO3,true)
        ];
        $con = [
            get_post_meta($pid,self::META_CON1,true),
            get_post_meta($pid,self::META_CON2,true),
            get_post_meta($pid,self::META_CON3,true)
        ];

        $avg = self::get_avg_rating($pid);
        list($yes,$no) = self::get_vote_counts($pid);
        $cats = wp_get_post_terms($pid, self::TAX_CAT, ['fields'=>'names']);
        $lvls = wp_get_post_terms($pid, self::TAX_LVL, ['fields'=>'names']);
        $a_name = get_the_author_meta('display_name',$p->post_author);
        $date = get_the_date('d.m.Y', $pid);

        nocache_headers();
        header('Content-Type: text/html; charset=' . get_bloginfo('charset'));

        // Back to view url
        $back = admin_url('admin.php?page=bottomup_view&post='.$pid);

        echo '<!doctype html><html><head><meta charset="'.esc_attr(get_bloginfo('charset')).'">';
        echo '<title>'.esc_html($doc_title).'</title>';
        echo '<style>
            :root{--border:#c3c4c7;--bg:#f0f0f1;--stripe:#f6f7f7;--text:#1d2327;}
            html,body{background:#fff;}
            body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif; margin:24px; color:var(--text);}
            .wrap{max-width:960px;}
            h1{margin:0 0 14px; font-size:22px; font-weight:600;}
            .subtitle{margin:0 0 18px; color:#50575e; font-size:13px;}
            .top-actions{display:flex; gap:10px; justify-content:flex-end; margin:0 0 10px;}
            .top-actions a,.top-actions button{
                display:inline-flex; align-items:center; gap:6px;
                background:#fff; border:1px solid #d0d7de; border-radius:8px;
                padding:6px 10px; font-size:13px; cursor:pointer; text-decoration:none; color:#1d2327;
            }
            .top-actions a:hover,.top-actions button:hover{background:#f6f8fa;}
            table.widefat{border:1px solid var(--border); border-collapse:separate; border-spacing:0; width:100%; background:#fff;}
            table.widefat th, table.widefat td{padding:10px 12px; vertical-align:top; border-bottom:1px solid var(--border);}
            table.widefat tr:last-child th, table.widefat tr:last-child td{border-bottom:none;}
            table.widefat th{width:220px; background:var(--bg); text-align:left; font-weight:600;}
            table.widefat.striped tbody tr:nth-child(odd) td{background:var(--stripe);}
            table.widefat.striped tbody tr:nth-child(odd) th{background:color-mix(in srgb, var(--bg) 85%, #fff);}
            ul{margin:0; padding-left:18px;}
            a{color:inherit;}
            @media print{
                body{margin:12mm;}
                .no-print{display:none !important;}
                @page{margin:12mm;}
            }
        </style></head><body><div class="wrap">';

        // Buttons (not printed)
        echo '<div class="top-actions no-print">';
        echo '<a href="'.esc_url($back).'" onclick="if(window.opener){try{window.close();}catch(e){} return false;}">← Zur Ansicht</a>';
        echo '<button type="button" onclick="window.print()">🖨 Drucken</button>';
        echo '</div>';

        echo '<h1>'.esc_html($doc_title).'</h1>';
        echo '<p class="subtitle">Druckansicht</p>';

        echo '<table class="widefat striped"><tbody>';
        echo '<tr><th>ID</th><td>'.intval($pid).'</td></tr>';
        echo '<tr><th>Titel</th><td>'.esc_html($title).'</td></tr>';
        echo '<tr><th>Autor</th><td>'.esc_html($a_name).'</td></tr>';
        echo '<tr><th>Kategorie</th><td>'.esc_html(implode(', ', (array)$cats)).'</td></tr>';
        echo '<tr><th>Ebene</th><td>'.esc_html(implode(', ', (array)$lvls)).'</td></tr>';
        echo '<tr><th>Datum</th><td>'.esc_html($date).'</td></tr>';
        echo '<tr><th>Inhalt</th><td>'.wp_kses_post(apply_filters('the_content', $p->post_content)).'</td></tr>';
        echo '<tr><th>Zusammenfassung</th><td>'.nl2br(esc_html($sum)).'</td></tr>';

        echo '<tr><th>Vorteile</th><td><ul>';
        echo '<li>'.esc_html($pro[0]).'</li><li>'.esc_html($pro[1]).'</li><li>'.esc_html($pro[2]).'</li>';
        echo '</ul></td></tr>';

        echo '<tr><th>Nachteile</th><td><ul>';
        echo '<li>'.esc_html($con[0]).'</li><li>'.esc_html($con[1]).'</li><li>'.esc_html($con[2]).'</li>';
        echo '</ul></td></tr>';

        $avg_str = is_null($avg) ? '–' : number_format_i18n($avg, 1);
        echo '<tr><th>SK-Ø / Ja-Nein</th><td>'.$avg_str.' &nbsp; | &nbsp; '.intval($yes).'/'.intval($no).'</td></tr>';
        echo '</tbody></table>';

        echo '</div></body></html>';
        exit;
    }

}
