<?php
if (!defined('ABSPATH')) exit;

trait BU_Ideas_Kiosk_Trait {
    private static function is_kiosk_enabled(){
        if (!is_admin()) return false;

        // Per-user override (show full WP menu)
        $uid = get_current_user_id();
        if ($uid && get_user_meta($uid, 'bu_kiosk_off', true) === '1') return false;

        // Admin escape hatch: append &bu_fullmenu=1 to any admin URL to temporarily show full menu
        if (current_user_can('manage_options') && isset($_GET['bu_fullmenu']) && $_GET['bu_fullmenu']=='1') return false;

        return true;
    }
    public static function handle_kiosk_toggle(){
        if (!is_admin()) return;
        if (!is_user_logged_in()) return;
        if (!isset($_GET['bu_menu'])) return;

        $mode = sanitize_key($_GET['bu_menu']);
        $uid  = get_current_user_id();

        if (!$uid) return;

        if ($mode === 'full'){
            update_user_meta($uid, 'bu_kiosk_off', '1');
        } elseif ($mode === 'kiosk'){
            delete_user_meta($uid, 'bu_kiosk_off');
        } else {
            return;
        }

        // Redirect to same page without bu_menu parameter
        $url = remove_query_arg(['bu_menu']);
        wp_safe_redirect($url);
        exit;
    }
    public static function kiosk_admin_menu(){
        if (!self::is_kiosk_enabled()) return;

        global $menu;
        if (empty($menu) || !is_array($menu)) return;

        // Keep only BottomUp top-level menu (and its submenus)
        $keep = ['bottomup_dashboard'];

        foreach ($menu as $item){
            if (!is_array($item) || !isset($item[2])) continue;
            $slug = (string)$item[2];
            if (in_array($slug, $keep, true)) continue;
            // Hide everything else
            remove_menu_page($slug);
        }
    }
    private static function kiosk_top_links(){
        // Small helper links on BottomUp pages
        $base = admin_url('admin.php?page=bottomup_dashboard');
        $full = esc_url(add_query_arg(['bu_menu'=>'full'], $base));
        $kiosk= esc_url(add_query_arg(['bu_menu'=>'kiosk'], $base));

        if (self::is_kiosk_enabled()){
            echo '<div style="margin:10px 0 0;opacity:.85;">';
            echo '<a href="'.$full.'">WP-Menü anzeigen</a>';
            if (current_user_can('manage_options')){
                echo ' <span style="margin-left:10px;" class="description">(Admin-Notfall: &amp;bu_fullmenu=1)</span>';
            }
            echo '</div>';
        } else {
            echo '<div style="margin:10px 0 0;opacity:.85;">';
            echo '<a href="'.$kiosk.'">Kiosk-Modus aktivieren</a>';
            echo '</div>';
        }
    }
    public static function kiosk_floating_button_css(){
        if (!self::is_bottomup_page()) return;
        echo '<style>
            .bu-kiosk-fab{
                position:fixed;
                top:46px;
                right:14px;
                z-index:99999;
                background:#fff;
                border:1px solid #d0d7de;
                border-radius:999px;
                padding:6px 10px;
                font-size:13px;
                line-height:18px;
                text-decoration:none;
                box-shadow:0 2px 8px rgba(0,0,0,.08);
            }
            .bu-kiosk-fab:hover{ background:#f6f8fa; }
            /* If admin bar is hidden, tuck closer to top */
            body.admin-bar-hidden .bu-kiosk-fab{ top:14px; }
        </style>';
    }
    public static function kiosk_floating_button(){
        if (!self::is_bottomup_page()) return;

        $mode = self::is_kiosk_enabled() ? 'full' : 'kiosk';
        $label = self::is_kiosk_enabled() ? 'WP-Menü' : 'Kiosk';
        $icon  = self::is_kiosk_enabled() ? '↗' : '⤾';

        // Current URL toggle (keep current page + params)
        $url = add_query_arg(['bu_menu'=>$mode], remove_query_arg(['bu_menu']));
        echo '<a class="bu-kiosk-fab" href="'.esc_url($url).'" title="'.esc_attr($label.' umschalten').'">'.$icon.' '.esc_html($label).'</a>';
    }

}
