<?php
if (!defined('ABSPATH')) exit;

trait BU_Ideas_PM_Trait {
    private static function pm_url($idea_id, $other_user_id, $task_id=0){
        $args = ['page'=>'bottomup_messages','idea'=>intval($idea_id),'user'=>intval($other_user_id)];
        if ($task_id) $args['task'] = intval($task_id);
        return add_query_arg($args, admin_url('admin.php'));
    }
    private static function pm_tables(){
        global $wpdb;
        return [
            'messages' => $wpdb->prefix . self::PM_TABLE,
            'groups'   => $wpdb->prefix . self::PM_GROUP_TABLE,
        ];
    }
    private static function pm_install_tables(){
        if (!function_exists('dbDelta')){
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        }
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        $t = self::pm_tables();
        $sql1 = "CREATE TABLE {$t['messages']} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            idea_id BIGINT(20) UNSIGNED NOT NULL,
            task_id BIGINT(20) UNSIGNED NULL,
            sender_id BIGINT(20) UNSIGNED NOT NULL,
            recipient_id BIGINT(20) UNSIGNED NOT NULL,
            body LONGTEXT NOT NULL,
            created_at DATETIME NOT NULL,
            read_at DATETIME NULL,
            deleted_by_sender TINYINT(1) NOT NULL DEFAULT 0,
            deleted_by_recipient TINYINT(1) NOT NULL DEFAULT 0,
            PRIMARY KEY  (id),
            KEY idea_idx (idea_id),
            KEY task_idx (task_id),
            KEY sender_idx (sender_id),
            KEY recipient_idx (recipient_id),
            KEY convo_idx (idea_id, sender_id, recipient_id),
            KEY created_idx (created_at)
        ) $charset;";
        $sql2 = "CREATE TABLE {$t['groups']} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT(20) UNSIGNED NOT NULL,
            idea_id BIGINT(20) UNSIGNED NOT NULL,
            other_user_id BIGINT(20) UNSIGNED NOT NULL,
            label VARCHAR(120) NOT NULL DEFAULT '',
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uniq (user_id, idea_id, other_user_id),
            KEY user_idx (user_id),
            KEY label_idx (label)
        ) $charset;";
        dbDelta($sql1);
        dbDelta($sql2);
            update_option('bu_pm_db_ver', intval(self::PM_DB_VER));
    }
    public static function pm_ensure_tables(){
        // Create / upgrade message tables on update (activation hook is not fired on plugin update)
        if (!is_admin()) return;
        if (!current_user_can('read')) return;
        global $wpdb;
        $t = self::pm_tables();

        $missing = false;
        foreach ($t as $tbl){
            $found = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $tbl));
            if ($found !== $tbl){ $missing = true; break; }
        }

        $have = intval(get_option('bu_pm_db_ver', 0));
        $want = intval(self::PM_DB_VER);

        if ($missing || $have < $want){
            self::pm_install_tables();
            update_option('bu_pm_db_ver', $want);
        }
    }

}
