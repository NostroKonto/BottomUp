<?php
if (!defined('ABSPATH')) exit;

trait BU_Ideas_Versions_Trait {
/*** Iterationsrunden & Versionshistorie ***/
private static function versions_table(){
    global $wpdb;
    return $wpdb->prefix . self::VERS_TABLE;
}
public static function versions_install_tables(){
    if (!function_exists('dbDelta')){
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    }
    global $wpdb;
    $charset = $wpdb->get_charset_collate();
    $t = self::versions_table();
    $sql = "CREATE TABLE {$t} (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        idea_id BIGINT(20) UNSIGNED NOT NULL,
        round_no INT(11) NOT NULL,
        created_at DATETIME NOT NULL,
        created_by BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
        snapshot LONGTEXT NOT NULL,
        PRIMARY KEY  (id),
        KEY idea_idx (idea_id),
        KEY round_idx (idea_id, round_no),
        KEY created_idx (created_at)
    ) {$charset};";
    dbDelta($sql);
}
public static function versions_ensure_tables(){
    if (!current_user_can('read')) return;
    $ver = intval(get_option('bu_idea_versions_db_ver', 0));
    if ($ver < intval(self::VERS_DB_VER)){
        self::versions_install_tables();
        update_option('bu_idea_versions_db_ver', intval(self::VERS_DB_VER));
    }
}
private static function get_round_current($iid){
    $r = intval(get_post_meta(intval($iid), self::META_ROUND, true));
    return ($r > 0) ? $r : 1;
}
private static function set_round_current($iid, $round){
    update_post_meta(intval($iid), self::META_ROUND, max(1, intval($round)));
}
    public static function get_round_deadline($iid, $round=null){
        $round = is_null($round) ? self::get_round_current($iid) : intval($round);
        if ($round<=0) $round = 1;
        $raw = get_post_meta(intval($iid), self::META_ROUND_DEADLINES, true);
        $map = [];
        if (is_string($raw) && $raw!==''){
            $d = json_decode($raw,true);
            if (is_array($d)) $map = $d;
        } elseif (is_array($raw)) {
            $map = $raw;
        }
        $key = (string)$round;
        return isset($map[$key]) ? (string)$map[$key] : '';
    }
    public static function set_round_deadline($iid, $round, $deadline_mysql){
        $round = intval($round);
        if ($round<=0) $round = 1;
        $deadline_mysql = trim((string)$deadline_mysql);
        $raw = get_post_meta(intval($iid), self::META_ROUND_DEADLINES, true);
        $map = [];
        if (is_string($raw) && $raw!==''){
            $d = json_decode($raw,true);
            if (is_array($d)) $map = $d;
        } elseif (is_array($raw)) {
            $map = $raw;
        }
        if ($deadline_mysql===''){
            unset($map[(string)$round]);
        } else {
            $map[(string)$round] = $deadline_mysql;
        }
        update_post_meta(intval($iid), self::META_ROUND_DEADLINES, wp_json_encode($map));
    }

    private static function deadline_is_expired($deadline_mysql){
        if (!$deadline_mysql) return false;
        $ts = strtotime($deadline_mysql);
        if (!$ts) return false;
        return ($ts < current_time('timestamp'));
    }

    private static function fmt_round_deadline($deadline_mysql){
        if (!$deadline_mysql) return '';
        $ts = strtotime($deadline_mysql);
        if (!$ts) return '';
        return wp_date('d.m.Y H:i', $ts);
    }
private static function build_snapshot($iid){
    $p = get_post(intval($iid));
    if (!$p) return null;

    $cats = wp_get_post_terms($iid, self::TAX_CAT, ['fields'=>'ids']);
    $lvls = wp_get_post_terms($iid, self::TAX_LVL, ['fields'=>'ids']);

    // Bewertungen/Abstimmung als Snapshot speichern (runde-spezifisch)
    $round = self::get_round_current($iid);
    list($avg,$sk_n) = self::get_rating_stats($iid, $round);
    list($yes,$no,$vote_n) = self::get_vote_stats($iid, $round);

    return [
        'title'   => get_the_title($iid),
        'content' => $p->post_content,
        'summary' => get_post_meta($iid, self::META_SUMMARY, true),
        'pros'    => [
            get_post_meta($iid, self::META_PRO1, true),
            get_post_meta($iid, self::META_PRO2, true),
            get_post_meta($iid, self::META_PRO3, true),
        ],
        'cons'    => [
            get_post_meta($iid, self::META_CON1, true),
            get_post_meta($iid, self::META_CON2, true),
            get_post_meta($iid, self::META_CON3, true),
        ],
        'cats'    => array_map('intval', is_array($cats) ? $cats : []),
        'lvls'    => array_map('intval', is_array($lvls) ? $lvls : []),
        'ratings' => [
            'round'  => intval($round),
            'sk_avg' => is_null($avg) ? null : floatval(number_format($avg, 4, '.', '')),
            'sk_n'   => intval($sk_n),
            'yes'    => intval($yes),
            'no'     => intval($no),
            'vote_n' => intval($vote_n),
        ],
    ];
}
private static function versions_check_nonce(){
    if (!current_user_can('read')) wp_send_json_error(['message'=>'Keine Berechtigung.'], 403);
    $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';
    if (!$nonce || !wp_verify_nonce($nonce, 'bu_versions')){
        wp_send_json_error(['message'=>'Nonce invalid'], 403);
    }
}
public static function handle_start_round(){
    if (!current_user_can('read')) wp_die('Keine Berechtigung.');
    $iid = isset($_GET['post']) ? intval($_GET['post']) : 0;
    if (!$iid || get_post_type($iid)!==self::CPT) wp_die('Ungültige Idee.');
    if (!current_user_can('edit_post', $iid)) wp_die('Keine Berechtigung.');
    if (!isset($_GET['_wpnonce']) || !wp_verify_nonce(sanitize_text_field($_GET['_wpnonce']), 'bu_start_round_'.$iid)){
        wp_die('Nonce invalid.');
    }
    if (self::is_idea_archived($iid)){
        wp_die('Diese Idee ist archiviert – schreibgeschützt.');
    }

    self::versions_ensure_tables();

    $round = self::get_round_current($iid);
    $snap  = self::build_snapshot($iid);
    if (!$snap) wp_die('Snapshot fehlgeschlagen.');

    global $wpdb;
    $t = self::versions_table();
    $wpdb->insert($t, [
        'idea_id'    => $iid,
        'round_no'   => $round,
        'created_at' => current_time('mysql'),
        'created_by' => get_current_user_id(),
        'snapshot'   => wp_json_encode($snap),
    ], ['%d','%d','%s','%d','%s']);

    self::set_round_current($iid, $round + 1);

    // Optional deadline for the NEW round (entered by moderator when starting the next round)
    // Preferred UI format: dd.mm.yyyy + 24h time (HH:MM)
    $deadline_date = isset($_REQUEST['deadline_date']) ? sanitize_text_field(wp_unslash($_REQUEST['deadline_date'])) : '';
    $deadline_time = isset($_REQUEST['deadline_time']) ? sanitize_text_field(wp_unslash($_REQUEST['deadline_time'])) : '';
    $deadline_in   = isset($_REQUEST['deadline']) ? sanitize_text_field(wp_unslash($_REQUEST['deadline'])) : '';

    try {
        $tz = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone(get_option('timezone_string') ?: 'UTC');

        if ($deadline_date !== ''){
            if ($deadline_time === '') $deadline_time = '00:00';
            $deadline_date = trim($deadline_date);
            $deadline_time = trim($deadline_time);

            if (preg_match('/^\d{2}\.\d{2}\.\d{4}$/', $deadline_date) && preg_match('/^\d{2}:\d{2}$/', $deadline_time)){
                // Allow 24:00 (interpreted as 00:00 next day)
                $add_day = false;
                if ($deadline_time === '24:00'){
                    $deadline_time = '00:00';
                    $add_day = true;
                }
                $dt = DateTime::createFromFormat('d.m.Y H:i', $deadline_date.' '.$deadline_time, $tz);
                if ($dt instanceof DateTime){
                    if ($add_day) $dt->modify('+1 day');
                    self::set_round_deadline($iid, $round + 1, $dt->format('Y-m-d H:i:s'));
                }
            }
        } elseif ($deadline_in){
            // Backward compatibility: datetime-local (YYYY-MM-DDTHH:MM) or mysql (YYYY-MM-DD HH:MM[:SS])
            $deadline_mysql = $deadline_in;
            if (strpos($deadline_mysql, 'T') !== false){
                $deadline_mysql = str_replace('T', ' ', $deadline_mysql);
            }
            if (strlen($deadline_mysql)===16) $deadline_mysql .= ':00';
            $dt = new DateTime($deadline_mysql, $tz);
            self::set_round_deadline($iid, $round + 1, $dt->format('Y-m-d H:i:s'));
        }
    } catch (Exception $e) {
        // ignore invalid deadline
    }

    // Benachrichtigung an Nutzer, die diese Idee als Favorit markiert haben
    self::notify_favorite_watchers($iid, 'Neue Runde gestartet', get_current_user_id(), [
        'fields' => 'Runde '.intval($round + 1),
    ]);


    $ref = wp_get_referer();
    if (!$ref) $ref = admin_url('admin.php?page=bottomup_view&post='.$iid);
    wp_safe_redirect($ref);
    exit;
}
public static function ajax_versions_list(){
    self::versions_check_nonce();
    $iid = isset($_POST['idea']) ? intval($_POST['idea']) : 0;
    if (!$iid || get_post_type($iid)!==self::CPT) wp_send_json_error(['message'=>'Ungültige Idee.'], 400);

    self::versions_ensure_tables();
    global $wpdb;
    $t = self::versions_table();
    $rows = $wpdb->get_results($wpdb->prepare("SELECT round_no, created_at, created_by FROM {$t} WHERE idea_id=%d ORDER BY round_no DESC, id DESC", $iid), ARRAY_A);
    if (!is_array($rows)) $rows = [];

    $out = [];
    foreach ($rows as $r){
        $out[] = [
            'round' => intval($r['round_no']),
            'ts'    => $r['created_at'],
            'by'    => intval($r['created_by']),
        ];
    }

    wp_send_json_success([
        'current_round' => self::get_round_current($iid),
        'versions'      => $out,
    ]);
}
public static function ajax_version_diff(){
    self::versions_check_nonce();
    $iid = isset($_POST['idea']) ? intval($_POST['idea']) : 0;
    $round = isset($_POST['round']) ? intval($_POST['round']) : 0;
    if (!$iid || get_post_type($iid)!==self::CPT || $round<=0) wp_send_json_error(['message'=>'Ungültige Anfrage.'], 400);

    self::versions_ensure_tables();
    global $wpdb;
    $t = self::versions_table();
    $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE idea_id=%d AND round_no=%d ORDER BY id DESC LIMIT 1", $iid, $round), ARRAY_A);
    if (!$row) wp_send_json_error(['message'=>'Version nicht gefunden.'], 404);

    $old = json_decode($row['snapshot'], true);
    if (!is_array($old)) wp_send_json_error(['message'=>'Snapshot defekt.'], 500);

    $cur = self::build_snapshot($iid);
    if (!$cur) wp_send_json_error(['message'=>'Aktueller Stand nicht lesbar.'], 500);

    if (!function_exists('wp_text_diff')){
        require_once ABSPATH . 'wp-admin/includes/revision.php';
    }

    $created_at = $row['created_at'];
    $created_fmt = mysql2date('d.m.Y H:i', $created_at);

    $html = '<div class="bu-diff-wrap">';
    $html .= '<div class="bu-diff-head"><strong>Runde #'.intval($round).'</strong> <span class="bu-diff-ts">'.esc_html($created_fmt).'</span></div>';

    $sections = [
        'Titel' => 'title',
        'Inhalt' => 'content',
        'Zusammenfassung' => 'summary',
        'Vorteile' => 'pros',
        'Nachteile' => 'cons',
    ];

    foreach ($sections as $label=>$field){
        $o = self::snap_text($old, $field);
        $n = self::snap_text($cur, $field);
        $diff = wp_text_diff($o, $n, ['show_split_view'=>false]);
        if (!$diff) $diff = '<p><em>Keine Änderungen.</em></p>';
        $html .= '<h3>'.esc_html($label).'</h3>'.$diff;
    }

    $o_c = self::terms_text($old['cats'] ?? [], self::TAX_CAT);
    $n_c = self::terms_text($cur['cats'] ?? [], self::TAX_CAT);
    $diff_c = wp_text_diff(wp_strip_all_tags($o_c), wp_strip_all_tags($n_c), ['show_split_view'=>false]);
    if (!$diff_c) $diff_c = '<p><em>Keine Änderungen.</em></p>';
    $html .= '<h3>Kategorien</h3>'.$diff_c;

    $o_l = self::terms_text($old['lvls'] ?? [], self::TAX_LVL);
    $n_l = self::terms_text($cur['lvls'] ?? [], self::TAX_LVL);
    $diff_l = wp_text_diff(wp_strip_all_tags($o_l), wp_strip_all_tags($n_l), ['show_split_view'=>false]);
    if (!$diff_l) $diff_l = '<p><em>Keine Änderungen.</em></p>';
    $html .= '<h3>Ebene</h3>'.$diff_l;

    // Bewertungen/Abstimmung: Vergleich Version (Runde #{$round}) vs aktueller Stand (aktuelle Runde)
    $old_round = $round;
    $cur_round = self::get_round_current($iid);

    list($old_avg,$old_sk_n) = self::get_rating_stats($iid, $old_round);
    list($old_yes,$old_no,$old_vote_n) = self::get_vote_stats($iid, $old_round);

    list($cur_avg,$cur_sk_n) = self::get_rating_stats($iid, $cur_round);
    list($cur_yes,$cur_no,$cur_vote_n) = self::get_vote_stats($iid, $cur_round);

    $fmt_avg = function($v){ return (is_null($v) || $v==='') ? '–' : number_format((float)$v, 2, ',', '.'); };
    $fmt_int = function($v){ return (is_null($v) || $v==='') ? '–' : (string)intval($v); };

    $delta_avg = '–';
    if (is_numeric($old_avg) && is_numeric($cur_avg)){
        $d = (float)$cur_avg - (float)$old_avg;
        $delta_avg = ($d>=0?'+':'') . number_format($d, 2, ',', '.');
    }
    $delta_sk_n = (is_numeric($old_sk_n) && is_numeric($cur_sk_n)) ? ((int)$cur_sk_n - (int)$old_sk_n) : '–';
    $delta_yes  = (is_numeric($old_yes)  && is_numeric($cur_yes))  ? ((int)$cur_yes  - (int)$old_yes)  : '–';
    $delta_no   = (is_numeric($old_no)   && is_numeric($cur_no))   ? ((int)$cur_no   - (int)$old_no)   : '–';
    $delta_vote_n = (is_numeric($old_vote_n) && is_numeric($cur_vote_n)) ? ((int)$cur_vote_n - (int)$old_vote_n) : '–';

    $html .= '<hr><h3>Bewertungen / Abstimmung</h3>';
    $html .= '<table class="widefat striped" style="max-width:560px">'
        .'<thead><tr><th></th><th>Version Runde #'.intval($old_round).'</th><th>Aktuell Runde #'.intval($cur_round).'</th><th>Δ</th></tr></thead><tbody>'
        .'<tr><th>SK-Ø</th><td>'.esc_html($fmt_avg($old_avg)).'</td><td>'.esc_html($fmt_avg($cur_avg)).'</td><td>'.esc_html($delta_avg).'</td></tr>'
        .'<tr><th>SK (Anzahl)</th><td>'.esc_html($fmt_int($old_sk_n)).'</td><td>'.esc_html($fmt_int($cur_sk_n)).'</td><td>'.esc_html((string)$delta_sk_n).'</td></tr>'
        .'<tr><th>Ja</th><td>'.esc_html($fmt_int($old_yes)).'</td><td>'.esc_html($fmt_int($cur_yes)).'</td><td>'.esc_html((string)$delta_yes).'</td></tr>'
        .'<tr><th>Nein</th><td>'.esc_html($fmt_int($old_no)).'</td><td>'.esc_html($fmt_int($cur_no)).'</td><td>'.esc_html((string)$delta_no).'</td></tr>'
        .'<tr><th>Stimmen (Anzahl)</th><td>'.esc_html($fmt_int($old_vote_n)).'</td><td>'.esc_html($fmt_int($cur_vote_n)).'</td><td>'.esc_html((string)$delta_vote_n).'</td></tr>'
        .'</tbody></table>';

    $html .= '</div>';

wp_send_json_success(['html'=>$html]);
}

}
