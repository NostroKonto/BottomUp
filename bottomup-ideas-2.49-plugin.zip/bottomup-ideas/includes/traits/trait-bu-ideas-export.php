<?php
if (!defined('ABSPATH')) exit;

trait BU_Ideas_Export_Trait {
    /*** CSV – Listen-Export ***/
    public static function export_csv(){
        // CSV via admin-post: sauber ohne Admin-HTML
        while (ob_get_level()) { @ob_end_clean(); }
        nocache_headers();
        if (!current_user_can('edit_posts')) wp_die('Keine Berechtigung.');
        $only_list = isset($_GET['list']) && $_GET['list']=='1';
        $lvl = isset($_GET['level']) ? sanitize_text_field($_GET['level']) : '';
        $cat = isset($_GET['cat'])   ? sanitize_text_field($_GET['cat'])   : '';
        $act = isset($_GET['act'])   ? sanitize_text_field($_GET['act'])   : '';
        $fav_on  = (isset($_GET['fav']) && $_GET['fav']=='1');
        $arch_on = (isset($_GET['arch']) && $_GET['arch']=='1');
        $rows = self::query_ideas($lvl, $cat, $act, $fav_on, $arch_on);
        if ($only_list){
            $flt = [
                'title'  => isset($_GET['flt_title'])  ? (string)wp_unslash($_GET['flt_title'])  : '',
                'author' => isset($_GET['flt_author']) ? (string)wp_unslash($_GET['flt_author']) : '',
                'date'   => isset($_GET['flt_date'])   ? (string)wp_unslash($_GET['flt_date'])   : '',
                'sk'     => isset($_GET['flt_sk'])     ? (string)wp_unslash($_GET['flt_sk'])     : '',
                'vote'   => isset($_GET['flt_vote'])   ? (string)wp_unslash($_GET['flt_vote'])   : '',
                'cat'    => isset($_GET['flt_cat'])    ? (string)wp_unslash($_GET['flt_cat'])    : '',
                'lvl'    => isset($_GET['flt_lvl'])    ? (string)wp_unslash($_GET['flt_lvl'])    : '',
                'act'    => isset($_GET['flt_act'])    ? (string)wp_unslash($_GET['flt_act'])    : '',
            ];
            $rows = array_filter($rows, function($r) use($flt){
                $contains = function($v,$q){ if($q==='') return true; return (stripos((string)$v,(string)$q)!==false); };
                if (!$contains($r['title'],$flt['title'])) return false;
                if (!$contains($r['author'],$flt['author'])) return false;
                if ($flt['date']!==''){ if (stripos(substr($r['date'],0,10), $flt['date'])===false) return false; }
                if ($flt['sk']!==''){
                    $sk = is_null($r['sk_avg']) ? '' : (string)$r['sk_avg'];
                    if (stripos($sk, $flt['sk'])===false) return false;
                }
                if ($flt['vote']!==''){ $v = ($r['yes'].'/'.$r['no']); if (stripos($v, $flt['vote'])===false) return false; }
                if ($flt['cat']!==''){
                    $ok=false; foreach($r['cats_all'] as $c){ if (stripos($c['name'],$flt['cat'])!==false){ $ok=true; break; } }
                    if(!$ok) return false;
                }
                if ($flt['lvl']!==''){
                    $ok=false; foreach($r['lvls_all'] as $l){ if (stripos($l['name'],$flt['lvl'])!==false){ $ok=true; break; } }
                    if(!$ok) return false;
                }
                if ($flt['act']!==''){
                    $ok=false; foreach(($r['acts_all'] ?? []) as $a){ if (stripos($a['name'],$flt['act'])!==false){ $ok=true; break; } }
                    if(!$ok) return false;
                }
                return true;
            });
        }
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="bottomup-ideas-list.csv"');
        echo "\xEF\xBB\xBF";
        $out = fopen('php://output','w');
        fputcsv($out, ['Titel','Autor','Datum','SK Ø','Ja','Nein','Kategorien','Ebenen','Vorstösse/Aktionen']);
        foreach ($rows as $r){
            $date = substr($r['date'],0,10);
            $sk   = is_null($r['sk_avg']) ? '' : number_format($r['sk_avg'],2,'.','');
            $cats = implode(', ', array_map(function($c){ return $c['name']; }, $r['cats_all']));
            $lvls = implode(', ', array_map(function($l){ return $l['name']; }, $r['lvls_all']));
            $acts = implode(', ', array_map(function($a){ return $a['name']; }, ($r['acts_all'] ?? [])));
            fputcsv($out, [$r['title'], $r['author'], $date, $sk, $r['yes'], $r['no'], $cats, $lvls, $acts]);
        }
        fclose($out);
        exit;
    }

}
