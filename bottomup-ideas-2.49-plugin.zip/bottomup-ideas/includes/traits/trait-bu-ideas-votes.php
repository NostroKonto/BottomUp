<?php
if (!defined('ABSPATH')) exit;

trait BU_Ideas_Votes_Trait {
/*** REST ***/
    public static function register_rest_routes(){
        register_rest_route('bu/v1','/ideas', [
            'methods'  => 'GET',
            // Use login check (instead of capability) to avoid 401 for custom roles missing the "read" cap.
            'permission_callback' => function(){ return is_user_logged_in(); },
            'callback' => function($req){
                $level_slug = sanitize_text_field($req->get_param('level'));
                $cat_slug   = sanitize_text_field($req->get_param('cat'));
                $act_slug   = sanitize_text_field($req->get_param('act'));
                $items = self::query_ideas($level_slug, $cat_slug, $act_slug);
                return rest_ensure_response(['ideas'=>$items]);
            }
        ]);
        register_rest_route('bu/v1','/rate/(?P<id>\\d+)', [
            'methods'  => 'POST',
            'permission_callback' => function($req){
                $pid = intval($req['id'] ?? 0);
                if (!$pid) return false;
                if (get_post_type($pid)!==self::CPT) return false;
                return current_user_can('read_post', $pid);
            },
            'callback' => function($req){
                $pid = intval($req['id']);
                if (get_post_type($pid)!==self::CPT) return new \WP_Error('invalid','Ungültige ID', ['status'=>400]);
                if (!current_user_can('read_post', $pid)) return new \WP_Error('forbidden','Keine Berechtigung.', ['status'=>403]);
                $val = intval($req->get_param('value'));
                if ($val<0 || $val>10) return new \WP_Error('range','Wert 0..10', ['status'=>400]);
                $ts = current_time('mysql');
                $round = self::get_round_current($pid);
                $comment = $req->get_param('comment');
                $comment = is_null($comment) ? '' : sanitize_textarea_field($comment);
                if ($val>=8){
                    if ($comment==='') return new \WP_Error('need_comment','Bitte Einwand angeben (max. 280 Zeichen).', ['status'=>400]);
                    if (self::s_len($comment) > 280) $comment = self::s_sub($comment, 0, 280);
                } else {
                    if (self::s_len($comment) > 280) $comment = self::s_sub($comment, 0, 280);
                }
                $uid = get_current_user_id();
                $before = self::get_user_rating_row($pid, $uid, $round);

                $updated = self::meta_json_put_user($pid, self::META_RATINGS, ['value'=>$val,'ts'=>$ts,'comment'=>$comment], $round);

                // Benachrichtigung (Autor der Idee), wenn sich die Bewertung tatsächlich geändert hat
                $after = self::get_user_rating_row($pid, $uid, $round);
                $before_val = is_array($before) ? (string)($before['value'] ?? '') : '';
                $before_comment = is_array($before) ? (string)($before['comment'] ?? '') : '';
                $after_val = is_array($after) ? (string)($after['value'] ?? '') : '';
                $after_comment = is_array($after) ? (string)($after['comment'] ?? '') : '';
                $changed = (!is_array($before)) || ($before_val !== $after_val) || ($before_comment !== $after_comment);

                if ($changed){
                    $vr = self::get_user_vote_row($pid, $uid, $round);
                    $vote_raw = is_array($vr) ? (string)($vr['value'] ?? '') : '';
                    $vote_label = ($vote_raw==='yes' ? 'Ja' : ($vote_raw==='no' ? 'Nein' : ($vote_raw==='undecided' ? 'Unentschieden' : '')));

                    self::notify_my_idea_activity($pid, $uid, 'SK-Bewertung', [
                        'sk_value'   => (string)$val,
                        'vote_value' => $vote_label,
                        'comment'    => (string)$comment,
                    ]);
                }
                list($avg,$sk_n) = self::get_rating_stats($pid, $round);
                list($yes,$no,$vote_n,$undecided) = self::get_vote_stats($pid, $round);
                return rest_ensure_response(['ok'=>true,'updated'=>$updated,'avg'=>$avg,'sk_n'=>$sk_n,'yes'=>$yes,'no'=>$no,'vote_n'=>$vote_n,'undecided'=>$undecided,'round'=>$round]);
            }
        ]);
        register_rest_route('bu/v1','/vote/(?P<id>\\d+)', [
            'methods'  => 'POST',
            'permission_callback' => function($req){
                $pid = intval($req['id'] ?? 0);
                if (!$pid) return false;
                if (get_post_type($pid)!==self::CPT) return false;
                return current_user_can('read_post', $pid);
            },
            'callback' => function($req){
                $pid = intval($req['id']);
                if (get_post_type($pid)!==self::CPT) return new \WP_Error('invalid','Ungültige ID', ['status'=>400]);
                if (!current_user_can('read_post', $pid)) return new \WP_Error('forbidden','Keine Berechtigung.', ['status'=>403]);
                $val = $req->get_param('value');
                $val = ($val==='yes'?'yes':($val==='no'?'no':($val==='undecided'?'undecided':'')));
                if ($val==='') return new \WP_Error('range','Wert yes|no|undecided', ['status'=>400]);
                $ts = current_time('mysql');
                $round = self::get_round_current($pid);
                $comment = $req->get_param('comment');
                $comment = is_null($comment) ? '' : sanitize_textarea_field($comment);
                if ($val==='no'){
                    if ($comment==='') return new \WP_Error('need_comment','Bitte Einwand angeben (max. 280 Zeichen).', ['status'=>400]);
                    if (self::s_len($comment) > 280) $comment = self::s_sub($comment, 0, 280);
                } else {
                    if (self::s_len($comment) > 280) $comment = self::s_sub($comment, 0, 280);
                }
                $uid = get_current_user_id();
                $before = self::get_user_vote_row($pid, $uid, $round);

                $updated = self::meta_json_put_user($pid, self::META_VOTES, ['value'=>$val,'ts'=>$ts,'comment'=>$comment], $round);

                // Benachrichtigung (Autor der Idee), wenn sich die Abstimmung tatsächlich geändert hat
                $after = self::get_user_vote_row($pid, $uid, $round);
                $before_val = is_array($before) ? (string)($before['value'] ?? '') : '';
                $before_comment = is_array($before) ? (string)($before['comment'] ?? '') : '';
                $after_val = is_array($after) ? (string)($after['value'] ?? '') : '';
                $after_comment = is_array($after) ? (string)($after['comment'] ?? '') : '';
                $changed = (!is_array($before)) || ($before_val !== $after_val) || ($before_comment !== $after_comment);

                if ($changed){
                    $vote_label = ($val==='yes' ? 'Ja' : ($val==='no' ? 'Nein' : ($val==='undecided' ? 'Unentschieden' : $val)));
                    $rr = self::get_user_rating_row($pid, $uid, $round);
                    $sk_val = is_array($rr) ? (string)($rr['value'] ?? '') : '';

                    self::notify_my_idea_activity($pid, $uid, 'Abstimmung', [
                        'sk_value'   => $sk_val,
                        'vote_value' => $vote_label,
                        'comment'    => (string)$comment,
                    ]);
                }
                list($avg,$sk_n) = self::get_rating_stats($pid, $round);
                list($yes,$no,$vote_n,$undecided) = self::get_vote_stats($pid, $round);
                return rest_ensure_response(['ok'=>true,'updated'=>$updated,'avg'=>$avg,'sk_n'=>$sk_n,'yes'=>$yes,'no'=>$no,'vote_n'=>$vote_n,'undecided'=>$undecided,'round'=>$round]);
            }
	        ]);

	        // Current state for live UI updates (stats + my values + objections)
	        register_rest_route('bu/v1','/state/(?P<id>\\d+)', [
            'methods'  => 'GET',
            'permission_callback' => function($req){
                $pid = intval($req['id'] ?? 0);
                if (!$pid) return false;
                if (get_post_type($pid)!==self::CPT) return false;
                return current_user_can('read_post', $pid);
            },
            'callback' => function($req){
                $pid = intval($req['id']);
                if (get_post_type($pid)!==self::CPT) return new \WP_Error('invalid','Ungültige ID', ['status'=>400]);
                if (!current_user_can('read_post', $pid)) return new \WP_Error('forbidden','Keine Berechtigung.', ['status'=>403]);
                $round = self::get_round_current($pid);
                list($avg,$sk_n) = self::get_rating_stats($pid, $round);
                list($yes,$no,$vote_n,$undecided) = self::get_vote_stats($pid, $round);
                $uid = get_current_user_id();
                $myR = self::get_user_rating_row($pid, $uid, $round);
                $myV = self::get_user_vote_row($pid, $uid, $round);

                $out = [
                    'ok'        => true,
                    'round'     => $round,
                    'avg'       => is_null($avg) ? null : round(floatval($avg), 1),
                    'sk_n'      => intval($sk_n),
                    'yes'       => intval($yes),
                    'no'        => intval($no),
                    'vote_n'    => intval($vote_n),
                    'undecided' => intval($undecided),
                    'my'        => [
                        'sk'           => $myR && isset($myR['value']) ? intval($myR['value']) : null,
                        'sk_comment'   => $myR && isset($myR['comment']) ? (string)$myR['comment'] : '',
                        'vote'         => $myV && isset($myV['value']) ? (string)$myV['value'] : '',
                        'vote_comment' => $myV && isset($myV['comment']) ? (string)$myV['comment'] : '',
                    ],
                    'objections_html' => self::render_objection_groups_html($pid, $round),
                ];
                return rest_ensure_response($out);
            }
	        ]);
	    }

    /*** Meta JSON helpers ***/
    private static function meta_json_get($post_id,$key){
        $val = get_post_meta($post_id,$key,true);
        if (is_array($val)) return $val;
        if (is_string($val) && $val!==''){
            $d = json_decode($val,true);
            if (is_array($d)) return $d;
        }
        return [];
    }
    private static function meta_json_put_user($post_id,$key,$row, $round=null){
        $rows = self::meta_json_get($post_id, $key);
        $uid = get_current_user_id();
        $round = is_null($round) ? self::get_round_current($post_id) : intval($round);
        if ($round<=0) $round = 1;

        // Ensure row has the standard fields
        $row['user']  = $uid;
        $row['round'] = $round;

        $out=[]; $replaced=false;
        foreach($rows as $r){
            $r_uid = isset($r['user']) ? intval($r['user']) : 0;
            $r_round = isset($r['round']) ? intval($r['round']) : 1; // legacy: no round -> 1
            if($r_uid===$uid && $r_round===$round){
                $out[]=$row;
                $replaced=true;
            } else {
                // normalize legacy rows so future reads work consistently
                if (!isset($r['round'])) $r['round'] = $r_round;
                $out[]=$r;
            }
        }
        if(!$replaced){ $out[]=$row; }
        update_post_meta($post_id, $key, wp_json_encode($out));
        return $replaced;
    }
    private static function filter_round_rows($rows, $round){
        $round = intval($round);
        if ($round<=0) $round = 1;
        $out = [];
        foreach ($rows as $r){
            $r_round = isset($r['round']) ? intval($r['round']) : 1; // legacy -> 1
            if ($r_round === $round) $out[] = $r;
        }
        return $out;
    }
    public static function get_rating_stats($post_id, $round=null){
        $round = is_null($round) ? self::get_round_current($post_id) : intval($round);
        $rows = self::meta_json_get($post_id, self::META_RATINGS);
        $rows = self::filter_round_rows($rows, $round);
        if (empty($rows)) return [null, 0];
        $sum=0; $n=0;
        foreach ($rows as $r){
            if (isset($r['value'])){
                $sum += floatval($r['value']);
                $n++;
            }
        }
        $avg = $n ? ($sum/$n) : null;
        return [$avg, $n];
    }
    public static function get_rating_average($post_id, $round=null){
        return self::get_rating_stats($post_id, $round)[0];
    }
    public static function get_rating_n($post_id, $round=null){
        return self::get_rating_stats($post_id, $round)[1];
    }
    /**
     * Alias for SK-Avg used in Print-Handler (historical name).
     * @param int $post_id
     * @return float|null
     */
    public static function get_avg_rating($post_id){
        return self::get_rating_average($post_id);
    }
	public static function get_vote_stats($post_id, $round=null){
        $round = is_null($round) ? self::get_round_current($post_id) : intval($round);
        $rows = self::meta_json_get($post_id, self::META_VOTES);
        $rows = self::filter_round_rows($rows, $round);
        $yes=0; $no=0; $und=0; $n=0; // vote_n ($n) counts only yes+no; undecided is stored separately
        foreach ($rows as $r){
            if (!isset($r['value'])) continue;
            if ($r['value']==='yes'){ $yes++; $n++; }
            elseif ($r['value']==='no'){ $no++; $n++; }
            elseif ($r['value']==='undecided'){ $und++; }
        }
        return [$yes,$no,$n,$und];
    }
    public static function get_vote_counts($post_id, $round=null){
        $st = self::get_vote_stats($post_id, $round);
        return [$st[0], $st[1]];
    }
    public static function get_vote_n($post_id, $round=null){
        return self::get_vote_stats($post_id, $round)[2];
    }
    public static function get_objection_comments($post_id, $round=null){
        $round = is_null($round) ? self::get_round_current($post_id) : intval($round);
        if ($round<=0) $round = 1;

        $out = [];

        $rs = self::meta_json_get($post_id, self::META_RATINGS);
        $rs = self::filter_round_rows($rs, $round);
        foreach ($rs as $r){
            $val = isset($r['value']) ? intval($r['value']) : 0;
            $c   = isset($r['comment']) ? trim((string)$r['comment']) : '';
            if ($val>=8 && $c!==''){
                $out[] = [
                    'kind' => 'sk',
                    'value'=> $val,
                    'ts'   => isset($r['ts']) ? (string)$r['ts'] : '',
                    'text' => $c,
                ];
            }
        }

        $vs = self::meta_json_get($post_id, self::META_VOTES);
        $vs = self::filter_round_rows($vs, $round);
        foreach ($vs as $r){
            $val = isset($r['value']) ? (string)$r['value'] : '';
            $c   = isset($r['comment']) ? trim((string)$r['comment']) : '';
            if ($val==='no' && $c!==''){
                $out[] = [
                    'kind' => 'no',
                    'value'=> 'no',
                    'ts'   => isset($r['ts']) ? (string)$r['ts'] : '',
                    'text' => $c,
                ];
            }
        }

        usort($out, function($a,$b){
            $ta = strtotime($a['ts'] ?? '') ?: 0;
            $tb = strtotime($b['ts'] ?? '') ?: 0;
            return $tb <=> $ta; // newest first
        });

        return $out;
    }

    /**
     * Get current user's row (rating) for a round.
     */
    public static function get_user_rating_row($post_id, $user_id=null, $round=null){
        $uid = is_null($user_id) ? get_current_user_id() : intval($user_id);
        $round = is_null($round) ? self::get_round_current($post_id) : intval($round);
        $rows = self::meta_json_get($post_id, self::META_RATINGS);
        $rows = self::filter_round_rows($rows, $round);
        foreach ($rows as $r){
            $r_uid = isset($r['user']) ? intval($r['user']) : 0;
            if ($r_uid === $uid) return $r;
        }
        return null;
    }

    /**
     * Get current user's row (vote) for a round.
     */
    public static function get_user_vote_row($post_id, $user_id=null, $round=null){
        $uid = is_null($user_id) ? get_current_user_id() : intval($user_id);
        $round = is_null($round) ? self::get_round_current($post_id) : intval($round);
        $rows = self::meta_json_get($post_id, self::META_VOTES);
        $rows = self::filter_round_rows($rows, $round);
        foreach ($rows as $r){
            $r_uid = isset($r['user']) ? intval($r['user']) : 0;
            if ($r_uid === $uid) return $r;
        }
        return null;
    }

    /**
     * Render grouped objections (SK>=8 and/or vote=no) per user.
     * Returns HTML for insertion into the view page.
     */
    public static function render_objection_groups_html($post_id, $round=null){
        $round = is_null($round) ? self::get_round_current($post_id) : intval($round);
        if ($round<=0) $round = 1;

        $groups = [];

        $rs = self::meta_json_get($post_id, self::META_RATINGS);
        $rs = self::filter_round_rows($rs, $round);
        foreach ($rs as $r){
            $uid = isset($r['user']) ? intval($r['user']) : 0;
            if ($uid<=0) continue;
            $val = isset($r['value']) ? intval($r['value']) : 0;
            $c   = isset($r['comment']) ? trim((string)$r['comment']) : '';
            if ($val>=8 && $c!==''){
                if (!isset($groups[$uid])) $groups[$uid] = ['uid'=>$uid, 'sk'=>null, 'sk_ts'=>'', 'sk_text'=>'', 'no'=>null, 'no_ts'=>'', 'no_text'=>''];
                $groups[$uid]['sk'] = $val;
                $groups[$uid]['sk_ts'] = isset($r['ts']) ? (string)$r['ts'] : '';
                $groups[$uid]['sk_text'] = $c;
            }
        }

        $vs = self::meta_json_get($post_id, self::META_VOTES);
        $vs = self::filter_round_rows($vs, $round);
        foreach ($vs as $r){
            $uid = isset($r['user']) ? intval($r['user']) : 0;
            if ($uid<=0) continue;
            $val = isset($r['value']) ? (string)$r['value'] : '';
            $c   = isset($r['comment']) ? trim((string)$r['comment']) : '';
            if ($val==='no' && $c!==''){
                if (!isset($groups[$uid])) $groups[$uid] = ['uid'=>$uid, 'sk'=>null, 'sk_ts'=>'', 'sk_text'=>'', 'no'=>true, 'no_ts'=>'', 'no_text'=>''];
                $groups[$uid]['no'] = true;
                $groups[$uid]['no_ts'] = isset($r['ts']) ? (string)$r['ts'] : '';
                $groups[$uid]['no_text'] = $c;
            }
        }

        // Filter to only those with any objection
        $groups = array_values(array_filter($groups, function($g){
            return (!is_null($g['sk']) && $g['sk_text']!=='') || (!empty($g['no']) && $g['no_text']!=='');
        }));

        if (empty($groups)){
            return '<p class="description">Noch keine Einwände.</p>';
        }

        // Sort by newest timestamp among items (desc)
        usort($groups, function($a,$b){
            $ta = 0; $tb = 0;
            $ta = max(strtotime($a['sk_ts'] ?? '') ?: 0, strtotime($a['no_ts'] ?? '') ?: 0);
            $tb = max(strtotime($b['sk_ts'] ?? '') ?: 0, strtotime($b['no_ts'] ?? '') ?: 0);
            return $tb <=> $ta;
        });

        $html = '<ul class="bu-objections bu-objections-grouped">';
        foreach ($groups as $g){
            $u = get_userdata(intval($g['uid']));
            $name = $u ? $u->display_name : ('User #'.intval($g['uid']));
            $html .= '<li class="bu-obj-user">';
            $pm_link = '';
            $me = get_current_user_id();
            if ($me && intval($g['uid'])>0){
                // show PM link for every displayed user (even if user == me; opens the message UI)
                $pm_url = self::pm_url($post_id, intval($g['uid']));
                $pm_link = ' <a class="button button-small bu-pm-link" href="'.esc_url($pm_url).'">✉ Private Nachricht</a>';
            }
            $html .= '<div class="bu-obj-header"><strong>'.esc_html($name).'</strong>'.$pm_link.'</div>';
            if (!is_null($g['sk']) && $g['sk_text']!==''){
                $ts = $g['sk_ts'] ? mysql2date('d.m.Y H:i', $g['sk_ts']) : '';
                $html .= '<div class="bu-obj-item bu-obj-sk"><div class="bu-obj-label"><strong>SK '.intval($g['sk']).'</strong> <span class="bu-obj-ts">'.esc_html($ts).'</span></div><div class="bu-obj-text">'.nl2br(esc_html($g['sk_text'])).'</div></div>';
            }
            if (!empty($g['no']) && $g['no_text']!==''){
                $ts = $g['no_ts'] ? mysql2date('d.m.Y H:i', $g['no_ts']) : '';
                $html .= '<div class="bu-obj-item bu-obj-no"><div class="bu-obj-label"><strong>Nein</strong> <span class="bu-obj-ts">'.esc_html($ts).'</span></div><div class="bu-obj-text">'.nl2br(esc_html($g['no_text'])).'</div></div>';
            }
            $html .= '</li>';
        }
        $html .= '</ul>';

        return $html;
    }

    public static function metabox_side_vote(){
        add_meta_box('bu_side_vote','Bewertung & Abstimmung',[__CLASS__,'box_side_vote'],self::CPT,'side','high');
    }
    public static function box_side_vote($post){
        $uid = get_current_user_id();
        $rowsR = self::meta_json_get($post->ID, self::META_RATINGS);
        $rowsV = self::meta_json_get($post->ID, self::META_VOTES);
        $myR = ''; foreach($rowsR as $r){ if(intval($r['user'])===$uid){ $myR=$r['value']; break; } }
        $myV = ''; foreach($rowsV as $v){ if(intval($v['user'])===$uid){ $myV=$v['value']; break; } }
        echo '<div class="bu-rating-wrap">';
        echo '<div class="bu-rating-row"><label for="bu_sk_value">SK-Wert:</label> <select id="bu_sk_value" name="bu_sk_value">';
        echo '<option value="">—</option>'; for($i=0;$i<=10;$i++){ echo '<option value="'.$i.'"'.selected($myR,(string)$i,false).'>'.$i.'</option>'; } echo '</select></div>';
        echo '<div class="bu-vote-row"><label>Abstimmung:</label> ';
        echo '<label><input type="radio" name="bu_vote" value="yes"'.checked($myV,'yes',false).'> Ja</label> ';
        echo '<label><input type="radio" name="bu_vote" value="no"'.checked($myV,'no',false).'> Nein</label> ';
        echo '<label><input type="radio" name="bu_vote" value="undecided"'.checked($myV,'undecided',false).'> unentschieden</label></div>';
        echo '<p class="description bu-vote-stats">Eigene Eingabe wird beim Speichern gesichert; frühere Eingabe desselben Users wird überschrieben.</p>';
        echo '</div>';
    }
    public static function save_side_vote($pid,$post){
        if ($post->post_type!==self::CPT) return;
        $uid = get_current_user_id();
        $ts = current_time('mysql');
        if (isset($_POST['bu_sk_value']) && $_POST['bu_sk_value']!==''){
            $val = max(0,min(10,intval($_POST['bu_sk_value'])));
            self::meta_json_put_user($pid, self::META_RATINGS, ['user'=>$uid,'value'=>$val,'ts'=>$ts]);
        }
        if (isset($_POST['bu_vote'])){
            $v = ($_POST['bu_vote']==='yes')?'yes':(($_POST['bu_vote']==='no')?'no':(($_POST['bu_vote']==='undecided')?'undecided':''));
            if ($v!==''){
                self::meta_json_put_user($pid, self::META_VOTES, ['user'=>$uid,'value'=>$v,'ts'=>$ts]);
            }
        }
    }

}
