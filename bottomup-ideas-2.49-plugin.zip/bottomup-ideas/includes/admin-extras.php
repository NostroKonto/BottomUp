<?php
if (!defined('ABSPATH')) exit;

if (!function_exists('bu_render_new_idea_toolbar_v2')) {
    function bu_render_new_idea_toolbar_v2(){
        static $done = false;
        if ($done) return; $done = true;
        if (!current_user_can('edit_posts')) return;
        $url = admin_url('post-new.php?post_type=bu_idea');
        echo '<div class="bu-list-toolbar bu-v2" style="display:flex;justify-content:flex-end;align-items:center;margin:6px 0;">'
            . '<a class="button button-primary bu-new-idea-btn" href="' . esc_url($url) . '">+ Neue Idee</a>'
            . '</div>';
    }
}


// Strong page matching + force option
add_action('current_screen', function($screen){
    $id = is_object($screen) ? (string)$screen->id : '';
    $get_page = isset($_GET['page']) ? sanitize_key($_GET['page']) : '';
    $match = (strpos($id,'bottomup')!==false && strpos($id,'ideas')!==false) || ($get_page==='bottomup_ideas');
    $force = isset($_GET['bu_force_button']) && $_GET['bu_force_button'];
    if ($match || $force){
        add_action('in_admin_header', 'bu_render_new_idea_toolbar_v2', 0);
        add_action('all_admin_notices', 'bu_render_new_idea_toolbar_v2', 0);
    }
}, 10);


add_action('admin_enqueue_scripts', function($hook){
    if (isset($_GET['page']) && $_GET['page']==='bottomup_ideas'){
        wp_enqueue_script('bu-place-button', plugins_url('assets/js/bu-place-button.js', BU_IDEAS_FILE), array('jquery'), '1.14', true);
    }
});


add_action('admin_enqueue_scripts', function($hook){
    if (isset($_GET['page']) && $_GET['page'] === 'bottomup_ideas'){
        wp_enqueue_script('bu-csv-export', plugins_url('assets/js/bu-csv-export.js', BU_IDEAS_FILE), array('jquery'), '1.14', true);
    }
});


// BU_FORCE_CSS_ALWAYS_BLUE
add_action('admin_head', function(){
    if (!is_admin()) return;
    $page = isset($_GET['page']) ? sanitize_key($_GET['page']) : '';
    if ($page !== 'bottomup_ideas') return;
    echo '<style>
    .bu-new-idea-pill { background:#2271b1 !important; border-color:#2271b1 !important; color:#fff !important; border-radius:9999px !important; padding:6px 14px !important; font-weight:600 !important; text-decoration:none !important; vertical-align:middle !important; display:inline-block !important; }
    .bu-new-idea-pill:hover, .bu-new-idea-pill:focus { background:#135e96 !important; border-color:#135e96 !important; color:#fff !important; outline:none !important; box-shadow:none !important; text-decoration:none !important; }
    #bu-ideas-container .row-actions a, #bu-ideas-container .row-actions a:focus, #bu-ideas-container .row-actions a:hover, #bu-ideas-container .row-actions button, #bu-ideas-container .row-actions button:focus, #bu-ideas-container .row-actions button:hover, #bu-ideas-container .row-actions .button, #bu-ideas-container .row-actions .button-link { background:transparent !important; border:0 !important; box-shadow:none !important; outline:none !important; padding:0 !important; -webkit-appearance:none !important; appearance:none !important; text-decoration:none !important; }
    #bu-ideas-container .row-actions .dashicons, #bu-ideas-container td.bu-actions-cell .dashicons { font-size:5px !important; width:5px !important; height:5px !important; line-height:5px !important; display:inline-block !important; }
    #bu-ideas-container .row-actions { display:inline-flex !important; gap:2px !important; }
    </style>';
});


// BU_PRINT_TITLE_FILENAME_1919
add_action('admin_head', function(){
    if (!is_admin()) return;
    $page = isset($_GET['page']) ? sanitize_key($_GET['page']) : '';
    if ($page !== 'bottomup_print') return;
    $post_id = isset($_GET['post']) ? intval($_GET['post']) : 0;
    if (!$post_id) return;
    $raw = get_the_title($post_id);
    if (!$raw) return;
    $file = wp_strip_all_tags($raw);
    $file = preg_replace('/[\\\\\/\:\*\?\"\<\>\|]/', ' ', $file);
    $file = trim(preg_replace('/\s+/', ' ', $file));
    echo '<script>document.title=' . json_encode($file) . ';</script>';
}, 0);


add_action('admin_enqueue_scripts', function($hook){
    $page = isset($_GET['page']) ? sanitize_key($_GET['page']) : '';
    if ($page === 'bottomup_ideas'){
        wp_enqueue_script('bu-place-button', plugins_url('assets/js/bu-place-button.js', BU_IDEAS_FILE), array('jquery'), BU_IDEAS_VERSION, true);
        wp_enqueue_script('bu-csv-export', plugins_url('assets/js/bu-csv-export.js', BU_IDEAS_FILE), array('jquery'), BU_IDEAS_VERSION, true);
    }
    // helpers are needed both in the list and in the view ("Neue Runde starten" modal)
    if (in_array($page, ['bottomup_ideas','bottomup_view'], true)){
        wp_enqueue_script('bu-ideas-helpers', plugins_url('assets/js/bu-ideas-helpers.js', BU_IDEAS_FILE), array('jquery'), BU_IDEAS_VERSION, true);
    }
    if ($page === 'bottomup_print'){
        wp_enqueue_script('bu-print-helpers', plugins_url('assets/js/bu-print-helpers.js', BU_IDEAS_FILE), array('jquery'), BU_IDEAS_VERSION, true);
    }
});


// Server-side print toolbar with 'Zurück zur Liste'
if (!function_exists('bu_render_print_toolbar')) {
    function bu_render_print_toolbar(){
        if (!is_admin()) return;
        $page = isset($_GET['page']) ? sanitize_key($_GET['page']) : '';
        if ($page !== 'bottomup_print') return;
        $back = admin_url('admin.php?page=bottomup_ideas');
        echo '<div class="bu-print-toolbar" style="position:sticky;top:0;z-index:1000;background:#fff;padding:8px 0;margin:0 0 8px 0;border-bottom:1px solid #ddd;">'
           . '<a class="button" href="' . esc_url($back) . '">&larr; Zurück zur Liste</a>'
           . '</div>';
    }
}
add_action('in_admin_header', 'bu_render_print_toolbar', 0);
add_action('all_admin_notices', 'bu_render_print_toolbar', 0);

// Ensure visibility and spacing in admin for print page
add_action('admin_head', function(){
    if (!is_admin()) return;
    $page = isset($_GET['page']) ? sanitize_key($_GET['page']) : '';
    if ($page !== 'bottomup_print') return;
    echo '<style>
        .wrap { margin-top: 8px; }
        .bu-print-toolbar .button { font-weight:600; }
        #bu-print-root { margin-top: 8px; }
    </style>';
});
