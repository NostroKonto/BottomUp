<?php
if (!defined('ABSPATH')) exit;

if (!class_exists('BU_Ideas')):
class BU_Ideas {
    // Trait modules (split aus bottomup-ideas.php)
    use BU_Ideas_Votes_Trait;
    use BU_Ideas_Versions_Trait;
    use BU_Ideas_Tasks_Trait;
    use BU_Ideas_Print_Trait;
    use BU_Ideas_Export_Trait;
    use BU_Ideas_PM_Trait;
    use BU_Ideas_Kiosk_Trait;

    const CPT     = 'bu_idea';
    const TAX_CAT = 'bu_category';
    const TAX_LVL = 'bu_level';
    const TAX_ACT = 'bu_action';
    const CPT_TASK = 'bu_task';

    const TASK_META_IDEA = '_bu_task_idea';
    const TASK_META_STATUS = '_bu_task_status'; // todo|doing|done
    const TASK_META_DUE = '_bu_task_due';       // YYYY-MM-DD
    const TASK_META_ASSIGNEE = '_bu_task_assignee'; // user id (int) or '' for none
    const TASK_META_CHECKLIST = '_bu_task_checklist'; // json
    const TASK_META_ATTACH = '_bu_task_attachments'; // json (array of urls)
    const TASK_META_COMMENTS = '_bu_task_comments'; // json
    const TASK_META_ORDER = '_bu_task_order'; // int per status

    
    const META_SUMMARY = '_bu_summary';
    const META_PRO1 = '_bu_pro1'; const META_PRO2 = '_bu_pro2'; const META_PRO3 = '_bu_pro3';
    const META_CON1 = '_bu_con1'; const META_CON2 = '_bu_con2'; const META_CON3 = '_bu_con3';
    const META_RATINGS = '_bu_sk_ratings'; // JSON: [{user, value, ts}]
    const META_VOTES   = '_bu_votes';      // JSON: [{user, value:"yes"|"no", ts}]
    const META_STATE   = '_bu_state';     // active|done
    const META_ARCHIVED = '_bu_archived'; // 0|1

    const META_ROUND  = '_bu_round_current'; // int, default 1
    const META_ROUND_DEADLINES = '_bu_round_deadlines'; // JSON map: {round:int => 'YYYY-MM-DD HH:MM:SS'}


    const VERS_TABLE  = 'bu_idea_versions';
    const VERS_DB_VER = 1;

    const PM_TABLE = 'bu_messages';
    const PM_GROUP_TABLE = 'bu_message_groups';
    const PM_DB_VER = 1;


    private static $selftest_errors = [];

    // Dedup within a single request (avoid duplicate mails on same save)
    private static $notif_dedup = [];

    private static function s_len($s){ return function_exists('mb_strlen') ? mb_strlen($s) : strlen($s); }
    private static function s_sub($s,$start,$len){ return function_exists('mb_substr') ? mb_substr($s,$start,$len) : substr($s,$start,$len); }

    public static function init(){
        add_action('init', [__CLASS__, 'register_cpt']);
        add_action('init', [__CLASS__, 'register_taxonomies']);
        add_action('init', [__CLASS__, 'ensure_actions_exist'], 20);
        add_action('init', [__CLASS__, 'register_meta_fields']);
        add_action('init', [__CLASS__, 'ensure_levels_exist'], 20);

        add_action('admin_init', [__CLASS__, 'ensure_levels_exist']);
        add_action('admin_init', [__CLASS__, 'pm_ensure_tables']);
        add_action('admin_init', [__CLASS__, 'versions_ensure_tables']);
        add_action('admin_init', [__CLASS__, 'handle_kiosk_toggle']);
        add_action('admin_menu', [__CLASS__, 'menu']);
        add_action('admin_menu', [__CLASS__, 'kiosk_admin_menu'], 999);
        add_action('admin_head', [__CLASS__, 'suppress_admin_notices'], 0);
        add_action('admin_head', [__CLASS__, 'suppress_admin_notice_css'], 1);
        add_action('admin_head', [__CLASS__, 'kiosk_floating_button_css'], 2);
        add_action('admin_footer', [__CLASS__, 'kiosk_floating_button'], 9999);
        add_action('admin_post_bottomup_export', [__CLASS__, 'export_csv']);
        add_action('admin_post_nopriv_bottomup_export', function(){ wp_die('Keine Berechtigung.'); });
        add_action('admin_post_bottomup_print_idea', [__CLASS__, 'handle_print_idea']);
        add_action('admin_post_bu_start_round', [__CLASS__, 'handle_start_round']);
        add_action('admin_post_nopriv_bottomup_print_idea', function(){ wp_die('Keine Berechtigung.'); });
        add_action('wp_ajax_bu_toggle_favorite', [__CLASS__, 'ajax_toggle_favorite']);
        add_action('wp_ajax_bu_task_create', [__CLASS__, 'ajax_task_create']);
        add_action('wp_ajax_bu_task_update', [__CLASS__, 'ajax_task_update']);
        add_action('wp_ajax_bu_task_reorder', [__CLASS__, 'ajax_task_reorder']);
        add_action('wp_ajax_bu_task_add_comment', [__CLASS__, 'ajax_task_add_comment']);
        add_action('wp_ajax_bu_task_toggle_check', [__CLASS__, 'ajax_task_toggle_check']);
        add_action('wp_ajax_bu_versions_list', [__CLASS__, 'ajax_versions_list']);
        add_action('wp_ajax_bu_version_diff', [__CLASS__, 'ajax_version_diff']);

        // Benachrichtigungen (E-Mails) & Templates
        add_action('init', [__CLASS__, 'ensure_notification_templates'], 30);
        // Favoriten: Frist verstrichen (Cron)
        add_action('init', [__CLASS__, 'ensure_deadline_cron'], 35);
        add_action('bu_check_favorite_deadlines', [__CLASS__, 'cron_check_favorite_deadlines']);
        add_action('post_updated', [__CLASS__, 'notify_favorite_post_updated'], 10, 3);
        add_action('transition_post_status', [__CLASS__, 'notify_new_idea_published'], 10, 3);
        // Debug/Diagnose: Mail-Fehler erfassen + Testmail-Action
        add_action('wp_mail_failed', [__CLASS__, 'capture_wp_mail_failed'], 10, 1);
        add_action('admin_post_bu_send_test_mail', [__CLASS__, 'handle_send_test_mail']);
        add_action('admin_post_nopriv_bu_send_test_mail', function(){ wp_die('Keine Berechtigung.'); });

    // Ensure important metaboxes are not hidden in Gutenberg/Screen Options
    add_filter('default_hidden_meta_boxes', function($hidden, $screen){
        if (!empty($screen->post_type) && $screen->post_type === self::CPT){
            $hidden = array_diff($hidden, ['bu_side_level','bu_side_cat','bu_side_actions']);
        }
        return $hidden;
    }, 10, 2);
    add_filter('hidden_meta_boxes', function($hidden, $screen){
        if (!empty($screen->post_type) && $screen->post_type === self::CPT){
            $hidden = array_diff($hidden, ['bu_side_level','bu_side_cat','bu_side_actions']);
        }
        return $hidden;
    }, 10, 2);

    // Force Gutenberg document sidebar open so side metaboxes show up
    add_action('admin_footer-post.php', function(){
        $screen = get_current_screen();
        if ($screen && $screen->post_type === self::CPT){
            echo "<script id='bu_force_sidebar'>(function(){try{if(window.wp&&wp.data){wp.data.dispatch('core/edit-post').openGeneralSidebar('edit-post/document');}}catch(e){}})();</script>";
        }
    });
add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue_admin_assets']);
        add_action('rest_api_init', [__CLASS__, 'register_rest_routes']);

        add_action('add_meta_boxes', [__CLASS__, 'metabox_info']);
        add_action('save_post', [__CLASS__, 'save_meta_info'], 10, 2);

        // Metaboxen für Ebene/Kategorie -> sehr früh + normal
        add_action('add_meta_boxes', [__CLASS__, 'metabox_side_tax'], 1);
        add_action('add_meta_boxes_'.self::CPT, [__CLASS__, 'metabox_side_tax'], 1);
        add_action('add_meta_boxes', [__CLASS__, 'metabox_side_tax'], 100);
        add_action('add_meta_boxes_'.self::CPT, [__CLASS__, 'metabox_side_tax'], 100);
        add_action('save_post', [__CLASS__, 'save_side_tax'], 10, 2);
        add_action('save_post', [__CLASS__, 'enforce_single_level'], 99, 2);
        add_action('save_post', [__CLASS__, 'validate_required_taxonomies'], 100, 2);
        // v2.21: Bewertungs/Abstimmungs-Metabox im Editor deaktiviert (nur im Ansichtsmodus via REST + Modals)
        add_action('add_meta_boxes', [__CLASS__, 'metabox_side_state'], 120);
        add_action('add_meta_boxes_'.self::CPT, [__CLASS__, 'metabox_side_state'], 120);
        // v2.21: save_side_vote deaktiviert (Editor darf SK/Vote nicht direkt speichern)
        add_action('save_post', [__CLASS__, 'save_side_state'], 10, 2);

        // Native CPT-Liste -> unsere Liste
        add_action('load-edit.php', [__CLASS__, 'redirect_native_list']);

        // Excerpt raus
        add_action('add_meta_boxes_'.self::CPT, function(){ remove_meta_box('postexcerpt', self::CPT, 'normal'); });

        // Zurück-zur-Liste Button
        add_action('edit_form_after_title', [__CLASS__, 'render_back_bar']);
        add_action('admin_footer', [__CLASS__, 'admin_footer_back_button']);
        add_action('admin_bar_menu', [__CLASS__, 'adminbar_back'], 80);
        // Seitenleisten-Boxen fixieren + Screen Options dürfen unsere Boxen nicht verstecken
        add_filter('get_user_option_closedpostboxes_bu_idea', function($v){ return []; });
        // Metabox-Layout erzwingen: Kategorie → Ebene → Bewertung in der rechten Sidebar (auch wenn ein User die Boxen früher verschoben hat)
        add_filter('get_user_option_meta-box-order_'.self::CPT, function($order){
            return [
                'side' => 'submitdiv,bu_side_actions,bu_side_cat,bu_side_level,bu_side_state',
                'normal' => 'bu_info_box',
                'advanced' => '',
            ];
        });
        add_action('admin_footer', [__CLASS__, 'lock_side_sortables']);

        // Systemcheck nur auf unseren Seiten
        add_action('current_screen', [__CLASS__, 'maybe_selftest_on_our_pages']);

        // Fallback während der Metabox-Phase: native Boxen entfernen, unsere sicher hinzufügen
        add_action('do_meta_boxes', function($post_type){
            if ($post_type !== self::CPT) return;
            remove_meta_box('tagsdiv-'.self::TAX_CAT, self::CPT, 'side'); // non-hierarchical native
            remove_meta_box(self::TAX_LVL.'div',       self::CPT, 'side'); // hierarchical native
            // add_meta_box('bu_side_level','Ebene',     [__CLASS__,'box_side_level'], self::CPT, 'side', 'high'); // removed duplicate; keep sidebar metabox from metabox_side_tax
            // add_meta_box('bu_side_cat',  'Kategorie', [__CLASS__,'box_side_cat'],   self::CPT, 'side', 'high'); // removed duplicate; keep sidebar metabox from metabox_side_tax
        }, 20);

        register_activation_hook(BU_IDEAS_FILE, [__CLASS__, 'on_activate']);
        add_action('admin_notices', [__CLASS__, 'activation_notice']);
    }

    /*** Register ***/
    public static function register_cpt(){
        register_post_type(self::CPT, [
            'labels' => [
                'name'          => 'Bottom Up',
                'menu_name'     => 'BottomUp',
                'singular_name' => 'Beitrag',
                'add_new_item'  => 'Neue Idee',
                'edit_item'     => 'Idee bearbeiten',
                'all_items'     => 'Ideen',
            ],
            'public'             => false,
            'publicly_queryable' => false,
            'show_ui'            => true,
            'show_in_menu'       => false,
            'show_in_rest'       => true,
            'supports'           => ['title','editor','author'],
        ]);

        // Tasks (Trello-ähnlich) als eigener CPT, damit Meta/Kommentare/Anhänge sauber gespeichert werden können
        register_post_type(self::CPT_TASK, [
            'labels' => [
                'name'          => 'Tasks',
                'singular_name' => 'Task',
            ],
            'public'             => false,
            'publicly_queryable' => false,
            'show_ui'            => false, // kein eigenes Menü – wird über BottomUp->Tasks verwaltet
            'show_in_menu'       => false,
            'show_in_rest'       => false,
            'supports'           => ['title','editor','author'],
        ]);
    }
    public static function register_taxonomies(){
        // Kategorien (nur auswählen in Ideen-Editor; Anlegen/Ändern nur Admin via Submenü)
        register_taxonomy(self::TAX_CAT, [self::CPT], [
            'labels' => [
                'name'          => 'Kategorien',
                'singular_name' => 'Kategorie',
                'search_items'  => 'Kategorien suchen',
                'all_items'     => 'Alle Kategorien',
                'edit_item'     => 'Kategorie bearbeiten',
                'update_item'   => 'Kategorie aktualisieren',
                'add_new_item'  => 'Neue Kategorie hinzufügen',
                'new_item_name' => 'Neuer Kategoriename',
                'menu_name'     => 'Kategorien',
            ],
            'hierarchical'      => false,
            'show_ui'           => true,
            'show_in_rest'      => false,  // verhindert Gutenberg-Term-UI (inkl. "Add new …") im Editor
            'meta_box_cb'       => false,  // verhindert Classic-Term-Metabox im Editor
            'show_admin_column' => true,
            'capabilities'      => [
                'manage_terms' => 'manage_options',
                'edit_terms'   => 'manage_options',
                'delete_terms' => 'manage_options',
                'assign_terms' => 'edit_posts',
            ],
        ]);

        // Ebenen (hierarchisch; nur auswählen im Ideen-Editor; Anlegen/Ändern nur Admin via Submenü)
        register_taxonomy(self::TAX_LVL, [self::CPT], [
            'labels' => [
                'name'          => 'Ebenen',
                'singular_name' => 'Ebene',
                'search_items'  => 'Ebenen suchen',
                'all_items'     => 'Alle Ebenen',
                'parent_item'   => 'Übergeordnete Ebene',
                'parent_item_colon' => 'Übergeordnete Ebene:',
                'edit_item'     => 'Ebene bearbeiten',
                'update_item'   => 'Ebene aktualisieren',
                'add_new_item'  => 'Neue Ebene hinzufügen',
                'new_item_name' => 'Neuer Ebenenname',
                'menu_name'     => 'Ebenen',
            ],
            'hierarchical'      => true,
            'show_ui'           => true,
            'show_in_rest'      => false,  // verhindert Gutenberg-Term-UI (inkl. "Add new …") im Editor
            'meta_box_cb'       => false,  // verhindert Classic-Term-Metabox im Editor
            'show_admin_column' => true,
            'capabilities'      => [
                'manage_terms' => 'manage_options',
                'edit_terms'   => 'manage_options',
                'delete_terms' => 'manage_options',
                'assign_terms' => 'edit_posts',
            ],
        ]);

        // Vorstösse/Aktionen (mehrfach auswählbar; Verwaltung nur im BottomUp Admin-Tab)
        register_taxonomy(self::TAX_ACT, [self::CPT], [
            'labels' => [
                'name'          => 'Vorstösse/Aktionen',
                'singular_name' => 'Vorstoss/Aktion',
                'search_items'  => 'Suchen',
                'all_items'     => 'Alle Vorstösse/Aktionen',
                'edit_item'     => 'Bearbeiten',
                'update_item'   => 'Aktualisieren',
                'add_new_item'  => 'Neu hinzufügen',
                'new_item_name' => 'Neuer Name',
                'menu_name'     => 'Vorstösse/Aktionen',
            ],
            'hierarchical'      => false,
            'show_ui'           => false,
            'show_in_rest'      => false,
            'meta_box_cb'       => false,
            'show_admin_column' => false,
            'capabilities'      => [
                'manage_terms' => 'manage_options',
                'edit_terms'   => 'manage_options',
                'delete_terms' => 'manage_options',
                'assign_terms' => 'edit_posts',
            ],
        ]);
;
    }
    public static function register_meta_fields(){
        foreach ([self::META_SUMMARY,self::META_PRO1,self::META_PRO2,self::META_PRO3,self::META_CON1,self::META_CON2,self::META_CON3] as $k){
            register_post_meta(self::CPT, $k, ['type'=>'string','single'=>true,'show_in_rest'=>true]);
        }
        register_post_meta(self::CPT, self::META_RATINGS, ['type'=>'string','single'=>true,'show_in_rest'=>true]);
        register_post_meta(self::CPT, self::META_VOTES,   ['type'=>'string','single'=>true,'show_in_rest'=>true]);
        register_post_meta(self::CPT, self::META_STATE,   ['type'=>'string','single'=>true,'show_in_rest'=>true]);
        register_post_meta(self::CPT, self::META_ARCHIVED,['type'=>'string','single'=>true,'show_in_rest'=>true]);
    }

    public static function ensure_levels_exist(){
        $needles = [
            'national' => 'National',
            'kanton'   => 'Kanton',
            'stadt'    => 'Stadt',
            'lokal'    => 'Lokal',
        ];
        $terms = get_terms(['taxonomy'=>self::TAX_LVL,'hide_empty'=>false]);
        $found = ['national'=>false,'kanton'=>false,'stadt'=>false,'lokal'=>false];
        if (!is_wp_error($terms)){
            foreach($terms as $t){
                $n = strtolower($t->name);
                $s = strtolower($t->slug);
                foreach ($found as $k=>$_){
                    if (strpos($n,$k)!==false || strpos($s,$k)!==false){ $found[$k] = true; }
                }
            }
        }
        foreach ($needles as $slug=>$name){
            if (!$found[$slug] && !term_exists($slug, self::TAX_LVL)){
                wp_insert_term($name, self::TAX_LVL, ['slug'=>$slug]);
            }
        }
    }


    public static function ensure_actions_exist(){
        // v2.21: Default Vorstösse/Aktionen nur einmalig seeden (Option-Flag), damit
        // bewusst gelöschte Einträge nicht bei jedem Seitenaufruf wieder erscheinen.
        $seeded = get_option('bu_actions_seeded_v', '');
        if ($seeded) return;

        $defaults = [
            'Volksinitiative',
            'Referendum',
            'Vernehmlassung',
            'Petition',
            'Motion',
            'Postulat',
            'Interpellation',
            'Anfrage',
            'Fragestunde',
        ];

        foreach ($defaults as $name){
            if ( ! term_exists($name, self::TAX_ACT) ){
                wp_insert_term($name, self::TAX_ACT);
            }
        }

        // Version als Marker speichern
        $ver = defined('BU_IDEAS_VERSION') ? BU_IDEAS_VERSION : '2.21';
        update_option('bu_actions_seeded_v', $ver);
    }



    /*** Admin menu ***/
    public static function menu(){
        add_menu_page('BottomUp','BottomUp','read','bottomup_dashboard',[__CLASS__,'render_dashboard'],'dashicons-lightbulb',5);
        add_submenu_page('bottomup_dashboard','Dashboard','Dashboard','read','bottomup_dashboard',[__CLASS__,'render_dashboard']);
        add_submenu_page('bottomup_dashboard','Ideen','Ideen','read','bottomup_ideas',[__CLASS__,'render_ideas']);
        add_submenu_page('bottomup_dashboard','Tasks','Tasks','read','bottomup_tasks',[__CLASS__,'render_tasks_overview']);
        add_submenu_page('bottomup_dashboard','Nachrichten','Nachrichten','read','bottomup_messages',[__CLASS__,'render_messages']);
        add_submenu_page('bottomup_dashboard','Einstellungen','Einstellungen','read','bottomup_settings',[__CLASS__,'render_settings']);

        // Aufgaben-Board (im Menü verborgen)
        add_submenu_page('bottomup_dashboard','Tasks Board','Tasks Board','read','bottomup_tasks_board',[__CLASS__,'render_tasks_board']);
        add_action('admin_head', function(){ remove_submenu_page('bottomup_dashboard','bottomup_tasks_board'); });

        // „Ansehen“ Route (im Menü verborgen)
        add_submenu_page('bottomup_dashboard','Ansehen','Ansehen','read','bottomup_view',[__CLASS__,'render_view']);
        add_action('admin_head', function(){ remove_submenu_page('bottomup_dashboard','bottomup_view'); });

        // Admin (CSV Export / Ebenen / Kategorien) – nur Admin
        if (current_user_can('manage_options')){
            add_submenu_page('bottomup_dashboard','Admin','Admin','manage_options','bottomup_admin',[__CLASS__,'render_admin']);
        }
    }

    /*** Assets ***/
    public static function enqueue_admin_assets($hook){
        if (!is_admin()) return;
        $page   = isset($_GET['page']) ? sanitize_key($_GET['page']) : '';
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        $is_cpt = ($screen && isset($screen->post_type) && $screen->post_type===self::CPT);
        if (in_array($page, ['bottomup_dashboard','bottomup_ideas','bottomup_export','bottomup_view','bottomup_tasks','bottomup_tasks_board','bottomup_messages','bottomup_settings','bottomup_admin'], true) || $is_cpt){
            wp_enqueue_style('dashicons');
            wp_enqueue_style('bu-admin', plugins_url('assets/css/admin.css', BU_IDEAS_FILE), [], BU_IDEAS_VERSION);
            wp_enqueue_script('bu-dashboard', plugins_url('assets/js/bu-dashboard.js', BU_IDEAS_FILE), ['jquery','jquery-ui-sortable'], BU_IDEAS_VERSION, true);
            wp_localize_script('bu-dashboard','BU_LIST', [
                'rest'       => esc_url_raw(rest_url('bu/v1/')),
                'nonce'      => wp_create_nonce('wp_rest'),
                'ideas_url'  => admin_url('admin.php?page=bottomup_ideas'),
                'dash_url'   => admin_url('admin.php?page=bottomup_dashboard'),
                'view_base'  => admin_url('admin.php?page=bottomup_view'),
                'export_url' => admin_url('admin-post.php?action=bottomup_export'),
                'ajax_url'  => admin_url('admin-ajax.php'),
                'where'      => $page ?: ($is_cpt ? 'edit' : ''),
                'fav_nonce'  => wp_create_nonce('bu_toggle_favorite'),
                'nonces'     => [
                    'rest'     => wp_create_nonce('wp_rest'),
                    'favorite' => wp_create_nonce('bu_toggle_favorite'),
                ],
            ]);

            // Dashboard: Prozess-Widget
            if ($page === 'bottomup_dashboard'){
                wp_enqueue_style('bu-process', plugins_url('assets/css/process.css', BU_IDEAS_FILE), [], BU_IDEAS_VERSION);
                wp_enqueue_script('bu-process', plugins_url('assets/js/bu-process.js', BU_IDEAS_FILE), ['jquery'], BU_IDEAS_VERSION, true);
                wp_localize_script('bu-process','BU_PROCESS', [
                    'steps' => self::get_process_steps(),
                ]);
            }



// Admin: Prozess-Editor (BottomUp Admin → Prozess)
if ($page === 'bottomup_admin'){
    $tab = isset($_GET['tab']) ? sanitize_key($_GET['tab']) : '';
    if ($tab === 'process'){
        wp_enqueue_style('bu-process-admin', plugins_url('assets/css/process-admin.css', BU_IDEAS_FILE), [], BU_IDEAS_VERSION);
        wp_enqueue_script('bu-process-admin', plugins_url('assets/js/bu-process-admin.js', BU_IDEAS_FILE), ['jquery','jquery-ui-sortable'], BU_IDEAS_VERSION, true);
        wp_localize_script('bu-process-admin','BU_PROC_ADMIN', [
            'confirm_remove' => 'Schritt wirklich löschen?',
        ]);
    }
}
            // Versions / Iterations (Runden)
            if ($page === 'bottomup_view' || $is_cpt){
                $idea_id = isset($_GET['post']) ? intval($_GET['post']) : 0;
                wp_enqueue_script('bu-versions', plugins_url('assets/js/bu-versions.js', BU_IDEAS_FILE), ['jquery'], BU_IDEAS_VERSION, true);
                wp_localize_script('bu-versions','BU_VERS', [
                    'ajax_url'  => admin_url('admin-ajax.php'),
                    'nonce'     => wp_create_nonce('bu_versions'),
                    'nonces'    => [ 'ajax' => wp_create_nonce('bu_versions') ],
                    'idea'      => $idea_id,
                    'readonly'  => $idea_id ? (self::is_idea_archived($idea_id) ? 1 : 0) : 0,
                    'start_url' => $idea_id ? wp_nonce_url(admin_url('admin-post.php?action=bu_start_round&post='.$idea_id), 'bu_start_round_'.$idea_id) : '',
                ]);
            }
                        // Tasks (Trello-ähnlich)
            if (in_array($page, ['bottomup_tasks','bottomup_tasks_board'], true)){
                wp_enqueue_style('bu-tasks', plugins_url('assets/css/tasks.css', BU_IDEAS_FILE), [], BU_IDEAS_VERSION);
                wp_enqueue_script('bu-tasks', plugins_url('assets/js/tasks.js', BU_IDEAS_FILE), ['jquery'], BU_IDEAS_VERSION, true);
                wp_localize_script('bu-tasks','BU_TASKS', [
                    'ajax_url' => admin_url('admin-ajax.php'),
                    'nonce'    => wp_create_nonce('bu_tasks'),
                    'nonces'   => [ 'ajax' => wp_create_nonce('bu_tasks') ],
                    'idea'     => isset($_GET['idea']) ? intval($_GET['idea']) : 0,
                    'readonly' => (isset($_GET['idea']) && self::is_idea_archived(intval($_GET['idea']))) ? 1 : 0,
                ]);
            }
            if ($page === 'bottomup_tasks'){
                wp_enqueue_script('bu-tasks-list', plugins_url('assets/js/tasks-list.js', BU_IDEAS_FILE), ['jquery'], BU_IDEAS_VERSION, true);
            }

wp_enqueue_script('bu-rating', plugins_url('assets/js/sk-rating.js', BU_IDEAS_FILE), ['jquery'], '1.15', true);
        }
    }

    
    /*** Favoriten (pro Nutzer) ***/
    public static function get_user_favorites(){
        $uid = get_current_user_id();
        if (!$uid) return [];
        $f = get_user_meta($uid, 'bu_favorites', true);
        if (!is_array($f)) $f = [];
        return array_values(array_unique(array_map('intval', $f)));
    }

    private static function is_idea_archived($iid){
        $iid = intval($iid);
        if (!$iid) return false;
        $arch = get_post_meta($iid, self::META_ARCHIVED, true);
        return ($arch === '1' || $arch === 1);
    }



    public static function ajax_toggle_favorite(){
        if (!current_user_can('read')) wp_send_json_error(['message'=>'Keine Berechtigung.'], 403);
        $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : (isset($_POST['_ajax_nonce']) ? sanitize_text_field($_POST['_ajax_nonce']) : '');
if (!$nonce || !wp_verify_nonce($nonce, 'bu_toggle_favorite')) {
            wp_send_json_error(['message'=>'Nonce invalid'], 403);
        }
        $pid = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
        if (!$pid || get_post_type($pid)!==self::CPT) wp_send_json_error(['message'=>'Ungültige ID.'], 400);

        $uid = get_current_user_id();

        $favs = self::get_user_favorites();
        $is_fav = false;
        $activity = '';

        if (in_array($pid, $favs, true)){
            $favs = array_values(array_diff($favs, [$pid]));
            update_user_meta($uid, 'bu_favorites', $favs);
            $is_fav = false;
            $activity = 'Favorit entfernt';
        } else {
            $favs[] = $pid;
            $favs = array_values(array_unique($favs));
            update_user_meta($uid, 'bu_favorites', $favs);
            $is_fav = true;
            $activity = 'Favorit hinzugefügt';
        }

        // Benachrichtigung an Autor (wenn aktiviert)
        self::notify_my_idea_activity($pid, $uid, $activity, [
            'sk_value'   => '',
            'vote_value' => '',
            'comment'    => '',
        ]);

        wp_send_json_success(['is_fav'=>$is_fav]);
    }



    /*** Benachrichtigungen (E-Mail) ***/
    public static function ensure_notification_templates(){
        $tpl = get_option('bu_notify_templates', []);
        if (!is_array($tpl)) $tpl = [];
        $defaults = self::default_notification_templates();
        $changed = false;

        foreach ($defaults as $k => $d){
            if (!isset($tpl[$k]) || !is_array($tpl[$k])){
                $tpl[$k] = $d;
                $changed = true;
                continue;
            }
            if (!isset($tpl[$k]['subject']) || trim((string)$tpl[$k]['subject']) === ''){
                $tpl[$k]['subject'] = $d['subject'];
                $changed = true;
            }
            if (!isset($tpl[$k]['body']) || trim((string)$tpl[$k]['body']) === ''){
                $tpl[$k]['body'] = $d['body'];
                $changed = true;
            }
        }

        if ($changed){
            update_option('bu_notify_templates', $tpl);
        }
    }

    private static function default_notification_templates(){
        $site = get_bloginfo('name');
        return [
            'fav_changes' => [
                'subject' => '['.$site.'] Favorit aktualisiert: {idea_title}',
                'body'    => "Hallo {recipient_name},\n\nEine Idee, die du als Favorit markiert hast, wurde aktualisiert.\n\nIdee: {idea_title}\nAktion: {action}\nDetails: {fields}\nVon: {actor_name}\n\nLink: {idea_url}\n\n--\n{site_name}"
            ],
            'fav_tasks' => [
                'subject' => '['.$site.'] Favoriten-Task aktualisiert: {idea_title}',
                'body'    => "Hallo {recipient_name},\n\nEin Task einer Idee, die du als Favorit markiert hast, wurde aktualisiert.\n\nIdee: {idea_title}\nAktion: {action}\nDetails: {fields}\nVon: {actor_name}\n\nLink: {idea_url}\n\n--\n{site_name}"
            ],
            'new_idea' => [
                'subject' => '['.$site.'] Neue Idee: {idea_title}',
                'body'    => "Hallo {recipient_name},\n\nEs wurde eine neue Idee erstellt.\n\nIdee: {idea_title}\nEbene: {level}\nKategorie: {category}\nVon: {actor_name}\n\nLink: {idea_url}\n\n--\n{site_name}"
            ],
            'my_idea_activity' => [
                'subject' => '['.$site.'] Neue Abstimmung/Kommentar zu deiner Idee: {idea_title}',
                'body'    => "Hallo {recipient_name},\n\nEs gibt eine neue Aktivität zu deiner Idee.\n\nIdee: {idea_title}\nVon: {actor_name}\nAktivität: {activity}\nSK: {sk_value}\nVote: {vote_value}\nKommentar: {comment}\n\nLink: {idea_url}\n\n--\n{site_name}"
            ],
        ];
    }


    private static function notification_template_sections(){
        // Reihenfolge gemäss BRD: Favoriten-Änderungen → Aktivität auf meinen Ideen → Neue Ideen
        return [
            'fav_changes'      => 'Änderungen an Favoriten-Ideen',
            'fav_tasks'        => 'Änderungen an Favoriten-Tasks',
            'my_idea_activity' => 'Abstimmungen & Kommentare zu meinen Ideen',
            'new_idea'         => 'Neue Ideen (Ebenen/Kategorien)',
        ];
    }

    private static function get_notification_templates(){
        $tpl = get_option('bu_notify_templates', []);
        return is_array($tpl) ? $tpl : [];
    }

    private static function get_notification_template($key){
        $tpls = self::get_notification_templates();
        if (isset($tpls[$key]) && is_array($tpls[$key])){
            return array_merge(['subject'=>'','body'=>''], $tpls[$key]);
        }
        $defs = self::default_notification_templates();
        return $defs[$key] ?? ['subject'=>'','body'=>''];
    }

    private static function tpl_render($str, $vars){
        if (!is_string($str) || $str === '') return '';
        if (!is_array($vars)) $vars = [];
        foreach ($vars as $k => $v){
            $str = str_replace('{'.$k.'}', (string)$v, $str);
        }
        // Remove unreplaced placeholders
        $str = preg_replace('/\{[a-zA-Z0-9_\-]+\}/', '', $str);
        return $str;
    }

    private static function user_notifications_enabled_for($user_id, $template_key){
        $user_id = intval($user_id);
        if ($user_id <= 0) return false;

        // Sonderfall: „Neue Ideen“ wurde ab v2.27 in Ebenen/Kategorien getrennt
        if ($template_key === 'new_idea'){
            $lv = get_user_meta($user_id, 'bu_notify_new_levels_on', true);
            $ct = get_user_meta($user_id, 'bu_notify_new_cats_on', true);
            $on = (($lv === '1' || $lv === 1 || $lv === true) || ($ct === '1' || $ct === 1 || $ct === true));

            if (!$on){
                // Abwärtskompatibilität: wenn altes Flag aktiv ist UND die neuen Flags noch nicht existieren
                $legacy = get_user_meta($user_id, 'bu_notify_new_ideas', true);
                $legacy_on = ($legacy === '1' || $legacy === 1 || $legacy === true);

                if ($legacy_on && function_exists('metadata_exists')){
                    $has_lv = metadata_exists('user', $user_id, 'bu_notify_new_levels_on');
                    $has_ct = metadata_exists('user', $user_id, 'bu_notify_new_cats_on');
                    if (!$has_lv && !$has_ct) $on = true;
                } elseif ($legacy_on){
                    $on = true;
                }
            }
            return $on;
        }

        $map = [
            'fav_changes'      => 'bu_notify_fav_changes',
            'fav_tasks'        => 'bu_notify_fav_tasks',
            'my_idea_activity' => 'bu_notify_my_idea_activity',
        ];
        $meta_key = $map[$template_key] ?? '';
        if (!$meta_key) return false;

        // Abwärtskompatibilität: „Favoriten-Tasks“ folgt standardmässig dem alten Flag „Favoriten-Ideen",
        // solange der User die neue Einstellung noch nie gespeichert hat.
        if ($template_key === 'fav_tasks' && function_exists('metadata_exists')){
            if (!metadata_exists('user', $user_id, 'bu_notify_fav_tasks')){
                return self::user_notifications_enabled_for($user_id, 'fav_changes');
            }
        }

        $v = get_user_meta($user_id, $meta_key, true);
        return ($v === '1' || $v === 1 || $v === true);
    }


    /**
     * Favoriten-Ideen: Task-Bewegungen (Statuswechsel) – pro User granular aktivierbar.
     * Standard (wenn User-Meta noch nicht existiert): alle Bewegungen aktiv.
     */
    private static function fav_task_move_allowed_keys(){
        return [
            'todo_doing',
            'doing_done',
            'todo_done',
            'doing_todo',
            'done_doing',
            'done_todo',
        ];
    }

    private static function fav_task_status_label($st){
        $st = sanitize_key((string)$st);
        if ($st === 'doing') return 'Doing';
        if ($st === 'done') return 'Done';
        return 'ToDo';
    }

    private static function user_fav_task_moves_enabled_list($user_id){
        $user_id = intval($user_id);
        if ($user_id <= 0) return [];

        $allowed = self::fav_task_move_allowed_keys();

        // Default: alle aktiv, solange Meta nicht existiert (Abwärtskompatibilität)
        if (function_exists('metadata_exists') && !metadata_exists('user', $user_id, 'bu_notify_fav_task_moves')){
            return $allowed;
        }

        $v = get_user_meta($user_id, 'bu_notify_fav_task_moves', true);
        if (!is_array($v)) return $allowed;

        $v = array_values(array_filter(array_map('sanitize_key', $v)));
        if (empty($v)) return [];

        return array_values(array_intersect($allowed, $v));
    }

    private static function user_notifications_enabled_for_fav_task_move($user_id, $from, $to){
        $user_id = intval($user_id);
        if ($user_id <= 0) return false;

        // Grundvoraussetzung: „Änderungen an Favoriten-Tasks“ aktiv
        if (!self::user_notifications_enabled_for($user_id, 'fav_tasks')) return false;

        $from = sanitize_key((string)$from);
        $to   = sanitize_key((string)$to);
        if ($from === '' || $to === '' || $from === $to) return false;

        $key = $from.'_'.$to;
        $enabled = self::user_fav_task_moves_enabled_list($user_id);
        return in_array($key, $enabled, true);
    }

    /**
     * Favoriten-Tasks: Task-Events (neuer Task, Kommentar, Inhalt/Datum/sonstige Änderungen)
     */
    private static function fav_task_event_allowed_keys(){
        return [
            'create',
            'comment',
            'content',
            'due',
            'other',
        ];
    }

    private static function user_fav_task_events_enabled_list($user_id){
        $user_id = intval($user_id);
        if ($user_id <= 0) return [];
        $allowed = self::fav_task_event_allowed_keys();

        // Default: alle aktiv, solange Meta nicht existiert
        if (function_exists('metadata_exists') && !metadata_exists('user', $user_id, 'bu_notify_fav_task_events')){
            return $allowed;
        }

        $v = get_user_meta($user_id, 'bu_notify_fav_task_events', true);
        if (!is_array($v)) return $allowed;
        $v = array_values(array_filter(array_map('sanitize_key', $v)));
        if (empty($v)) return [];
        return array_values(array_intersect($allowed, $v));
    }

    private static function user_notifications_enabled_for_fav_task_event($user_id, $event_key){
        $user_id = intval($user_id);
        if ($user_id <= 0) return false;

        // Grundvoraussetzung: „Änderungen an Favoriten-Tasks“ aktiv
        if (!self::user_notifications_enabled_for($user_id, 'fav_tasks')) return false;

        $event_key = sanitize_key((string)$event_key);
        if ($event_key === '') return false;
        $enabled = self::user_fav_task_events_enabled_list($user_id);
        return in_array($event_key, $enabled, true);
    }

    private static function idea_tasks_board_url($idea_id){
        return admin_url('admin.php?page=bottomup_tasks_board&idea='.intval($idea_id));
    }

    private static function notify_favorite_watchers_task_moved($idea_id, $task_id, $from, $to, $actor_id=0){
        $idea_id = intval($idea_id);
        $task_id = intval($task_id);
        if ($idea_id <= 0 || $task_id <= 0) return;

        $from = sanitize_key((string)$from);
        $to   = sanitize_key((string)$to);
        if ($from === '' || $to === '' || $from === $to) return;

        $dedup_key = $idea_id.'-'.$task_id.'-'.$from.'-'.$to;
        if (self::notif_once('fav_task_move', $dedup_key)) return;

        $uids = self::get_favorite_user_ids_for_idea($idea_id);
        if (empty($uids)) return;

        $actor_id = intval($actor_id);
        $actor_name = 'System';
        if ($actor_id){
            $u = get_userdata($actor_id);
            if ($u) $actor_name = $u->display_name;
        }

        $task_title = get_the_title($task_id);
        if (!$task_title) $task_title = 'Task #'.$task_id;

        $from_lab = self::fav_task_status_label($from);
        $to_lab   = self::fav_task_status_label($to);

        $vars = [
            'idea_id'    => $idea_id,
            'idea_title' => get_the_title($idea_id) ?: ('Idee #'.$idea_id),
            // Für Task-Meldungen direkt auf das Board verlinken
            'idea_url'   => self::idea_tasks_board_url($idea_id),
            'action'     => 'Task bewegt: '.$from_lab.' → '.$to_lab,
            'fields'     => 'Task: '.$task_title.' (ID '.$task_id.')',
            'actor_name' => $actor_name,
        ];

        foreach ($uids as $uid){
            if (!self::user_notifications_enabled_for_fav_task_move($uid, $from, $to)) continue;
            self::send_notification_mail($uid, 'fav_tasks', $vars);
        }
    }

    private static function notify_favorite_watchers_task_event($idea_id, $task_id, $event_key, $details, $actor_id=0){
        $idea_id = intval($idea_id);
        $task_id = intval($task_id);
        if ($idea_id <= 0 || $task_id <= 0) return;

        $event_key = sanitize_key((string)$event_key);
        if ($event_key === '') return;

        $dedup_key = $idea_id.'-'.$task_id.'-'.$event_key.'-'.md5((string)$details);
        if (self::notif_once('fav_task_event', $dedup_key)) return;

        $uids = self::get_favorite_user_ids_for_idea($idea_id);
        if (empty($uids)) return;

        $actor_id = intval($actor_id);
        $actor_name = 'System';
        if ($actor_id){
            $u = get_userdata($actor_id);
            if ($u) $actor_name = $u->display_name;
        }

        $task_title = get_the_title($task_id);
        if (!$task_title) $task_title = 'Task #'.$task_id;

        $labels = [
            'create'  => 'Task angelegt',
            'comment' => 'Task kommentiert',
            'content' => 'Task-Inhalt geändert',
            'due'     => 'Task-Datum geändert',
            'other'   => 'Task aktualisiert',
        ];
        $action = $labels[$event_key] ?? 'Task aktualisiert';

        $details = trim((string)$details);
        if ($details === '') $details = 'Task: '.$task_title.' (ID '.$task_id.')';

        $vars = [
            'idea_id'    => $idea_id,
            'idea_title' => get_the_title($idea_id) ?: ('Idee #'.$idea_id),
            'idea_url'   => self::idea_tasks_board_url($idea_id),
            'action'     => $action,
            'fields'     => 'Task: '.$task_title.' (ID '.$task_id.')'."\n".$details,
            'actor_name' => $actor_name,
        ];

        foreach ($uids as $uid){
            if (!self::user_notifications_enabled_for_fav_task_event($uid, $event_key)) continue;
            self::send_notification_mail($uid, 'fav_tasks', $vars);
        }
    }

    private static function notification_mail_headers($template_key, $user_id=0){
        $headers = ['Content-Type: text/plain; charset=UTF-8'];

        // Optional: eigener Absender (Admin -> Templates)
        $from_name  = (string)get_option('bu_notify_from_name', '');
        $from_email = (string)get_option('bu_notify_from_email', '');

        $from_name = trim($from_name);
        $from_email = trim($from_email);

        if ($from_name === ''){
            $from_name = (string)get_bloginfo('name');
        }

        if (!is_email($from_email)){
            // Fallback: noreply@<domain> wenn möglich
            $host = (string)parse_url(home_url(), PHP_URL_HOST);
            $host = preg_replace('/^www\./i', '', $host);
            if ($host && strpos($host, '.') !== false && strpos($host, ':') === false){
                $cand = 'noreply@'.$host;
                if (is_email($cand)) $from_email = $cand;
            }
        }

        if (!is_email($from_email)){
            $from_email = (string)get_option('admin_email');
        }

        if (is_email($from_email)){
            $headers[] = 'From: '.sanitize_text_field($from_name).' <'.sanitize_email($from_email).'>';
            $headers[] = 'Reply-To: '.sanitize_text_field($from_name).' <'.sanitize_email($from_email).'>';
        }

        // Diagnose: Mails markieren (nur intern; wird auch bei wp_mail_failed mitgegeben)
        $headers[] = 'X-BottomUp-Notification: '.sanitize_key((string)$template_key);
        if (intval($user_id) > 0){
            $headers[] = 'X-BottomUp-Recipient-ID: '.intval($user_id);
        }

        return $headers;
    }

    private static function send_notification_mail($user_id, $template_key, $vars){
        $user = get_userdata(intval($user_id));
        if (!$user || empty($user->user_email)) return false;

        if (!self::user_notifications_enabled_for($user_id, $template_key)) return false;

        $tpl = self::get_notification_template($template_key);

        $base_vars = [
            'site_name'      => get_bloginfo('name'),
            'recipient_name' => $user->display_name ?: ('User #'.intval($user_id)),
        ];
        $vars = array_merge($base_vars, is_array($vars) ? $vars : []);

        $subject = trim(self::tpl_render($tpl['subject'] ?? '', $vars));
        $body    = trim(self::tpl_render($tpl['body'] ?? '', $vars));

        if ($subject === '') $subject = '['.get_bloginfo('name').'] Benachrichtigung';
        if ($body === '') $body = 'Benachrichtigung';

        $headers = self::notification_mail_headers($template_key, $user_id);
        $ok = wp_mail($user->user_email, $subject, $body, $headers);

        // Status für Diagnose in User-Settings speichern
        if ($ok){
            update_user_meta(intval($user_id), 'bu_notify_last_success', current_time('mysql'));
        } else {
            update_user_meta(intval($user_id), 'bu_notify_last_fail', current_time('mysql'));
        }

        return $ok;
    }

    public static function capture_wp_mail_failed($wp_error){
        if (!is_wp_error($wp_error)) return;

        // WP packs details into error data
        $data = $wp_error->get_error_data();
        if (!is_array($data)) $data = [];

        $headers = $data['headers'] ?? [];
        $headers_txt = '';
        if (is_array($headers)){
            $headers_txt = implode("\n", array_map('strval', $headers));
        } elseif (is_string($headers)){
            $headers_txt = $headers;
        }

        // Nur unsere Benachrichtigungs-Mails speichern
        if (stripos($headers_txt, 'X-BottomUp-Notification:') === false){
            return;
        }

        // Recipient-ID aus Header extrahieren (wenn vorhanden)
        $recipient_id = 0;
        if (preg_match('/X-BottomUp-Recipient-ID:\s*(\d+)/i', $headers_txt, $m)){
            $recipient_id = intval($m[1]);
        }

        $to = '';
        if (!empty($data['to'])){
            if (is_array($data['to'])){
                $to = implode(', ', array_map('strval', $data['to']));
            } else {
                $to = (string)$data['to'];
            }
        }

        $subject = isset($data['subject']) ? (string)$data['subject'] : '';
        $msg = (string)$wp_error->get_error_message();

        $template_key = '';
        if (preg_match('/X-BottomUp-Notification:\s*([a-z0-9_\-]+)/i', $headers_txt, $m2)){
            $template_key = sanitize_key($m2[1]);
        }

        $to_domain = '';
        if (!empty($to)){
            $first = trim(explode(',', (string)$to)[0]);
            if (preg_match('/@([A-Z0-9\.\-]+\.[A-Z]{2,})/i', $first, $m3)){
                $to_domain = strtolower($m3[1]);
            }
        }

        $from_header = '';
        if (preg_match('/^From:\s*(.+)$/mi', $headers_txt, $m4)){
            $from_header = trim($m4[1]);
        }


        $payload = [
            'time'    => current_time('mysql'),
            'to'      => $to,
            'subject' => $subject,
            'error'   => $msg,
            'template_key' => $template_key,
            'to_domain'    => $to_domain,
            'from_header'  => $from_header,
        ];

        // pro User (wenn möglich) + global
        if ($recipient_id > 0){
            set_transient('bu_last_mail_error_'.$recipient_id, $payload, 6 * HOUR_IN_SECONDS);
        }
        set_transient('bu_last_mail_error_global', $payload, 6 * HOUR_IN_SECONDS);
    }

    public static function handle_send_test_mail(){
        if (!current_user_can('read')) wp_die('Keine Berechtigung.');

        check_admin_referer('bu_send_test_mail');

        $uid = get_current_user_id();
        $u = get_userdata($uid);
        if (!$u || empty($u->user_email)){
            wp_die('Keine E-Mail-Adresse beim Benutzer hinterlegt.');
        }

        $subject = '['.get_bloginfo('name').'] BottomUp Test-Mail';
        $body = "Hallo ".($u->display_name ?: ('User #'.$uid)).",\n\n";
        $body .= "Dies ist eine Test-Mail von BottomUp (Benachrichtigungen).\n";
        $body .= "Zeitpunkt: ".current_time('d.m.Y H:i')."\n";
        $body .= "Empfänger: ".$u->user_email."\n\n";
        $body .= "Wenn diese Mail nicht ankommt, liegt es meist an der Mail-Konfiguration von WordPress/Server (SMTP).\n\n";
        $body .= "--\n".get_bloginfo('name');

        $headers = self::notification_mail_headers('test', $uid);
        $ok = wp_mail($u->user_email, $subject, $body, $headers);

        $flash = [
            'ok'   => $ok ? 1 : 0,
            'time' => current_time('mysql'),
            'msg'  => $ok ? 'Test-Mail wurde gesendet. Bitte prüfe auch den Spam-Ordner.' : 'Test-Mail konnte nicht gesendet werden.',
        ];
        if (!$ok){
            $err = get_transient('bu_last_mail_error_'.$uid);
            if (is_array($err) && !empty($err['error'])){
                $flash['msg'] .= ' Fehler: '.$err['error'];
            }
        }

        set_transient('bu_test_mail_flash_'.$uid, $flash, 2 * MINUTE_IN_SECONDS);

        $redir = add_query_arg([
            'page' => 'bottomup_settings',
            'tab'  => 'notifications',
            'test' => 1,
        ], admin_url('admin.php'));
        wp_safe_redirect($redir);
        exit;
    }

    private static function notif_is_deduped($bucket, $key){
        if (!isset(self::$notif_dedup[$bucket])) self::$notif_dedup[$bucket] = [];
        return isset(self::$notif_dedup[$bucket][$key]);
    }
    private static function notif_mark_dedup($bucket, $key){
        if (!isset(self::$notif_dedup[$bucket])) self::$notif_dedup[$bucket] = [];
        self::$notif_dedup[$bucket][$key] = true;
    }


    private static function notif_once($bucket, $key){
        // returns true if already handled in this request (i.e., should skip)
        if (!is_scalar($key)) $key = wp_json_encode($key);
        $key = (string)$key;
        if (self::notif_is_deduped($bucket, $key)) return true;
        self::notif_mark_dedup($bucket, $key);
        return false;
    }

    private static function get_favorite_user_ids_for_idea($idea_id){
        global $wpdb;
        $idea_id = intval($idea_id);
        if ($idea_id <= 0) return [];
        $like = '%i:'.$idea_id.';%';
        $tbl = $wpdb->usermeta;
        $rows = $wpdb->get_col($wpdb->prepare(
            "SELECT user_id FROM {$tbl} WHERE meta_key=%s AND meta_value LIKE %s",
            'bu_favorites',
            $like
        ));
        if (!is_array($rows)) return [];
        $ids = array_values(array_unique(array_map('intval', $rows)));
        $ids = array_values(array_filter($ids));
        return $ids;
    }

    private static function idea_admin_view_url($idea_id){
        return admin_url('admin.php?page=bottomup_view&post='.intval($idea_id));
    }

    private static function notify_favorite_watchers($idea_id, $action_label, $actor_id=0, $extra_vars=[]){
        $idea_id = intval($idea_id);
        if ($idea_id <= 0) return;
        $actor_id = intval($actor_id);

        $uids = self::get_favorite_user_ids_for_idea($idea_id);
        if (empty($uids)) return;

        $actor_name = 'System';
        if ($actor_id){
            $u = get_userdata($actor_id);
            if ($u) $actor_name = $u->display_name;
        }

        $vars = array_merge([
            'idea_id'    => $idea_id,
            'idea_title' => get_the_title($idea_id) ?: ('Idee #'.$idea_id),
            'idea_url'   => self::idea_admin_view_url($idea_id),
            'action'     => (string)$action_label,
            'fields'     => '',
            'actor_name' => $actor_name,
        ], is_array($extra_vars) ? $extra_vars : []);

        foreach ($uids as $uid){
            self::send_notification_mail($uid, 'fav_changes', $vars);
        }
    }

    public static function notify_favorite_post_updated($post_ID, $post_after, $post_before){
        if (!is_object($post_after) || !is_object($post_before)) return;
        if ($post_after->post_type !== self::CPT) return;

        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (wp_is_post_autosave($post_ID) || wp_is_post_revision($post_ID)) return;
        if (isset($post_after->post_status) && $post_after->post_status === 'auto-draft') return;

        $changed = [];
        if ((string)$post_after->post_title !== (string)$post_before->post_title) $changed[] = 'Titel';
        if ((string)$post_after->post_content !== (string)$post_before->post_content) $changed[] = 'Beschreibung';

        if (empty($changed)) return;

        $dedup_key = intval($post_ID);
        if (self::notif_once('fav_content', $dedup_key)) return;

        self::notify_favorite_watchers($post_ID, 'Inhalt aktualisiert', get_current_user_id(), [
            'fields' => implode(', ', $changed),
        ]);
    }

    /**
     * Cron scheduling for favorite deadlines.
     * Runs hourly (WP-Cron) and sends a notification when the current round deadline of a favorited idea has passed.
     */
    public static function ensure_deadline_cron(){
        if (!function_exists('wp_next_scheduled') || !function_exists('wp_schedule_event')) return;
        if (!wp_next_scheduled('bu_check_favorite_deadlines')){
            // Start a few minutes later to avoid burst right on activation
            wp_schedule_event(time() + 300, 'hourly', 'bu_check_favorite_deadlines');
        }
    }

    public static function cron_check_favorite_deadlines(){
        global $wpdb;
        if (!$wpdb) return;

        $now = current_time('timestamp');
        // Performance: nur User berücksichtigen, die Favoriten-Benachrichtigungen aktiv haben.
        // (Cron bleibt stündlich.)
        $tbl = $wpdb->usermeta;
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT f.user_id, f.meta_value\n".
            "FROM {$tbl} f\n".
            "INNER JOIN {$tbl} n ON n.user_id=f.user_id AND n.meta_key=%s AND n.meta_value=%s\n".
            "WHERE f.meta_key=%s",
            'bu_notify_fav_changes',
            '1',
            'bu_favorites'
        ));

        if (!is_array($rows) || empty($rows)) return;

        foreach ($rows as $r){
            $uid = intval($r->user_id);
            if ($uid <= 0) continue;

            $favs = maybe_unserialize($r->meta_value);
            if (!is_array($favs) || empty($favs)) continue;

            $sent_map = get_user_meta($uid, 'bu_notify_deadline_sent', true);
            if (!is_array($sent_map)) $sent_map = [];
            $changed = false;

            $keep_keys = [];

            foreach ($favs as $iid_raw){
                $iid = intval($iid_raw);
                if ($iid <= 0) continue;
                if (get_post_type($iid) !== self::CPT) continue;

                $round = self::get_round_current($iid);
                if ($round <= 0) $round = 1;

                // Für Aufräumen: pro favorisierte Idee nur den Key der aktuellen Runde behalten.
                $keep_keys[$iid . ':' . $round] = true;

                $deadline_mysql = self::get_round_deadline($iid, $round);
                if (!$deadline_mysql){
                    continue;
                }
                $dl_ts = strtotime($deadline_mysql);
                if (!$dl_ts) continue;

                $key = $iid . ':' . $round;
                $already = isset($sent_map[$key]) ? intval($sent_map[$key]) : 0;

                if ($now < $dl_ts){
                    // Deadline (wieder) in Zukunft: alte Markierung entfernen, wenn sich die Deadline geändert hat
                    if ($already && $already !== $dl_ts){
                        unset($sent_map[$key]);
                        $changed = true;
                    }
                    continue;
                }

                // Deadline erreicht/verstrichen
                if ($already === $dl_ts) continue; // bereits für diese Deadline gemeldet

                $vars = [
                    'idea_id'    => $iid,
                    'idea_title' => get_the_title($iid) ?: ('Idee #'.$iid),
                    'idea_url'   => self::idea_admin_view_url($iid),
                    'action'     => 'Frist verstrichen',
                    'fields'     => 'Frist: '.self::fmt_round_deadline($deadline_mysql).' (Runde #'.intval($round).')',
                    'actor_name' => 'System',
                ];

                self::send_notification_mail($uid, 'fav_changes', $vars);

                $sent_map[$key] = $dl_ts;
                $changed = true;
            }

            // Aufräumen: bu_notify_deadline_sent nicht wachsen lassen
            if (!empty($sent_map)){
                foreach (array_keys($sent_map) as $k){
                    if (!isset($keep_keys[$k])){
                        unset($sent_map[$k]);
                        $changed = true;
                    }
                }
            }

            if ($changed){
                update_user_meta($uid, 'bu_notify_deadline_sent', $sent_map);
            }
        }
    }


    public static function notify_new_idea_published($new_status, $old_status, $post){
        if (!is_object($post)) return;
        if ($post->post_type !== self::CPT) return;
        if ($new_status !== 'publish' || $old_status === 'publish') return;

        $idea_id = intval($post->ID);
        if ($idea_id <= 0) return;

        $lvl_ids = wp_get_post_terms($idea_id, self::TAX_LVL, ['fields'=>'ids']);
        if (is_wp_error($lvl_ids) || !is_array($lvl_ids)) $lvl_ids = [];
        $cat_ids = wp_get_post_terms($idea_id, self::TAX_CAT, ['fields'=>'ids']);
        if (is_wp_error($cat_ids) || !is_array($cat_ids)) $cat_ids = [];

        $lvl_all = [];
        foreach ($lvl_ids as $lid){
            $lid = intval($lid);
            if (!$lid) continue;
            $lvl_all[] = $lid;
            $anc = get_ancestors($lid, self::TAX_LVL);
            if (is_array($anc)) $lvl_all = array_merge($lvl_all, array_map('intval', $anc));
        }
        $lvl_all = array_values(array_unique(array_filter(array_map('intval', $lvl_all))));
        $cat_ids = array_values(array_unique(array_filter(array_map('intval', $cat_ids))));

        $lvl_name = '';
        if (!empty($lvl_ids)){
            $t = get_term(intval($lvl_ids[0]), self::TAX_LVL);
            if ($t && !is_wp_error($t)) $lvl_name = $t->name;
        }
        $cat_name = '';
        if (!empty($cat_ids)){
            $t = get_term(intval($cat_ids[0]), self::TAX_CAT);
            if ($t && !is_wp_error($t)) $cat_name = $t->name;
        }

        $author_id = intval($post->post_author);
        $actor_name = 'System';
        if ($author_id){
            $u = get_userdata($author_id);
            if ($u) $actor_name = $u->display_name;
        }

        $vars = [
            'idea_id'    => $idea_id,
            'idea_title' => get_the_title($idea_id) ?: ('Idee #'.$idea_id),
            'idea_url'   => self::idea_admin_view_url($idea_id),
            'level'      => $lvl_name,
            'category'   => $cat_name,
            'actor_name' => $actor_name,
        ];

        $subscribers = get_users([
            'meta_query' => [
                'relation' => 'OR',
                ['key'=>'bu_notify_new_levels_on','value'=>'1','compare'=>'='],
                ['key'=>'bu_notify_new_cats_on','value'=>'1','compare'=>'='],
                // Legacy key (vor v2.27)
                ['key'=>'bu_notify_new_ideas','value'=>'1','compare'=>'='],
            ],
            'fields'     => ['ID'],
            'number'     => 5000,
        ]);

        if (!is_array($subscribers) || empty($subscribers)) return;

        foreach ($subscribers as $u){
            $uid = isset($u->ID) ? intval($u->ID) : 0;
            if (!$uid) continue;

            $sel_lvls = get_user_meta($uid, 'bu_notify_new_levels', true);
            if (!is_array($sel_lvls)) $sel_lvls = [];
            $sel_lvls = array_values(array_unique(array_filter(array_map('intval', $sel_lvls))));

            $sel_cats = get_user_meta($uid, 'bu_notify_new_cats', true);
            if (!is_array($sel_cats)) $sel_cats = [];
            $sel_cats = array_values(array_unique(array_filter(array_map('intval', $sel_cats))));

            // Neue (v2.27) Schalter
            $lv_on = (get_user_meta($uid, 'bu_notify_new_levels_on', true) === '1');
            $cat_on = (get_user_meta($uid, 'bu_notify_new_cats_on', true) === '1');

            // Abwärtskompatibilität: altes Flag aktiviert „beides“, solange die neuen Flags noch nicht existieren
            $legacy_new = (get_user_meta($uid, 'bu_notify_new_ideas', true) === '1');
            if ($legacy_new && !$lv_on && !$cat_on){
                if (function_exists('metadata_exists')){
                    $has_lv = metadata_exists('user', $uid, 'bu_notify_new_levels_on');
                    $has_cat = metadata_exists('user', $uid, 'bu_notify_new_cats_on');
                    if (!$has_lv && !$has_cat){
                        $lv_on = true;
                        $cat_on = true;
                    }
                } else {
                    $lv_on = true;
                    $cat_on = true;
                }
            }

            $should_send = false;

            if ($lv_on){
                $match_lvl = true;
                if (!empty($sel_lvls)){
                    $match_lvl = (count(array_intersect($sel_lvls, $lvl_all)) > 0);
                }

                if ($cat_on){
                    $match_cat = true;
                    if (!empty($sel_cats)){
                        $match_cat = (count(array_intersect($sel_cats, $cat_ids)) > 0);
                    }
                    $should_send = ($match_lvl && $match_cat);
                } else {
                    $should_send = $match_lvl;
                }
            } elseif ($cat_on){
                $match_cat = true;
                if (!empty($sel_cats)){
                    $match_cat = (count(array_intersect($sel_cats, $cat_ids)) > 0);
                }
                $should_send = $match_cat;
            }

            if ($should_send){
                self::send_notification_mail($uid, 'new_idea', $vars);
            }
        }
    }

    public static function notify_my_idea_activity($idea_id, $actor_id, $activity, $data=[]){
        $idea_id = intval($idea_id);
        $actor_id = intval($actor_id);
        if ($idea_id <= 0 || $actor_id <= 0) return;

        $author_id = intval(get_post_field('post_author', $idea_id));
        if ($author_id <= 0) return;

        $actor = get_userdata($actor_id);
        $actor_name = $actor ? $actor->display_name : ('User #'.$actor_id);

        $vars = array_merge([
            'idea_id'     => $idea_id,
            'idea_title'  => get_the_title($idea_id) ?: ('Idee #'.$idea_id),
            'idea_url'    => self::idea_admin_view_url($idea_id),
            'actor_name'  => $actor_name,
            'activity'    => (string)$activity,
            'sk_value'    => '',
            'vote_value'  => '',
            'comment'     => '',
        ], is_array($data) ? $data : []);

        self::send_notification_mail($author_id, 'my_idea_activity', $vars);
    }


/*** Native CPT-Liste -> unsere Liste ***/
    public static function redirect_native_list(){
        if ( ! is_admin() ) return;
        if ( ! function_exists('get_current_screen') ) return;
        $screen = get_current_screen(); if (!$screen) return;
        if ($screen->id === 'edit-'.self::CPT || (isset($_GET['post_type']) && $_GET['post_type']===self::CPT)) {
            wp_safe_redirect( admin_url('admin.php?page=bottomup_ideas') );
            exit;
        }
    }

    /** Hilfsfunktion: Level-Slugs auf vorhandene Begriffe mappen (bevorzugt Begriffe mit Posts) */
    private static function find_level_terms_map(){
        $candidates = ['national'=>'National','kanton'=>'Kanton','stadt'=>'Stadt','lokal'=>'Lokal'];
        $map = [];
        $terms = get_terms(['taxonomy'=>self::TAX_LVL,'hide_empty'=>false]);
        if (is_wp_error($terms)) $terms = [];
        foreach ($candidates as $needle=>$label){
            $best_slug = null; $best_count = -1;
            foreach ($terms as $t){
                $n=strtolower($t->name); $s=strtolower($t->slug);
                if (strpos($n,$needle)!==false || strpos($s,$needle)!==false){
                    $q = new \WP_Query([
                        'post_type'=>self::CPT,'post_status'=>'any','fields'=>'ids',
                        'tax_query'=>[['taxonomy'=>self::TAX_LVL,'field'=>'term_id','terms'=>[$t->term_id]]],
                        'posts_per_page'=>1,'no_found_rows'=>true
                    ]);
                    $cnt = $q->found_posts;
                    if ($cnt>$best_count){ $best_count=$cnt; $best_slug=$t->slug; }
                }
            }
            $map[$needle] = $best_slug ?: $needle;
        }
        return $map;
    }

    /*** Seiten ***/

    public static function get_back_url(){
        $default = admin_url('admin.php?page=bottomup_ideas');
        $ret = isset($_GET['ret']) ? wp_unslash($_GET['ret']) : '';
        if ($ret === '') return $default;
        $decoded = base64_decode(rawurldecode($ret), true);
        if (!is_string($decoded) || $decoded === '') return $default;
        $params = [];
        wp_parse_str($decoded, $params);
        if (empty($params['page'])) return $default;
        $allowed = ['bottomup_ideas','bottomup_dashboard'];
        if (!in_array($params['page'], $allowed, true)) return $default;
        return add_query_arg($params, admin_url('admin.php'));
    }

    /**
     * Prozessschritte fürs Dashboard (fachliche Kurz-/Detailtexte).
     * Rückgabe ist ein assoziatives Array, damit JS/HTML stabil über IDs referenzieren kann.
     */
    
/**
 * Prozessschritte fürs Dashboard (fachliche Kurz-/Detailtexte).
 * Rückgabe ist ein assoziatives Array, damit JS/HTML stabil über IDs referenzieren kann.
 *
 * Admin kann die Schritte unter BottomUp → Admin → Prozess pflegen.
 */
public static function get_process_steps(){
    $stored = get_option('bu_process_steps', null);
    if (is_array($stored) && !empty($stored)){
        $norm = self::normalize_process_steps($stored);
        if (!empty($norm)) return $norm;
    }
    return self::get_process_steps_default();
}

/** Normalisiert/säubert Prozessschritte (Reihenfolge bleibt wie im Array). */
private static function normalize_process_steps($steps){
    if (!is_array($steps)) return [];
    $out = [];
    $n = 1;
    foreach ($steps as $id => $s){
        if (!is_array($s)) continue;
        $id = sanitize_key($id);
        if ($id === '') continue;

        $out[$id] = [
            'n'          => $n,
            'title'      => isset($s['title']) ? sanitize_text_field($s['title']) : '',
            'short'      => isset($s['short']) ? sanitize_text_field($s['short']) : '',
            'what'       => isset($s['what']) ? sanitize_textarea_field($s['what']) : '',
            'who'        => isset($s['who']) ? sanitize_textarea_field($s['who']) : '',
            'system'     => isset($s['system']) ? sanitize_textarea_field($s['system']) : '',
            'rules'      => isset($s['rules']) ? sanitize_textarea_field($s['rules']) : '',
            'link'       => isset($s['link']) ? esc_url_raw($s['link']) : '',
            'link_label' => isset($s['link_label']) ? sanitize_text_field($s['link_label']) : '',
        ];
        $n++;
    }
    return $out;
}

/** Standard-Prozessschritte (Fallback, falls Admin noch nichts definiert hat). */
private static function get_process_steps_default(){
    $ideas_url = admin_url('admin.php?page=bottomup_ideas');
    $msg_url   = admin_url('admin.php?page=bottomup_messages');
    $tasks_url = admin_url('admin.php?page=bottomup_tasks');
    $new_url   = admin_url('post-new.php?post_type='.self::CPT);
    $arch_url  = admin_url('admin.php?page=bottomup_ideas&arch=1');

    $defaults = [
        'publish' => [
            'title' => 'Idee publizieren',
            'short' => 'Online oder offline nachgetragen',
            'what' => 'Ein Mitglied erstellt eine Idee und publiziert sie im BottomUp Portal. Offline eingereichte Ideen werden von geeigneten Nutzerinnen und Nutzern nacherfasst.',
            'who' => 'Mitglied / geeignete Nutzerinnen und Nutzer',
            'system' => 'Idee als Datensatz im Backend',
            'rules' => 'Idee sauber erfassen, danach Ebene und Kategorie zuweisen.',
            'link' => $new_url,
            'link_label' => 'Neue Idee anlegen',
        ],
        'classify' => [
            'title' => 'Einordnen',
            'short' => 'Ebene und Kategorie zuweisen',
            'what' => 'Die Idee wird einer Ebene (hierarchisch) und einer Kategorie zugeordnet, damit sie später gefiltert und diskutiert werden kann. Sie kann zudem als Basis für eine Volksinitiative, ein Referendum usw. dienen.',
            'who' => 'Mitglied / Admin',
            'system' => 'Taxonomien: Ebene und Kategorie',
            'rules' => 'Idee sollte mindestens eine Ebene und eine Kategorie besitzen.',
            'link' => $ideas_url,
            'link_label' => 'Ideen öffnen',
        ],
        'vote' => [
            'title' => 'Bewerten und abstimmen',
            'short' => 'SK und Vote pro Runde',
            'what' => 'Andere Mitglieder geben eine SK-Bewertung und stimmen Ja/Nein/Unentschieden ab. Das passiert pro Diskussionsrunde.',
            'who' => 'Mitglieder',
            'system' => 'SK, Vote und Einwände pro Runde',
            'rules' => 'Bei SK >= 8 oder Vote = Nein ist eine Begründung (Einwand) erforderlich.',
            'link' => $ideas_url,
            'link_label' => 'Zur Ideenliste',
        ],
        'objections' => [
            'title' => 'Einwände klären',
            'short' => 'Direkt per PN kommunizieren',
            'what' => 'Einwände werden gelesen und geklärt. Bei Bedarf schreiben sich Mitglieder direkt private Nachrichten, um offene Punkte zu lösen.',
            'who' => 'Mitglieder',
            'system' => 'Einwände und Private Nachrichten',
            'rules' => 'Einwände sollten konkret sein, damit sie in der Runde bearbeitet werden können.',
            'link' => $msg_url,
            'link_label' => 'Nachrichten öffnen',
        ],
        'rounds' => [
            'title' => 'Diskussionsrunden',
            'short' => 'Verfeinern und Gemeinsamkeiten sammeln',
            'what' => 'Ideen werden in einer oder mehreren Diskussionsrunden verfeinert. Dabei werden Gemeinsamkeiten zwischen Mitgliedern und ggf. auch zwischen Ideen herausgearbeitet und in die Idee eingetragen.',
            'who' => 'Mitglieder / Vorstand (organisatorisch)',
            'system' => 'Runden (Iteration) in der Idee',
            'rules' => 'Bewertungen und Einwände werden pro Runde geführt. Weitere Schritte können zusätzlich als Tasks erfasst werden.',
            'link' => $ideas_url,
            'link_label' => 'Zur Ideenliste',
        ],
        'implement' => [
            'title' => 'Umsetzung',
            'short' => 'Schritte als Tasks erfassen',
            'what' => 'Wenn eine Idee genug ausgereift ist, wird sie umgesetzt. Umsetzungsschritte werden als Tasks/Aktionen erfasst, ohne dafür eine neue Diskussionsrunde zu starten.',
            'who' => 'Verantwortliche / Umsetzungsteam',
            'system' => 'Tasks/Aktionen',
            'rules' => 'Umsetzung transparent dokumentieren; keine neue Runde nötig.',
            'link' => $tasks_url,
            'link_label' => 'Zum Task-Board',
        ],
        'archive' => [
            'title' => 'Abschluss und Archiv',
            'short' => 'Umgesetzt: archivieren',
            'what' => 'Umgesetzte Ideen werden abgeschlossen und können archiviert werden, damit das Portal übersichtlich bleibt.',
            'who' => 'Admin / Verantwortliche',
            'system' => 'Status und Archivierung',
            'rules' => 'Archivierte Ideen sind schreibgeschützt.',
            'link' => $arch_url,
            'link_label' => 'Archiv ansehen',
        ],
    ];

    return self::normalize_process_steps($defaults);
}

/** Rendert das Prozess-Widget (Dashboard Sidebar). */
    private static function render_process_widget($variant){
        $variant = in_array($variant, ['stepper','tiles','flow'], true) ? $variant : 'stepper';
        $steps = self::get_process_steps();
        echo '<div class="bu-proc-card" data-variant="'.esc_attr($variant).'">';
        echo '  <div class="bu-proc-head">';
        echo '    <div>';
        echo '      <p class="bu-proc-title">Prozess in Kürze</p>';
        echo '      <p class="bu-proc-sub">Klick auf einen Schritt zeigt Details und Links.</p>';
        echo '    </div>';
        echo '    <span class="dashicons dashicons-editor-help" aria-hidden="true"></span>';
        echo '  </div>';

        if ($variant === 'tiles'){
            echo '  <div class="bu-proc-tiles">';
            foreach ($steps as $id=>$s){
                echo '    <button type="button" class="bu-proc-tile bu-proc-trigger" data-step="'.esc_attr($id).'">';
                echo '      <div class="bu-proc-tile-title">'.esc_html(intval($s['n']).'. '.$s['title']).'</div>';
                echo '      <p class="bu-proc-tile-sub">'.esc_html($s['short']).'</p>';
                echo '    </button>';
            }
            echo '  </div>';
        } elseif ($variant === 'flow'){
// Simple SVG flow; click handled by JS on .bu-proc-trigger
// NOTE: In v2.32 the SVG viewBox height was fixed (440) and only showed 7 steps.
// We calculate the height dynamically so additional steps are visible.
$count = is_array($steps) ? count($steps) : 0;
if ($count < 1) $count = 1;
// Node geometry: y starts at 28 + idx*60, height=48, gap=12; bottom margin=4 (legacy: 7 steps => 440)
$vb_h = 28 + max(0, $count-1) * 60 + 48 + 4;

echo '  <div class="bu-proc-flow-wrap">';
echo '  <svg class="bu-proc-flow" viewBox="0 0 340 '.intval($vb_h).'" role="img" aria-label="Prozessfluss">';
// arrow marker definition
echo '    <defs>';
echo '      <marker id="buProcArrow" markerWidth="10" markerHeight="10" refX="5" refY="5" orient="auto" markerUnits="strokeWidth">';
echo '        <path d="M 0 0 L 10 5 L 0 10 z" fill="#c3c4c7" />';
echo '      </marker>';
echo '    </defs>';
// edges (rendered as directional arrows between nodes)
for ($i=1; $i<=($count-1); $i++){
    $y1 = 28 + ($i-1)*60 + 48; // bottom of current node
    $y2 = 28 + ($i)*60 - 4;    // slightly above next node
    echo '<path class="bu-proc-edge" marker-end="url(#buProcArrow)" d="M170 '.$y1.' L170 '.($y2).'" />';
}
$idx = 0;
foreach ($steps as $id=>$s){
    $y = 28 + $idx*60;
    $label = intval($s['n']).'. '.$s['title'];
    echo '<a href="#" class="bu-proc-trigger" data-step="'.esc_attr($id).'">';
    echo '  <g class="bu-proc-node">';
    echo '    <rect x="22" y="'.$y.'" width="296" height="48" />';
    echo '    <text x="38" y="'.($y+30).'">'.esc_html($label).'</text>';
    echo '  </g>';
    echo '</a>';
    $idx++;
}
echo '  </svg>';
echo '  </div>';

        } else {
            // stepper default
            echo '  <ol class="bu-proc-stepper">';
            foreach ($steps as $id=>$s){
                echo '    <li class="bu-proc-step bu-proc-trigger" data-step="'.esc_attr($id).'" tabindex="0" role="button">';
                echo '      <span class="bu-proc-num">'.esc_html(intval($s['n'])).'</span>';
                echo '      <span class="bu-proc-label"><strong>'.esc_html($s['title']).'</strong><span>'.esc_html($s['short']).'</span></span>';
                echo '    </li>';
            }
            echo '  </ol>';
        }

        echo '  <p class="bu-proc-hint">Tipp: Details öffnen ohne die Seite zu verlassen.</p>';
        echo '</div>';
    }






    public static function render_dashboard(){
        if (!current_user_can('read')) wp_die('Keine Berechtigung.');
        echo '<div class="wrap"><h1>Dashboard</h1>';
        self::kiosk_top_links();
        echo '<div class="bu-dashboard-layout">';
        echo '  <div class="bu-dashboard-main">';
        // Dashboard: Gänseblümchen zeigt Ebenen (Root-Terme). Kategorien erscheinen NICHT als Blüten.
        self::render_daisy_levels();
        echo '  </div>';
        echo '  <div class="bu-dashboard-side">';
        self::render_process_widget('flow');
        echo '  </div>';
        echo '</div>';
        echo '</div>';
    }
    public static function render_ideas(){
        if (!current_user_can('read')) wp_die('Keine Berechtigung.');
        $lvl = isset($_GET['level']) ? sanitize_text_field($_GET['level']) : '';
        $cat = isset($_GET['cat'])   ? sanitize_text_field($_GET['cat'])   : '';
        $act = isset($_GET['act'])   ? sanitize_text_field($_GET['act'])   : '';
        echo '<div class="wrap"><h1>Ideen</h1>';
        self::kiosk_top_links();
        self::render_tabs('ideas', $lvl);
        $fav_on = (isset($_GET['fav']) && $_GET['fav']=='1');
        $arch_on = (isset($_GET['arch']) && $_GET['arch']=='1');

        // 3-stufige Button-Filter (Ebene via Tabs oben, darunter Kategorien und Vorstösse/Aktionen)
        self::render_ideas_button_filters($lvl, $cat, $act, $fav_on, $arch_on);

        $items = self::query_ideas($lvl, $cat, $act, $fav_on, $arch_on);
        echo '<div class="bu-list-controls">';
        echo '  <label style="margin-right:8px;">Anzeige:</label>';
        echo '  <select id="bu-per-page">';
        echo '    <option value="10">10 / Seite</option>';
        echo '    <option value="50">50 / Seite</option>';
        echo '  </select> ';
        echo '  <button type="button" id="bu-reset" class="button">Filter zurücksetzen</button>';
        echo '  <a class="button button-primary" id="bu-export-top" href="'.esc_url(admin_url('admin-post.php?action=bottomup_export&list=1')).'">CSV exportieren</a>';
        echo '</div>';
        echo '<div id="bu-ideas-container" class="bu-ideas-wrap" data-ssr="1">';
        echo self::render_table_html($items);
        echo '</div>';
        echo '<script id="bu-ssr-data" type="application/json">'.wp_json_encode($items).'</script>';
        echo '<script>window.BU_DEFAULT_LEVEL='.json_encode($lvl).';window.BU_DEFAULT_CAT='.json_encode($cat).';window.BU_DEFAULT_ACT='.json_encode($act).';window.BU_DEFAULT_ARCH='.json_encode($arch_on?1:0).';</script>';
        echo '</div>';
    }




    public static function render_messages(){
        if (!current_user_can('read')) wp_die('Keine Berechtigung.');
        self::pm_ensure_tables();
        global $wpdb;
        $t = self::pm_tables();
        $uid = get_current_user_id();

        // Handle actions (send, label, delete) with nonce
        if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['bu_pm_nonce']) && wp_verify_nonce(sanitize_text_field($_POST['bu_pm_nonce']), 'bu_pm')){
            $action = sanitize_key($_POST['bu_pm_action'] ?? '');
            $idea_id = intval($_POST['idea'] ?? 0);
            $other_id = intval($_POST['user'] ?? 0);

            if ($action === 'send'){
                $body = sanitize_textarea_field($_POST['body'] ?? '');
                $task_id = intval($_POST['task'] ?? 0);
                if ($idea_id && $other_id && $body !== ''){
                    // Archived ideas => read-only
                    if (self::is_idea_archived($idea_id)){
                        add_settings_error('bu_pm','bu_pm_ro','Diese Idee ist archiviert – Nachrichten sind schreibgeschützt.','error');
                    } else {
                        $ins_ok = $wpdb->insert($t['messages'], [
                            'idea_id' => $idea_id,
                            'task_id' => $task_id ?: null,
                            'sender_id' => $uid,
                            'recipient_id' => $other_id,
                            'body' => $body,
                            'created_at' => current_time('mysql'),
                            'read_at' => null,
                            'deleted_by_sender' => 0,
                            'deleted_by_recipient' => 0,
                        ], ['%d','%d','%d','%d','%s','%s','%s','%d','%d']);
                        if (!$ins_ok){
                            $err = $wpdb->last_error ? $wpdb->last_error : 'Unbekannter Fehler';
                            add_settings_error('bu_pm','bu_pm_send_fail','Senden fehlgeschlagen: '.esc_html($err),'error');
                        }
}
                }
            } elseif ($action === 'label'){
                $label = sanitize_text_field($_POST['label'] ?? '');
                if ($idea_id && $other_id){
                    $now = current_time('mysql');
                    // upsert
                    $existing = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$t['groups']} WHERE user_id=%d AND idea_id=%d AND other_user_id=%d", $uid, $idea_id, $other_id));
                    if ($existing){
                        $wpdb->update($t['groups'], ['label'=>$label,'updated_at'=>$now], ['id'=>intval($existing)], ['%s','%s'], ['%d']);
                    } else {
                        $wpdb->insert($t['groups'], ['user_id'=>$uid,'idea_id'=>$idea_id,'other_user_id'=>$other_id,'label'=>$label,'updated_at'=>$now], ['%d','%d','%d','%s','%s']);
                    }
                }
            } elseif ($action === 'delete'){
                if ($idea_id && $other_id){
                    // Soft delete for current user
                    $wpdb->query($wpdb->prepare(
                        "UPDATE {$t['messages']}
                         SET deleted_by_sender = IF(sender_id=%d, 1, deleted_by_sender),
                             deleted_by_recipient = IF(recipient_id=%d, 1, deleted_by_recipient)
                         WHERE idea_id=%d AND ((sender_id=%d AND recipient_id=%d) OR (sender_id=%d AND recipient_id=%d))",
                         $uid, $uid, $idea_id, $uid, $other_id, $other_id, $uid
                    ));
                }
            }
        }

        $sel_idea = isset($_GET['idea']) ? intval($_GET['idea']) : 0;
        $sel_user = isset($_GET['user']) ? intval($_GET['user']) : 0;
        $sel_task = isset($_GET['task']) ? intval($_GET['task']) : 0;

        $label_filter = isset($_GET['group']) ? sanitize_text_field($_GET['group']) : '';
        $sort = isset($_GET['sort']) ? sanitize_key($_GET['sort']) : 'last';
        if (!in_array($sort, ['last','unread','title'], true)) $sort='last';

        $search = isset($_GET['q']) ? sanitize_text_field($_GET['q']) : '';

        echo '<div class="wrap">';
        self::kiosk_top_links();
        echo '<h1>Nachrichten</h1>';

        settings_errors('bu_pm');

        // Fetch conversation list
        $case_other = "CASE WHEN m.sender_id={$uid} THEN m.recipient_id ELSE m.sender_id END";
        $where_main = "((m.sender_id={$uid} AND m.deleted_by_sender=0) OR (m.recipient_id={$uid} AND m.deleted_by_recipient=0))";

        $order = "last_at DESC";
        if ($sort==='unread') $order = "unread DESC, last_at DESC";
        elseif ($sort==='title') $order = "p.post_title ASC, last_at DESC";

        $sql = "SELECT m.idea_id,
                       {$case_other} AS other_id,
                       MAX(m.created_at) AS last_at,
                       SUM(CASE WHEN m.recipient_id={$uid} AND (m.read_at IS NULL OR m.read_at='0000-00-00 00:00:00') THEN 1 ELSE 0 END) AS unread,
                       MAX(g.label) AS label
                FROM {$t['messages']} m
                LEFT JOIN {$wpdb->posts} p ON p.ID = m.idea_id
                LEFT JOIN {$wpdb->users} u ON u.ID = ({$case_other})
                LEFT JOIN {$t['groups']} g ON g.user_id={$uid} AND g.idea_id=m.idea_id AND g.other_user_id=({$case_other})
                WHERE {$where_main}";

        $sql_params = [];

        if ($label_filter){
            $sql .= " AND g.label=%s";
            $sql_params[] = $label_filter;
        }

        if ($search){
            $like = '%'.$wpdb->esc_like($search).'%';
            $sql .= " AND (m.body LIKE %s OR p.post_title LIKE %s OR u.display_name LIKE %s OR u.user_email LIKE %s OR g.label LIKE %s OR CAST(m.idea_id AS CHAR) LIKE %s)";
            $sql_params = array_merge($sql_params, [$like,$like,$like,$like,$like,$like]);
        }

        $sql .= " GROUP BY m.idea_id, {$case_other} ORDER BY {$order} LIMIT 500";

        if (!empty($sql_params)){
            $rows = $wpdb->get_results($wpdb->prepare($sql, ...$sql_params));
        } else {
            $rows = $wpdb->get_results($sql);
        }

        // Labels list for filter dropdown
        $labels = $wpdb->get_col($wpdb->prepare("SELECT DISTINCT label FROM {$t['groups']} WHERE user_id=%d AND label<>'' ORDER BY label ASC", $uid));
        echo '<div style="display:flex;gap:16px;align-items:flex-start;">';

        // Left: list
        echo '<div style="flex:0 0 420px;max-width:420px;">';
        echo '<form method="get" style="margin:0 0 12px;">';
        echo '<input type="hidden" name="page" value="bottomup_messages">';
        echo '<label>Gruppe: <select name="group"><option value="">– alle –</option>';
        foreach ($labels as $lab){
            echo '<option value="'.esc_attr($lab).'"'.selected($label_filter,$lab,false).'>'.esc_html($lab).'</option>';
        }
        echo '</select></label> &nbsp; ';
        echo '<label>Sortierung: <select name="sort">';
        foreach (['last'=>'Letzte Aktivität','unread'=>'Ungelesen','title'=>'Ideentitel'] as $k=>$lab){
            echo '<option value="'.esc_attr($k).'"'.selected($sort,$k,false).'>'.esc_html($lab).'</option>';
        }
        echo '</select></label> &nbsp; ';
        echo '<label>Suchen: <input type="search" name="q" value="'.esc_attr($search).'" placeholder="Suchen..." style="width:160px;"></label> ';
        echo '<button class="button">Anwenden</button>';
        echo '</form>';



        echo '<table class="widefat striped"><thead><tr>';
        echo '<th style="width:50px">ID</th><th>Idee / Kontakt</th><th style="width:80px">Neu</th></tr></thead><tbody>';

        foreach ($rows as $r){
            $idea_id = intval($r->idea_id);
            $other_id = intval($r->other_id);
            $unread = intval($r->unread);
            $title = get_the_title($idea_id);
            $other = get_user_by('id', $other_id);
            if (!$other) continue;

            $href = esc_url(self::pm_url($idea_id, $other_id));
            $is_sel = ($idea_id===$sel_idea && $other_id===$sel_user);
            $last_disp = '';
            if (!empty($r->last_at)) $last_disp = date_i18n('d.m.Y', strtotime($r->last_at));

            echo '<tr'.($is_sel?' style="background:#f0f6fc"':'').'>';
            echo '<td>'.intval($idea_id).'</td>';
            echo '<td><a href="'.$href.'"><strong>'.esc_html($title).'</strong><br><span style="color:#646970">mit '.esc_html($other->display_name).'</span>';
            if ($last_disp) echo '<br><small style="color:#646970">Letzte: '.esc_html($last_disp).'</small>';
            echo '</a></td>';
            echo '<td>'.($unread?'<span class="bu-badge" style="background:#d63638;color:#fff">'.intval($unread).'</span>':'').'</td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
        echo '</div>';

        // Right: selected conversation
        echo '<div style="flex:1;min-width:520px;">';
        if ($sel_idea && $sel_user){
            $idea = get_post($sel_idea);
            $other = get_user_by('id', $sel_user);
            if ($idea && $other){
                // mark read
                $wpdb->query($wpdb->prepare("UPDATE {$t['messages']} SET read_at=%s WHERE idea_id=%d AND sender_id=%d AND recipient_id=%d AND (read_at IS NULL OR read_at='0000-00-00 00:00:00')",
                    current_time('mysql'), $sel_idea, $sel_user, $uid
                ));

                $readonly = self::is_idea_archived($sel_idea);

                echo '<div class="card" style="padding:16px;max-width:980px">';
                echo '<h2 style="margin-top:0;">Idee #'.intval($sel_idea).' – '.esc_html(get_the_title($sel_idea)).'</h2>';
                echo '<p style="margin:0 0 12px;color:#646970">Chat mit <strong>'.esc_html($other->display_name).'</strong>'.($readonly?' · <span style="color:#d63638">Archiviert (nur Anzeige)</span>':'').'</p>';

                // label editor
                $cur_lab = $wpdb->get_var($wpdb->prepare("SELECT label FROM {$t['groups']} WHERE user_id=%d AND idea_id=%d AND other_user_id=%d", $uid, $sel_idea, $sel_user));
                echo '<form method="post" style="margin:0 0 12px;display:flex;gap:8px;align-items:center;">';
                echo '<input type="hidden" name="bu_pm_nonce" value="'.esc_attr(wp_create_nonce('bu_pm')).'">';
                echo '<input type="hidden" name="bu_pm_action" value="label">';
                echo '<input type="hidden" name="idea" value="'.intval($sel_idea).'">';
                echo '<input type="hidden" name="user" value="'.intval($sel_user).'">';
                echo '<label style="margin:0;">Gruppe: <input type="text" name="label" value="'.esc_attr($cur_lab).'" placeholder="z.B. Team / PR / Recht" style="min-width:220px"></label>';
                echo '<button class="button">Speichern</button>';
                echo '</form>';



                // delete convo
                echo '<form method="post" style="margin:0 0 12px;">';
                echo '<input type="hidden" name="bu_pm_nonce" value="'.esc_attr(wp_create_nonce('bu_pm')).'">';
                echo '<input type="hidden" name="bu_pm_action" value="delete">';
                echo '<input type="hidden" name="idea" value="'.intval($sel_idea).'">';
                echo '<input type="hidden" name="user" value="'.intval($sel_user).'">';
				echo '<button class="button button-link-delete" data-confirm="Diese Unterhaltung für dich löschen?">Unterhaltung löschen</button>';
                echo '</form>';



                // messages list
                $msgs = $wpdb->get_results($wpdb->prepare(
                    "SELECT * FROM {$t['messages']}
                     WHERE idea_id=%d AND ((sender_id=%d AND recipient_id=%d AND deleted_by_sender=0) OR (sender_id=%d AND recipient_id=%d AND deleted_by_recipient=0))
                     ORDER BY created_at ASC
                     LIMIT 500",
                     $sel_idea, $uid, $sel_user, $sel_user, $uid
                ));
                echo '<div style="border:1px solid #d0d7de;border-radius:8px;padding:12px;max-height:520px;overflow:auto;background:#fff">';
                if ($msgs){
                    foreach ($msgs as $m){
                        $is_me = (intval($m->sender_id) === $uid);
                        $who = $is_me ? 'Du' : $other->display_name;
                        $dt = date_i18n('d.m.Y H:i', strtotime($m->created_at));
                        echo '<div style="margin:0 0 10px;">';
                        echo '<div style="font-size:12px;color:#646970"><strong>'.esc_html($who).'</strong> · '.esc_html($dt).'</div>';
                        echo '<div style="white-space:pre-wrap">'.esc_html($m->body).'</div>';
                        echo '</div>';
                    }
                } else {
                    echo '<p style="margin:0;color:#646970">Noch keine Nachrichten.</p>';
                }
                echo '</div>';

                // send
                echo '<form method="post" style="margin-top:12px;">';
                echo '<input type="hidden" name="bu_pm_nonce" value="'.esc_attr(wp_create_nonce('bu_pm')).'">';
                echo '<input type="hidden" name="bu_pm_action" value="send">';
                echo '<input type="hidden" name="idea" value="'.intval($sel_idea).'">';
                echo '<input type="hidden" name="user" value="'.intval($sel_user).'">';
                if ($sel_task) echo '<input type="hidden" name="task" value="'.intval($sel_task).'">';
                echo '<textarea name="body" rows="3" class="widefat" '.($readonly?'readonly':'').' placeholder="'.($readonly?'Archiviert – nur Anzeige':'Nachricht schreiben…').'"></textarea>';
                echo '<p style="margin:8px 0 0;">';
                if (!$readonly) echo '<button class="button button-primary">Senden</button>';
                echo '</p>';
                echo '</form>';



                echo '</div>';
            }
        } else {
            echo '<div class="card" style="padding:16px;"><p style="margin:0;color:#646970">Wähle links eine Unterhaltung.</p></div>';
        }
        echo '</div>';

        echo '</div>'; // flex
        echo '</div>'; // wrap
    }
























    public static function render_settings(){
        if (!current_user_can('read')) wp_die('Keine Berechtigung.');

        $uid = get_current_user_id();
        $tab = isset($_GET['tab']) ? sanitize_key($_GET['tab']) : 'notifications';
        if (!in_array($tab, ['notifications'], true)) $tab = 'notifications';

        // Save settings
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bu_settings_nonce']) && wp_verify_nonce(sanitize_text_field($_POST['bu_settings_nonce']), 'bu_settings')){
            $bulk = sanitize_key($_POST['bu_notif_bulk'] ?? '');

            $fav = (isset($_POST['bu_notify_fav_changes']) && $_POST['bu_notify_fav_changes']) ? '1' : '0';
            $fav_tasks = (isset($_POST['bu_notify_fav_tasks']) && $_POST['bu_notify_fav_tasks']) ? '1' : '0';
            $new_lv = (isset($_POST['bu_notify_new_levels_on']) && $_POST['bu_notify_new_levels_on']) ? '1' : '0';
            $new_cat = (isset($_POST['bu_notify_new_cats_on']) && $_POST['bu_notify_new_cats_on']) ? '1' : '0';
            $my  = (isset($_POST['bu_notify_my_idea_activity']) && $_POST['bu_notify_my_idea_activity']) ? '1' : '0';

            if ($bulk === 'on'){
                $fav = '1'; $fav_tasks = '1'; $new_lv = '1'; $new_cat = '1'; $my = '1';
            } elseif ($bulk === 'off'){
                $fav = '0'; $fav_tasks = '0'; $new_lv = '0'; $new_cat = '0'; $my = '0';
            }

            update_user_meta($uid, 'bu_notify_fav_changes', $fav);
            update_user_meta($uid, 'bu_notify_fav_tasks', $fav_tasks);
            update_user_meta($uid, 'bu_notify_new_levels_on', $new_lv);
            update_user_meta($uid, 'bu_notify_new_cats_on', $new_cat);
            // Legacy key (für Abwärtskompatibilität): 1 wenn Ebenen ODER Kategorien aktiv
            update_user_meta($uid, 'bu_notify_new_ideas', ($new_lv === '1' || $new_cat === '1') ? '1' : '0');
            update_user_meta($uid, 'bu_notify_my_idea_activity', $my);

            // Favoriten-Tasks: Task-Bewegungen (Statuswechsel) – pro User granular
            $moves = isset($_POST['bu_notify_fav_task_moves']) ? (array)$_POST['bu_notify_fav_task_moves'] : [];
            $moves = array_values(array_filter(array_map('sanitize_key', $moves)));
            $allowed = self::fav_task_move_allowed_keys();
            $moves = array_values(array_intersect($allowed, $moves));

            if ($bulk === 'on'){
                $moves = $allowed;
            } elseif ($bulk === 'off'){
                $moves = [];
            }

            update_user_meta($uid, 'bu_notify_fav_task_moves', $moves);

            // Favoriten-Tasks: weitere Events (Neuer Task, Kommentar, Inhalt/Datum/sonstiges) – pro User aktivierbar
            $events = isset($_POST['bu_notify_fav_task_events']) ? (array)$_POST['bu_notify_fav_task_events'] : [];
            $events = array_values(array_filter(array_map('sanitize_key', $events)));
            $allowed_events = self::fav_task_event_allowed_keys();
            $events = array_values(array_intersect($allowed_events, $events));

            if ($bulk === 'on'){
                $events = $allowed_events;
            } elseif ($bulk === 'off'){
                $events = [];
            }

            update_user_meta($uid, 'bu_notify_fav_task_events', $events);

            $levels = isset($_POST['bu_notify_new_levels']) ? (array)$_POST['bu_notify_new_levels'] : [];
            $levels = array_values(array_filter(array_map('intval', $levels)));
            update_user_meta($uid, 'bu_notify_new_levels', $levels);

            $cats = isset($_POST['bu_notify_new_cats']) ? (array)$_POST['bu_notify_new_cats'] : [];
            $cats = array_values(array_filter(array_map('intval', $cats)));
            update_user_meta($uid, 'bu_notify_new_cats', $cats);

            add_settings_error('bu_settings','bu_settings_saved','Gespeichert.','updated');

            // Avoid resubmission on refresh
            wp_safe_redirect(add_query_arg(['page'=>'bottomup_settings','tab'=>$tab,'saved'=>1], admin_url('admin.php')));
            exit;
        }

        if (isset($_GET['saved'])){
            add_settings_error('bu_settings','bu_settings_saved','Gespeichert.','updated');
        }

        // Flash-Messages (z.B. Test-Mail)
        if (isset($_GET['test'])){
            $flash = get_transient('bu_test_mail_flash_'.$uid);
            if (is_array($flash) && isset($flash['msg'])){
                $type = (!empty($flash['ok']) ? 'updated' : 'error');
                add_settings_error('bu_settings','bu_test_mail', sanitize_text_field($flash['msg']), $type);
                delete_transient('bu_test_mail_flash_'.$uid);
            }
        }

        $fav_on = (get_user_meta($uid, 'bu_notify_fav_changes', true) === '1');
        $fav_tasks_on = self::user_notifications_enabled_for($uid, 'fav_tasks');
        $fav_task_moves = self::user_fav_task_moves_enabled_list($uid);
        $fav_task_events = self::user_fav_task_events_enabled_list($uid);
        $my_on  = (get_user_meta($uid, 'bu_notify_my_idea_activity', true) === '1');

        // „Neue Ideen“ wurde ab v2.27 in Ebenen/Kategorien getrennt.
        // Abwärtskompatibilität: wenn altes Flag aktiv ist und die neuen Flags noch nicht existieren, werden beide aktiviert.
        $legacy_new_on = (get_user_meta($uid, 'bu_notify_new_ideas', true) === '1');
        $new_lv_on = (get_user_meta($uid, 'bu_notify_new_levels_on', true) === '1');
        $new_cat_on = (get_user_meta($uid, 'bu_notify_new_cats_on', true) === '1');

        $has_lv = function_exists('metadata_exists') ? metadata_exists('user', $uid, 'bu_notify_new_levels_on') : ($new_lv_on || get_user_meta($uid, 'bu_notify_new_levels_on', true) !== '');
        $has_cat = function_exists('metadata_exists') ? metadata_exists('user', $uid, 'bu_notify_new_cats_on') : ($new_cat_on || get_user_meta($uid, 'bu_notify_new_cats_on', true) !== '');

        if ($legacy_new_on && !$has_lv && !$has_cat){
            $new_lv_on = true;
            $new_cat_on = true;
            update_user_meta($uid, 'bu_notify_new_levels_on', '1');
            update_user_meta($uid, 'bu_notify_new_cats_on', '1');
        }

        $sel_levels = get_user_meta($uid, 'bu_notify_new_levels', true);
        if (!is_array($sel_levels)) $sel_levels = [];
        $sel_levels = array_values(array_filter(array_map('intval', $sel_levels)));

        $sel_cats = get_user_meta($uid, 'bu_notify_new_cats', true);
        if (!is_array($sel_cats)) $sel_cats = [];
        $sel_cats = array_values(array_filter(array_map('intval', $sel_cats)));

        // Small version badge helps verify which plugin build is active
        $ver_badge = '<span style="display:inline-block;margin-left:8px;padding:2px 8px;border:1px solid #d0d7de;border-radius:9999px;font-size:12px;color:#57606a;vertical-align:middle;">v'.esc_html(BU_IDEAS_VERSION).'</span>';
        echo '<div class="wrap"><h1>Einstellungen '.$ver_badge.'</h1>';
        self::kiosk_top_links();

        // Tooltip helper (native title attribute)
        $tip = function($text){
            $text = (string)$text;
            return ' <span class="dashicons dashicons-editor-help" style="vertical-align:middle;margin-left:6px;color:#646970;cursor:help;" title="'.esc_attr($text).'"></span>';
        };

        echo '<h2 class="nav-tab-wrapper">';
        echo '<a class="nav-tab '.($tab==='notifications'?'nav-tab-active':'').'" href="'.esc_url(add_query_arg(['page'=>'bottomup_settings','tab'=>'notifications'], admin_url('admin.php'))).'">Benachrichtigungen</a>';
        echo '</h2>';

        settings_errors('bu_settings');

        echo '<form method="post" style="max-width:980px;margin-top:16px;">';
        echo '<input type="hidden" name="bu_settings_nonce" value="'.esc_attr(wp_create_nonce('bu_settings')).'">';

        echo '<div class="card" style="padding:16px;">';
        echo '<p style="margin-top:0;">Hier kannst du festlegen, welche E-Mail-Benachrichtigungen du erhalten möchtest.</p>';

        echo '<p style="display:flex;gap:8px;flex-wrap:wrap;">';
        echo '<button type="submit" name="bu_notif_bulk" value="on" class="button">Alle aktivieren</button>';
        echo '<button type="submit" name="bu_notif_bulk" value="off" class="button">Alle deaktivieren</button>';
        echo '<button type="submit" class="button button-primary">Speichern</button>';
        echo '</p>';

        echo '<hr>';

        echo '<h2 style="margin-top:0;">E-Mail Benachrichtigungen</h2>';

        $tip_fav = 'E-Mail, wenn sich an einer Idee, die du als Favorit markiert hast, etwas ändert (Inhalt, Status/Archiv, Ebene/Kategorie/Aktionen), wenn eine neue Runde gestartet wird oder wenn eine Runde-Deadline verstrichen ist.';
        echo '<label style="display:block;margin:0 0 10px 0;">'
            . '<input type="checkbox" name="bu_notify_fav_changes" value="1" '.checked($fav_on,true,false).'> '
            . 'Änderungen an Favoriten-Ideen'.$tip($tip_fav)
            . '</label>';

        // Favoriten-Tasks (eigener Knoten)
        $tip_fav_tasks = 'E-Mail, wenn sich ein Task einer Idee, die du als Favorit markiert hast, ändert: Statuswechsel im Tasks-Board, neuer Task, Kommentar oder Änderungen am Inhalt/Datum/sonstigen Feldern.';
        echo '<label style="display:block;margin:0 0 10px 0;">'
            . '<input type="checkbox" name="bu_notify_fav_tasks" value="1" '.checked($fav_tasks_on,true,false).'> '
            . 'Änderungen an Favoriten-Tasks'.$tip($tip_fav_tasks)
            . '</label>';

        $allowed_moves = self::fav_task_move_allowed_keys();
        $moves_labels = [
            'todo_doing' => 'ToDo → Doing',
            'doing_done' => 'Doing → Done',
            'todo_done'  => 'ToDo → Done (übersprungen)',
            'doing_todo' => 'Doing → ToDo (zurück)',
            'done_doing' => 'Done → Doing (zurück)',
            'done_todo'  => 'Done → ToDo (zurück)',
        ];

        $allowed_events = self::fav_task_event_allowed_keys();
        $event_labels = [
            'create'  => 'Neuer Task angelegt',
            'comment' => 'Task kommentiert',
            'content' => 'Neuer Inhalt / Text geändert',
            'due'     => 'Datum geändert',
            'other'   => 'Sonstige Änderung (z.B. Zuständigkeit, Checkliste, Anhänge)',
        ];

        $disabled_style = $fav_tasks_on ? '' : 'opacity:0.6;';
        $disabled_note = $fav_tasks_on ? '' : '<p class="description" style="margin:6px 0 0;">Wird nur berücksichtigt, wenn „Änderungen an Favoriten-Tasks“ aktiv ist.</p>';

        $open_tasks = $fav_tasks_on ? ' open' : '';
        echo '<details'.$open_tasks.' style="margin:0 0 16px 20px;'.$disabled_style.'">';
        echo '<summary style="cursor:pointer;user-select:none;font-weight:600;">Optionen anzeigen</summary>';
        echo '<div style="margin:10px 0 0 0;padding:10px 12px;border-left:3px solid #d0d7de;background:#f6f8fa;">';

        // Unterknoten 1: Statuswechsel
        $open_moves = (!empty($fav_task_moves) && $fav_tasks_on) ? ' open' : '';
        $tip_moves = 'E-Mail, wenn ein Task im Tasks-Board zwischen den Spalten ToDo/Doing/Done verschoben wird. Du kannst Übergänge einzeln aktivieren.';
        echo '<details'.$open_moves.' style="margin:0 0 10px 0;">';
        echo '<summary style="cursor:pointer;user-select:none;font-weight:600;">Statuswechsel (Task-Bewegungen)'.$tip($tip_moves).'</summary>';
        echo '<div style="margin:10px 0 0 0;">';
        echo '<p style="margin:0 0 8px 0;">Wähle, bei welchen Statuswechseln du benachrichtigt werden möchtest:</p>';
        echo '<div style="display:flex;flex-wrap:wrap;gap:10px 18px;">';
        foreach ($allowed_moves as $k){
            $lab = $moves_labels[$k] ?? $k;
            $checked = in_array($k, $fav_task_moves, true);
            $t = 'E-Mail, wenn ein Task von '.$lab.' verschoben wird.';
            echo '<label style="display:inline-flex;align-items:center;gap:6px;" title="'.esc_attr($t).'">'
               . '<input type="checkbox" name="bu_notify_fav_task_moves[]" value="'.esc_attr($k).'" '.checked($checked,true,false).'> '
               . esc_html($lab)
               . '</label>';
        }
        echo '</div>';
        echo '</div>';
        echo '</details>';

        // Unterknoten 2: Kommentar/Inhalt/Datum/Sonstiges
        $open_events = (!empty($fav_task_events) && $fav_tasks_on) ? ' open' : '';
        $tip_events = 'E-Mail bei inhaltlichen Änderungen an Tasks einer Favoriten-Idee (z.B. neuer Task, Kommentar, Text/Datum/sonstige Felder).';
        echo '<details'.$open_events.' style="margin:0;">';
        echo '<summary style="cursor:pointer;user-select:none;font-weight:600;">Task kommentiert / Inhalt / Datum / Sonstiges'.$tip($tip_events).'</summary>';
        echo '<div style="margin:10px 0 0 0;">';
        echo '<div style="display:flex;flex-direction:column;gap:8px;">';
        foreach ($allowed_events as $ek){
            $lab = $event_labels[$ek] ?? $ek;
            $checked = in_array($ek, $fav_task_events, true);
            $tt = '';
            if ($ek === 'create') $tt = 'E-Mail, wenn ein neuer Task bei einer Favoriten-Idee erstellt wird.';
            elseif ($ek === 'comment') $tt = 'E-Mail, wenn ein Task kommentiert wird.';
            elseif ($ek === 'content') $tt = 'E-Mail, wenn Titel oder Beschreibung eines Tasks geändert werden.';
            elseif ($ek === 'due') $tt = 'E-Mail, wenn das Task-Datum gesetzt, geändert oder entfernt wird.';
            elseif ($ek === 'other') $tt = 'E-Mail bei sonstigen Änderungen (z.B. Zuständigkeit, Checkliste, Anhänge).';
            echo '<label style="display:inline-flex;align-items:center;gap:6px;" title="'.esc_attr($tt).'">'
               . '<input type="checkbox" name="bu_notify_fav_task_events[]" value="'.esc_attr($ek).'" '.checked($checked,true,false).'> '
               . esc_html($lab)
               . '</label>';
        }
        echo '</div>';
        echo '</div>';
        echo '</details>';

        echo $disabled_note;
        echo '</div>';
        echo '</details>';

        $tip_my = 'E-Mail an dich als Autor, wenn jemand deine Idee bewertet (SK), abstimmt oder seinen Einwand/Kommentar dazu ändert.';
        echo '<label style="display:block;margin:0 0 10px 0;">'
            . '<input type="checkbox" name="bu_notify_my_idea_activity" value="1" '.checked($my_on,true,false).'> '
            . 'Über meine Ideen wurde abgestimmt & kommentiert'.$tip($tip_my)
            . '</label>';

        $tip_new_lv = 'E-Mail, wenn eine neue Idee veröffentlicht wird, die zu einer der ausgewählten Ebenen gehört (wenn keine Ebenen ausgewählt sind: alle).';
        echo '<label style="display:block;margin:0 0 10px 0;">'
            . '<input type="checkbox" name="bu_notify_new_levels_on" value="1" '.checked($new_lv_on,true,false).'> '
            . 'Neue Ideen in Ebenen'.$tip($tip_new_lv)
            . '</label>';

        $open_lv = ($new_lv_on || !empty($sel_levels)) ? ' open' : '';
        echo '<details'.$open_lv.' style="margin:0 0 16px 20px;">';
        echo '<summary style="cursor:pointer;user-select:none;font-weight:600;">Ebenen auswählen</summary>';
        echo '<div style="margin:10px 0 0 0;padding:10px 12px;border-left:3px solid #d0d7de;background:#f6f8fa;">';
        echo '<p style="margin:0 0 8px 0;"><strong>Filter für „Neue Ideen“ (Ebenen)</strong></p>';
        echo '<p class="description" style="margin:0 0 10px 0;">Wenn keine Ebenen ausgewählt sind, gilt automatisch: <em>alle</em>.</p>';

        // Ebenen
        $lvl_parents = get_terms(['taxonomy'=>self::TAX_LVL,'hide_empty'=>false,'parent'=>0,'orderby'=>'name','order'=>'ASC']);
        if (is_wp_error($lvl_parents)) $lvl_parents = [];

        echo '<div class="bu-settings-levels" style="min-width:260px;">';
        if (empty($lvl_parents)){
            echo '<p class="description">Keine Ebenen vorhanden.</p>';
        } else {
            echo '<p class="description" style="margin:0 0 8px 0;">Tipp: Kantone/Städte/Gemeinden kannst du auf- und zuklappen.</p>';
            foreach ($lvl_parents as $pt){
                $pid = intval($pt->term_id);
                $checked_parent = in_array($pid, $sel_levels, true) ? 'checked' : '';

                $children = get_terms(['taxonomy'=>self::TAX_LVL,'hide_empty'=>false,'parent'=>$pid,'orderby'=>'name','order'=>'ASC']);
                $has_children = (!is_wp_error($children) && !empty($children));

                // Details-Block nur wenn es Untergruppen gibt
                if ($has_children){
                    $open = ($checked_parent !== '');
                    foreach ($children as $ct){
                        $cid = intval($ct->term_id);
                        if (in_array($cid, $sel_levels, true)) { $open = true; break; }
                    }

                    // Summary-Label (schöner lesbar für lange Listen)
                    $sum = 'Untergruppen anzeigen';
                    $pn = function_exists('mb_strtolower') ? mb_strtolower((string)$pt->name) : strtolower((string)$pt->name);
                    if (strpos($pn, 'kanton') !== false) $sum = 'Kantone anzeigen';
                    elseif (strpos($pn, 'stadt') !== false) $sum = 'Städte anzeigen';
                    elseif (strpos($pn, 'gemeinde') !== false || strpos($pn, 'lokal') !== false) $sum = 'Gemeinden anzeigen';

                    echo '<div class="bu-level-group">';
                    echo '<label class="bu-level-group__parent"><input type="checkbox" name="bu_notify_new_levels[]" value="'.$pid.'" '.$checked_parent.'> '.esc_html($pt->name).'</label>';
                    echo '<details class="bu-level-fold" '.($open?'open':'').'>';
                    echo '<summary class="bu-level-fold__summary">'.esc_html($sum).' <span class="bu-level-fold__count">('.intval(count($children)).')</span></summary>';
                    echo '<div class="bu-level-fold__body">';
                    foreach ($children as $ct){
                        $cid = intval($ct->term_id);
                        $checked2 = in_array($cid, $sel_levels, true) ? 'checked' : '';
                        echo '<label class="bu-level-fold__child"><input type="checkbox" name="bu_notify_new_levels[]" value="'.$cid.'" '.$checked2.'> '.esc_html($ct->name).'</label>';
                    }
                    echo '</div>';
                    echo '</details>';
                    echo '</div>';
                } else {
                    echo '<label style="display:block;margin:0 0 4px 0;"><input type="checkbox" name="bu_notify_new_levels[]" value="'.$pid.'" '.$checked_parent.'> '.esc_html($pt->name).'</label>';
                }
            }
        }
        echo '</div>';

        echo '</div></details>'; // indent

        $tip_new_cat = 'E-Mail, wenn eine neue Idee veröffentlicht wird, die zu einer der ausgewählten Kategorien gehört (wenn keine Kategorien ausgewählt sind: alle).';
        echo '<label style="display:block;margin:0 0 10px 0;">'
            . '<input type="checkbox" name="bu_notify_new_cats_on" value="1" '.checked($new_cat_on,true,false).'> '
            . 'Neue Ideen in Kategorien'.$tip($tip_new_cat)
            . '</label>';

        $open_cat = ($new_cat_on || !empty($sel_cats)) ? ' open' : '';
        echo '<details'.$open_cat.' style="margin:0 0 16px 20px;">';
        echo '<summary style="cursor:pointer;user-select:none;font-weight:600;">Kategorien auswählen</summary>';
        echo '<div style="margin:10px 0 0 0;padding:10px 12px;border-left:3px solid #d0d7de;background:#f6f8fa;">';
        echo '<p style="margin:0 0 8px 0;"><strong>Filter für „Neue Ideen“ (Kategorien)</strong></p>';
        echo '<p class="description" style="margin:0 0 10px 0;">Wenn keine Kategorien ausgewählt sind, gilt automatisch: <em>alle</em>.</p>';

        // Kategorien
        $cat_terms = get_terms(['taxonomy'=>self::TAX_CAT,'hide_empty'=>false,'orderby'=>'name','order'=>'ASC']);
        if (is_wp_error($cat_terms)) $cat_terms = [];

        if (empty($cat_terms)){
            echo '<p class="description">Keine Kategorien vorhanden.</p>';
        } else {
            foreach ($cat_terms as $ct){
                $cid = intval($ct->term_id);
                $checked = in_array($cid, $sel_cats, true) ? 'checked' : '';
                echo '<label style="display:block;margin:0 0 4px 0;"><input type="checkbox" name="bu_notify_new_cats[]" value="'.$cid.'" '.$checked.'> '.esc_html($ct->name).'</label>';
            }
        }

        echo '</div></details>'; // indent



        $me = wp_get_current_user();
        if ($me && $me->user_email){
            $profile_url = admin_url('profile.php#email');
            echo '<p class="description" style="margin-top:12px;display:flex;align-items:center;gap:10px;flex-wrap:wrap;">'
               . 'Benachrichtigungen werden an <strong>'.esc_html($me->user_email).'</strong> gesendet.'
               . ' <a class="button button-small" href="'.esc_url($profile_url).'">E-Mail ändern</a>'
               . '</p>';
        }

        // Mail-Test & Diagnose
        $test_url = wp_nonce_url(admin_url('admin-post.php?action=bu_send_test_mail'), 'bu_send_test_mail');
        $last_ok = get_user_meta($uid, 'bu_notify_last_success', true);
        $last_fail = get_user_meta($uid, 'bu_notify_last_fail', true);
        $last_err = get_transient('bu_last_mail_error_'.$uid);
        if (!is_array($last_err)) $last_err = [];

        echo '<hr style="margin:16px 0;">';
        echo '<h3 style="margin:0 0 8px 0;">Mail-Test & Diagnose</h3>';
        echo '<p class="description" style="margin:0 0 10px 0;">Wenn du keine E-Mails erhältst, liegt es meist an der WordPress/Server-Mailkonfiguration. Mit dem Test kannst du prüfen, ob <code>wp_mail()</code> grundsätzlich funktioniert (Spam-Ordner prüfen!).</p>';
        echo '<p style="margin:0 0 12px 0;"><a class="button" href="'.esc_url($test_url).'">Test-Mail senden</a></p>';

        if (!empty($last_ok)){
            echo '<p class="description" style="margin:0 0 6px 0;">Letzte erfolgreiche Mail: <strong>'.esc_html($last_ok).'</strong></p>';
        }
        if (!empty($last_fail)){
            echo '<p class="description" style="margin:0 0 6px 0;">Letzter fehlgeschlagener Versuch: <strong>'.esc_html($last_fail).'</strong></p>';
        }
        if (!empty($last_err['error'])){
            $t = !empty($last_err['time']) ? $last_err['time'] : '';
            $to = !empty($last_err['to']) ? $last_err['to'] : '';
            $subj = !empty($last_err['subject']) ? $last_err['subject'] : '';
            echo '<p style="margin:8px 0 0 0;color:#b32d2e;">';
            echo '<strong>Letzter Mail-Fehler</strong>'.($t?' ('.$t.')':'').': '.esc_html($last_err['error']);
            if ($to) echo ' <span class="description" style="color:#b32d2e;">(to: '.esc_html($to).')</span>';
            echo '</p>';

            // Copy-to-clipboard (hilft Support / IT)
            $copy_lines = [];
            if ($t) $copy_lines[] = 'Zeit: '.$t;
            if ($to) $copy_lines[] = 'To: '.$to;
            if ($subj) $copy_lines[] = 'Subject: '.$subj;
            $copy_lines[] = 'Fehler: '.(string)$last_err['error'];
            $copy_txt = implode("\n", array_filter($copy_lines));
            echo '<p style="margin:6px 0 0 0;">';
            echo '<button type="button" class="button" id="bu_copy_last_error" data-copy="'.esc_attr($copy_txt).'">Letzten Fehler kopieren</button>';
            echo '<span id="bu_copy_last_error_ok" class="description" style="margin-left:8px;display:none;">Kopiert.</span>';
            echo '</p>';
            echo '<script>(function(){\n'
                .'var b=document.getElementById("bu_copy_last_error");\n'
                .'if(!b) return;\n'
                .'b.addEventListener("click", function(){\n'
                .'  var txt=b.getAttribute("data-copy")||"";\n'
                .'  function ok(){var s=document.getElementById("bu_copy_last_error_ok"); if(s){s.style.display="inline"; setTimeout(function(){s.style.display="none";},1500);} }\n'
                .'  if(navigator.clipboard && window.isSecureContext){\n'
                .'    navigator.clipboard.writeText(txt).then(ok).catch(function(){fallback();});\n'
                .'  } else {\n'
                .'    fallback();\n'
                .'  }\n'
                .'  function fallback(){\n'
                .'    var ta=document.createElement("textarea");\n'
                .'    ta.value=txt;\n'
                .'    ta.setAttribute("readonly", "");\n'
                .'    ta.style.position="absolute"; ta.style.left="-9999px";\n'
                .'    document.body.appendChild(ta);\n'
                .'    ta.select();\n'
                .'    try{document.execCommand("copy"); ok();}catch(e){}\n'
                .'    document.body.removeChild(ta);\n'
                .'  }\n'
                .'});\n'
                .'})();</script>';
            echo '<p class="description" style="margin-top:6px;">Tipp: Installiere z.B. ein SMTP-Plugin (WP Mail SMTP) oder konfiguriere den Mailserver, damit WordPress Mails zuverlässig versenden kann.</p>';
        }

        echo '</div>'; // card
        echo '</form>';

        echo '</div>'; // wrap
    }


private static function snap_text($snap, $field){
    $val = $snap[$field] ?? '';
    if (is_array($val)){
        $val = implode("
", array_map(function($x){ return (string)$x; }, $val));
    }
    $val = (string)$val;
    $val = wp_strip_all_tags($val);
    $val = str_replace(["
","
"], "
", $val);
    return trim($val);
}

private static function terms_text($term_ids, $taxonomy){
    $names = [];
    if (is_array($term_ids)){
        foreach ($term_ids as $tid){
            $t = get_term(intval($tid), $taxonomy);
            if ($t && !is_wp_error($t)) $names[] = $t->name;
        }
    }
    return implode(', ', $names);
}



    public static function render_view(){
        if (!current_user_can('read')) wp_die('Keine Berechtigung.');
        $pid = isset($_GET['post']) ? intval($_GET['post']) : 0;
        if (!$pid || get_post_type($pid)!==self::CPT) wp_die('Ungültige ID.');
        $p = get_post($pid);
        echo '<div class="wrap">';
        echo '<h1>Idee ansehen <span class="bu-id-badge">ID: '.intval($pid).'</span></h1>';
        $back_url = self::get_back_url();
        echo '<p><a class="button" href="'.esc_url($back_url).'">← Zurück zur Liste</a> ';
        $print_url = self::print_url($pid);
        echo '<a class="button" href="'.esc_url($print_url).'">🖨 Drucken</a> ';
        $round = self::get_round_current($pid);
        echo '<span class="bu-round-badge" style="margin-left:6px" title="Aktuelle Runde">Runde #'.intval($round).'</span> ';
        $dl = self::get_round_deadline($pid, $round);
        if ($dl){
            $dl_txt = self::fmt_round_deadline($dl);
            if ($dl_txt){
                $expired = self::deadline_is_expired($dl);
                $cls = $expired ? ' bu-deadline-expired' : '';
                $title = $expired ? ' title="verstrichen"' : '';
                echo '<span class="bu-round-deadline'.$cls.'"'.$title.' style="margin-left:8px;color:#444">Runde #'.intval($round).' läuft bis '.esc_html($dl_txt).'</span> ';
            }
        }

        $readonly = self::is_idea_archived($pid);
        if (!$readonly && current_user_can('edit_post', $pid)){
            $start_url = wp_nonce_url(admin_url('admin-post.php?action=bu_start_round&post='.$pid), 'bu_start_round_'.$pid);
            $next_dl = self::get_round_deadline($pid, $round + 1);
            $next_dl_txt = $next_dl ? self::fmt_round_deadline($next_dl) : '';
            $next_dl_date = '';
            $next_dl_time = '';
            if ($next_dl){
                try {
                    $tz = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone(get_option('timezone_string') ?: 'UTC');
                    $dt = new DateTime($next_dl, $tz);
                    $next_dl_date = $dt->format('d.m.Y');
                    $next_dl_time = $dt->format('H:i');
                } catch (Exception $e) { $next_dl_date = ''; $next_dl_time = ''; }
            }
            echo '<a class="button bu-start-round" href="'.esc_url($start_url).'" data-url="'.esc_attr($start_url).'" data-next-deadline-date="'.esc_attr($next_dl_date).'" data-next-deadline-time="'.esc_attr($next_dl_time).'">🔁 Neue Runde starten</a> ';
            if ($next_dl_txt){
                $expired2 = self::deadline_is_expired($next_dl);
                $cls2 = $expired2 ? ' bu-deadline-expired' : '';
                $title2 = $expired2 ? ' title="verstrichen"' : '';
                echo '<span class="bu-next-deadline'.$cls2.'"'.$title2.' style="margin-left:8px">Nächste Deadline: <strong>'.esc_html($next_dl_txt).'</strong></span> ';
            }
        }
        echo '<button type="button" class="button" id="bu-open-versions" data-idea="'.intval($pid).'">🕘 Versionen</button> ';
        echo '<a class="button button-primary" href="'.esc_url(get_edit_post_link($pid,'')).'">Bearbeiten</a></p>';
        $sum = get_post_meta($pid,self::META_SUMMARY,true);
        $pro = [get_post_meta($pid,self::META_PRO1,true),get_post_meta($pid,self::META_PRO2,true),get_post_meta($pid,self::META_PRO3,true)];
        $con = [get_post_meta($pid,self::META_CON1,true),get_post_meta($pid,self::META_CON2,true),get_post_meta($pid,self::META_CON3,true)];
        $pid_int = (int)$pid;
		$round = self::get_round_current($pid_int);
		list($avg,$sk_n) = self::get_rating_stats($pid_int, $round);
		list($yes,$no,$vote_n,$undecided) = self::get_vote_stats($pid_int, $round);
        $myR = self::get_user_rating_row($pid, get_current_user_id(), $round);
        $myV = self::get_user_vote_row($pid, get_current_user_id(), $round);
        $mySk = ($myR && isset($myR['value'])) ? (string)intval($myR['value']) : '';
        $myVote = ($myV && isset($myV['value'])) ? (string)$myV['value'] : '';
        $cats = wp_get_post_terms($pid, self::TAX_CAT, ['fields'=>'names']);
        $acts = wp_get_post_terms($pid, self::TAX_ACT, ['fields'=>'names']);
        $lvl_terms = wp_get_post_terms($pid, self::TAX_LVL, ['fields'=>'all']);
        $lvls = [];
        if (is_array($lvl_terms)){
            foreach($lvl_terms as $t){
                if (!is_object($t)) continue;
                $name = isset($t->name) ? (string)$t->name : '';
                if ($name === '') continue;
                $parent_id = isset($t->parent) ? intval($t->parent) : 0;
                $is_national = (0 === strcasecmp($name, 'National'));
                // Anzeige im Ansichtsmodus: ausser bei "National" als "Ebene / Name" (z.B. "Kanton / Sankt Gallen")
                if (!$is_national && $parent_id > 0){
                    $parent = get_term($parent_id, self::TAX_LVL);
                    if ($parent && !is_wp_error($parent) && isset($parent->name) && $parent->name){
                        $name = $parent->name.' / '.$name;
                    }
                }
                $lvls[] = $name;
            }
        }
        if (empty($lvls)){
            $lvls = wp_get_post_terms($pid, self::TAX_LVL, ['fields'=>'names']);
        }
        echo '<div class="bu-view-layout">';
        echo '<div class="bu-view-main">';
        echo '<table class="widefat striped" style="max-width:960px"><tbody>';
        echo '<tr><th style="width:220px">Titel</th><td>'.esc_html(get_the_title($pid)).'</td></tr>';
        $a_name = get_the_author_meta('display_name',$p->post_author);
        $a_url = esc_url(self::pm_url($pid, $p->post_author));
        echo '<tr><th>Autor</th><td>'.esc_html($a_name).' <a href="'.$a_url.'" title="Private Nachricht"><span class="dashicons dashicons-email"></span></a></td></tr>';
        echo '<tr><th>Kategorie</th><td>'.esc_html(implode(', ', $cats)).'</td></tr>';
        echo '<tr><th>Ebene</th><td>'.esc_html(implode(', ', $lvls)).'</td></tr>';
        $acts_txt = is_array($acts) ? implode(', ', $acts) : '';
        if (trim((string)$acts_txt) === '') $acts_txt = '–';
        echo '<tr><th>Vorstösse/Aktionen</th><td>'.esc_html($acts_txt).'</td></tr>';
        echo '<tr><th>Datum</th><td>'.esc_html(substr($p->post_date,0,10)).'</td></tr>';
        echo '<tr><th>Inhalt</th><td>'.wp_kses_post(apply_filters('the_content', $p->post_content)).'</td></tr>';
        echo '<tr><th>Zusammenfassung</th><td>'.nl2br(esc_html($sum)).'</td></tr>';
        echo '<tr><th>Vorteile</th><td><ul><li>'.esc_html($pro[0]).'</li><li>'.esc_html($pro[1]).'</li><li>'.esc_html($pro[2]).'</li></ul></td></tr>';
        echo '<tr><th>Nachteile</th><td><ul><li>'.esc_html($con[0]).'</li><li>'.esc_html($con[1]).'</li><li>'.esc_html($con[2]).'</li></ul></td></tr>';
        echo '<tr><th>SK-Ø / Abstimmung</th><td>'
            .'<span id="bu_stat_sk_avg">'.(is_null($avg)?'–':number_format_i18n($avg,1)).'</span> (n=<span id="bu_stat_sk_n">'.intval($sk_n).'</span>)'
            .' &nbsp; | &nbsp; '
            .'<span id="bu_stat_yes">'.intval($yes).'</span>/<span id="bu_stat_no">'.intval($no).'</span> (n=<span id="bu_stat_vote_n">'.intval($vote_n).'</span>)'
            .' <span class="bu-stat-undecided">unentschieden: <span id="bu_stat_undecided">'.intval($undecided).'</span></span>'
            .'</td></tr>';

        echo '</tbody></table>';
        echo '<h2>Bewertung & Abstimmung abgeben</h2>';
        echo '<form id="bu-rate-form" data-postid="'.intval($pid).'" method="post" onsubmit="return false;">';
        echo '<p>SK-Wert <span class="dashicons dashicons-editor-help" title="0 – Kein Widerstand&#10;1 – Minimaler Widerstand (voll ok)&#10;2 – Sehr geringer Widerstand&#10;3 – Geringer Widerstand&#10;4 – Spürbarer Widerstand&#10;5 – Mittlerer Widerstand (Überarbeitung nötig)&#10;6 – Deutlicher Widerstand&#10;7 – Hoher Widerstand&#10;8 – Sehr hoher Widerstand (Kommentar nötig)&#10;9 – Fast maximaler Widerstand (Kommentar nötig)&#10;10 – Maximaler Widerstand/Veto (Kommentar nötig)"></span>: <select id="bu_sk_value_view"><option value=""'.($mySk===''?' selected':'').'>—</option>';
        for($i=0;$i<=10;$i++){ echo '<option value="'.$i.'"'.selected($mySk,(string)$i,false).'>'.$i.'</option>'; }
        echo '</select></p>';
        echo '<p>Abstimmung: <label><input type="radio" name="vote" value="yes"'.checked($myVote,'yes',false).'> Ja</label> ';
        echo '<label><input type="radio" name="vote" value="no"'.checked($myVote,'no',false).'> Nein</label> ';
        echo '<label><input type="radio" name="vote" value="undecided"'.checked($myVote,'undecided',false).'> unentschieden</label></p>';
        echo '<p class="description">Hinweis: <em>unentschieden</em> wird gespeichert, zählt aber nicht in n (Ja/Nein).</p>';
        echo '<p><button class="button button-primary" type="submit">Speichern</button> ';
        echo '<span id="bu-rate-msg" style="margin-left:10px;color:#666"></span></p>';
        echo '</form>';
        echo '<h2>Einwände (Runde #'.intval($round).')</h2>';
        echo '<div id="bu-objections">'.self::render_objection_groups_html($pid, $round).'</div>';

        echo '</div>'; // bu-view-main
        echo self::render_similar_ideas_sidebar($pid);
        echo '</div>'; // bu-view-layout



        echo '</div>';
    }


    /*** Similar Ideas (Ansichtsmodus) ***/
    private static function render_similar_ideas_sidebar($idea_id){
        $items = self::get_similar_ideas($idea_id, 10);
        $out = '<aside class="bu-view-side"><h2>Ähnliche Ideen</h2>';
        if (empty($items)){
            $out .= '<div class="bu-sim-empty">Keine ähnlichen Ideen gefunden.</div>';
            $out .= '</aside>';
            return $out;
        }

        $favs = self::get_user_favorites();
        $fav_lookup = [];
        if (is_array($favs)) { foreach ($favs as $f) { $fav_lookup[intval($f)] = true; } }

        foreach ($items as $row){
            $pid = intval($row['id'] ?? 0);
            if (!$pid) continue;
            $title = get_the_title($pid);
            $url = esc_url(self::idea_admin_view_url($pid));

            $is_fav = isset($fav_lookup[$pid]);
            $star_svg = $is_fav
                ? '<svg fill="#2e8b57" viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87L18.18 22 12 18.56 5.82 22 7 14.14l-5-4.87 6.91-1.01L12 2z"/></svg>'
                : '<svg fill="#9aa0a6" viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87L18.18 22 12 18.56 5.82 22 7 14.14l-5-4.87 6.91-1.01L12 2z"/></svg>';
            $fav_link = '<a href="#" class="bu-fav-toggle bu-sim-fav" data-id="'.intval($pid).'" data-fav="'.($is_fav?'1':'0').'" title="Favorit" aria-label="Favorit">'.$star_svg.'</a>';

            $score = floatval($row['score'] ?? 0.0);
            $pct = max(0, min(100, (int)round($score * 100)));
            $hue = (int)round($pct * 1.2); // 0=rot, 120=grün
            $bars = 0;
            if ($pct > 0){
                $bars = (int)ceil($pct / 20);
                if ($bars < 1) $bars = 1;
                if ($bars > 5) $bars = 5;
            }

            $pct_badge = '<span class="bu-sim-pct" title="Ähnlichkeit: '.esc_attr($pct).'%">'.intval($pct).'%</span>';

            $bars_html = '';
            if ($bars > 0){
                $bars_html = '<span class="bu-sim-bars" aria-hidden="true" title="Ähnlichkeit: '.esc_attr($pct).'%">';
                for ($i=1; $i<=5; $i++){
                    $bars_html .= '<span class="bu-sim-barseg '.($i <= $bars ? 'on' : 'off').'">▮</span>';
                }
                $bars_html .= '</span>';
            }

            $progress = '<div class="bu-sim-progress" aria-hidden="true"><span style="width:'.intval($pct).'%"></span></div>';

$sum = get_post_meta($pid, self::META_SUMMARY, true);
            $excerpt = '';
            if (is_string($sum) && trim($sum) !== ''){
                $excerpt = wp_trim_words($sum, 18, '…');
            } else {
                $excerpt = wp_trim_words(wp_strip_all_tags(get_post_field('post_content', $pid)), 18, '…');
            }

            $cats = wp_get_post_terms($pid, self::TAX_CAT, ['fields'=>'names']);
            $cat_txt = '';
            if (is_array($cats) && !empty($cats)){
                $cat_txt = implode(', ', array_slice($cats, 0, 3));
            }

            $out .= '<div class="bu-sim-item" style="--bu-sim-h:'.esc_attr($hue).';">';
            $out .= $fav_link . $pct_badge . $bars_html;
            $out .= '<a class="bu-sim-title" href="'.$url.'">'.esc_html($title).'</a>';
            if ($cat_txt !== ''){
                $out .= '<div class="bu-sim-meta">'.esc_html($cat_txt).'</div>';
            }
            if ($excerpt !== ''){
                $out .= '<div class="bu-sim-excerpt">'.esc_html($excerpt).'</div>';
            }
            $out .= $progress;
            $out .= '</div>';
        }
        $out .= '</aside>';
        return $out;
    }
    private static function get_similar_ideas($idea_id, $limit=10){
        $idea_id = intval($idea_id);
        $limit = max(1, min(50, intval($limit)));
        if (!$idea_id) return [];

        // Ähnlichkeit nur über Titel + Inhalt/Beschreibung (keine Taxonomien)
        list($base_title, $base_body) = self::bu_tokenize_idea_parts($idea_id);

        // Performance: Similar-Ideas Ergebnis kurz cachen
        $base_mod = get_post_modified_time('U', true, $idea_id);
        $cache_key = 'bu_sim_' . md5($idea_id . '|' . $base_mod . '|' . $limit);
        $cached = get_transient($cache_key);
        if ($cached !== false && is_array($cached)){
            return $cached;
        }

        $meta_query = [
            'relation' => 'OR',
            ['key'=>self::META_ARCHIVED, 'compare'=>'NOT EXISTS'],
            ['key'=>self::META_ARCHIVED, 'value'=>'1', 'compare'=>'!='],
        ];

        $args = [
            'post_type'      => self::CPT,
            'post_status'    => 'any',
            'posts_per_page' => 300,
            'post__not_in'   => [$idea_id],
            'orderby'        => 'date',
            'order'          => 'DESC',
            'no_found_rows'  => true,
            'meta_query'     => $meta_query,
        ];

        $q = new WP_Query($args);
        $rows = [];

        if (!empty($q->posts)){
            foreach ($q->posts as $p){
                $pid = is_object($p) ? intval($p->ID) : intval($p);
                if (!$pid) continue;

                // Sichtbarkeit/Leserechte respektieren
                if (function_exists('current_user_can') && !current_user_can('read_post', $pid)) continue;

                list($cand_title, $cand_body) = self::bu_tokenize_idea_parts($pid);

                $title_sim = self::bu_jaccard($base_title, $cand_title);
                $body_sim  = self::bu_jaccard($base_body,  $cand_body);

                // Titel stärker gewichten
                $score = (0.65 * $title_sim) + (0.35 * $body_sim);
                if ($score <= 0) continue;
                if ($score > 1) $score = 1.0;

                $rows[] = ['id'=>$pid, 'score'=>$score];
            }
        }
        wp_reset_postdata();

        usort($rows, function($a, $b){
            $da = floatval($a['score'] ?? 0);
            $db = floatval($b['score'] ?? 0);
            if ($da === $db) return 0;
            return ($da < $db) ? 1 : -1;
        });

        $result = array_slice($rows, 0, $limit);
        set_transient($cache_key, $result, 10 * MINUTE_IN_SECONDS);
        return $result;
    }

    private static function bu_overlap_ratio($a, $b){
        if (empty($a) || empty($b)) return 0.0;
        $a = array_unique(array_map('intval', (array)$a));
        $b = array_unique(array_map('intval', (array)$b));
        $inter = array_intersect($a, $b);
        $den = max(1, max(count($a), count($b)));
        return count($inter) / $den;
    }

    private static function bu_tokenize_idea_parts($idea_id){
        $idea_id = intval($idea_id);
        $title = get_the_title($idea_id);
        $content = wp_strip_all_tags(get_post_field('post_content', $idea_id));
        $sum = get_post_meta($idea_id, self::META_SUMMARY, true);

        $title_tokens = self::bu_tokenize((string)$title);
        $body_tokens  = self::bu_tokenize(trim((string)$sum.' '.(string)$content));
        return [$title_tokens, $body_tokens];
    }


    private static function bu_tokenize_idea($idea_id){
        list($t, $b) = self::bu_tokenize_idea_parts($idea_id);
        // Merge sets
        return $t + $b;
    }


    private static function bu_tokenize($text){
        $text = (string)$text;
        if ($text === '') return [];
        $text = function_exists('mb_strtolower') ? mb_strtolower($text, 'UTF-8') : strtolower($text);
        // Nur Buchstaben/Zahlen behalten
        $text = preg_replace('/[^\p{L}\p{N}]+/u', ' ', $text);
        $parts = preg_split('/\s+/u', trim($text));
        if (!$parts) return [];

        $stop = [
            'und','oder','der','die','das','dass','ein','eine','einer','eines','einem','einen','den','dem','des',
            'ist','sind','war','waren','wird','werden','mit','ohne','für','fuer','auf','im','in','an','am','zu','zum','zur',
            'von','vom','bei','als','auch','nicht','nur','mehr','weniger','sehr','man','wir','ihr','sie','es','ich','du',
            'haben','hat','hätte','haette','kann','können','koennen','soll','sollen','muss','müssen','muessen'
        ];
        $stop = array_fill_keys($stop, true);

        $tokens = [];
        foreach ($parts as $w){
            $w = trim($w);
            if ($w === '') continue;
            if (function_exists('mb_strlen')){
                if (mb_strlen($w, 'UTF-8') < 3) continue;
            } else {
                if (strlen($w) < 3) continue;
            }
            if (isset($stop[$w])) continue;
            $tokens[$w] = true;
        }
        return $tokens; // set
    }

    private static function bu_jaccard($a, $b){
        if (empty($a) || empty($b)) return 0.0;
        $ka = array_keys($a);
        $kb = array_keys($b);
        $inter = array_intersect($ka, $kb);
        $union = array_unique(array_merge($ka, $kb));
        $den = max(1, count($union));
        return count($inter) / $den;
    }






    /*** Tabs + Daisy ***/
    /**
     * Liefert die "Root"-Ebenen in einer stabilen Reihenfolge:
     * 1) Standard (National/Kanton/Stadt/Lokal) falls vorhanden,
     * 2) danach zusätzliche Root-Ebenen alphabetisch.
     */
    private static function get_root_level_terms_ordered(){
        $terms = self::get_terms_cached(self::TAX_LVL, [
            'hide_empty' => false,
            'parent'     => 0,
            'orderby'    => 'name',
            'order'      => 'ASC',
        ], 20);
        if (!is_array($terms)) $terms = [];

        $by_slug = [];
        foreach ($terms as $t){
            if (is_object($t) && isset($t->slug)) $by_slug[(string)$t->slug] = $t;
        }

        $ordered = [];
        $map = self::find_level_terms_map();
        foreach (['national','kanton','stadt','lokal'] as $std){
            $real = isset($map[$std]) ? (string)$map[$std] : (string)$std;
            if (isset($by_slug[$real])){
                $ordered[] = $by_slug[$real];
                unset($by_slug[$real]);
            }
        }
        // Rest
        foreach ($by_slug as $t){
            $ordered[] = $t;
        }
        return $ordered;
    }

    private static function render_tabs($context='ideas', $active_level=''){
    $levels = self::get_root_level_terms_ordered();

	    $base_page = ($context === 'dashboard') ? 'bottomup_dashboard' : (($context === 'tasks') ? 'bottomup_tasks' : 'bottomup_ideas');
    $fav_on = (isset($_GET['fav']) && $_GET['fav']=='1');
    $arch_on = (isset($_GET['arch']) && $_GET['arch']=='1');
    $cat_cur = isset($_GET['cat']) ? sanitize_text_field($_GET['cat']) : '';
    $act_cur = isset($_GET['act']) ? sanitize_text_field($_GET['act']) : '';

    echo '<div class="bu-tabs-row">';
    echo '<div class="bu-tabs-label">Ebenen</div>';
    echo '<div class="bu-tabs bu-tabs-centered" role="tablist">';

    // Ebenen-Tabs (inkl. 'Alle'). Favoriten/Archiv/weitere Filter werden mitgenommen.
    $all_args = ['page'=>$base_page];
    if ($fav_on){ $all_args['fav'] = 1; }
    if ($arch_on){ $all_args['arch'] = 1; }
    if ($cat_cur){ $all_args['cat'] = $cat_cur; }
    if ($act_cur){ $all_args['act'] = $act_cur; }
    $all_href = esc_url(add_query_arg($all_args, admin_url('admin.php')));
    echo '<a class="bu-tab'.(empty($active_level)?' active':'').'" role="tab" href="'.$all_href.'">Alle</a>';

    // Ebenen-Tabs (2. Klick auf aktive Ebene hebt nur Ebenen-Filter auf.)
    foreach ($levels as $term){
        if (!is_object($term) || empty($term->slug)) continue;
        $slug  = (string)$term->slug;
        $label = isset($term->name) ? (string)$term->name : $slug;
        $is_active = ($active_level === $slug) ? ' active' : '';
        if ($active_level === $slug) {
            // Aktive Ebene -> zweiter Klick: Ebene entfernen, Favoriten-Flag behalten
            $args = ['page'=>$base_page];
            if ($fav_on){ $args['fav'] = 1; }
            if ($arch_on){ $args['arch'] = 1; }
            if ($cat_cur){ $args['cat'] = $cat_cur; }
            if ($act_cur){ $args['act'] = $act_cur; }
        } else {
            $args = ['page'=>$base_page, 'level'=>$slug];
            if ($fav_on){ $args['fav'] = 1; }   // Kombifilter: fav bleibt aktiv
            if ($arch_on){ $args['arch'] = 1; }
            if ($cat_cur){ $args['cat'] = $cat_cur; }
            if ($act_cur){ $args['act'] = $act_cur; }
        }
        $href = esc_url(add_query_arg($args, admin_url('admin.php')));
        echo '<a class="bu-tab'.$is_active.'" data-level="'.esc_attr($slug).'" role="tab" href="'.$href.'">'.esc_html($label).'</a>';
    }

    // Favoriten Toggle
    $fav_args = ['page'=>$base_page];
    if (!empty($active_level)) { $fav_args['level'] = $active_level; }
    if ($arch_on){ $fav_args['arch'] = 1; }
    if ($cat_cur){ $fav_args['cat'] = $cat_cur; }
    if ($act_cur){ $fav_args['act'] = $act_cur; }
    if (!$fav_on) { $fav_args['fav'] = 1; } // 1. Klick AN, 2. Klick AUS
    $fav_href = esc_url(add_query_arg($fav_args, admin_url('admin.php')));
    $fav_class = 'bu-tab bu-tab-favorites-toggle'.($fav_on?' active':'');
    echo '<a class="'.$fav_class.'" data-fav="1" role="tab" href="'.$fav_href.'">Favoriten</a>';

    echo '</div>'; // tabs

    // Rechts: Archiv-Toggle (nur Ideenliste)
    if (in_array($context, ['ideas','tasks'], true)){
        $arch_args = ['page'=>$base_page];
        if (!empty($active_level)) { $arch_args['level'] = $active_level; }
        if ($fav_on) { $arch_args['fav'] = 1; }
        if ($cat_cur) { $arch_args['cat'] = $cat_cur; }
        if ($act_cur) { $arch_args['act'] = $act_cur; }
        if (!$arch_on) { $arch_args['arch'] = 1; } // 1. Klick Archiv AN, 2. Klick AUS
        $arch_href = esc_url(add_query_arg($arch_args, admin_url('admin.php')));
        echo '<div class="bu-tabs-actions">';
        echo '<a class="bu-arch-switch'.($arch_on?' on':' off').'" href="'.$arch_href.'">'
            . '<span class="bu-arch-left">Aktuell</span>'
            . '<span class="bu-arch-knob" aria-hidden="true"></span>'
            . '<span class="bu-arch-right">Archiv</span>'
            . '</a>';
        echo '</div>';
    }

    echo '</div>'; // row

}

    /**
     * Ideenliste: zusätzliche Button-Filter für Kategorien und Vorstösse/Aktionen.
     * Ebene bleibt über die Tabs oben steuerbar.
     */
    
/*** Performance: short transient caching for term lists (button filters etc.) ***/
private static function get_terms_cached($taxonomy, $args = [], $ttl = 20){
    $taxonomy = (string)$taxonomy;
    $args = is_array($args) ? $args : [];
    $ttl = intval($ttl);
    if ($ttl < 1) $ttl = 1;
    // Cache-Key muss sich bei Term-Änderungen automatisch ändern, damit neue Ebenen/Kategorien
    // sofort sichtbar werden (ohne warten auf TTL). WordPress pflegt dafür ein "last_changed".
    $last_changed = '';
    if (function_exists('wp_cache_get_last_changed')){
        $last_changed = (string) wp_cache_get_last_changed('terms');
    } else {
        $lc = wp_cache_get('last_changed', 'terms');
        $last_changed = is_string($lc) ? $lc : '';
    }
    $key = 'bu_terms_' . md5($taxonomy . '|' . maybe_serialize($args) . '|' . $last_changed);
    $cached = get_transient($key);
    if ($cached !== false && is_array($cached)){
        return $cached;
    }
    $terms = get_terms(array_merge(['taxonomy' => $taxonomy], $args));
    if (is_wp_error($terms) || !is_array($terms)) $terms = [];
    set_transient($key, $terms, $ttl);
    return $terms;
}

private static function render_ideas_button_filters($active_level, $active_cat, $active_act, $fav_on=false, $arch_on=false, $base_page='bottomup_ideas'){
        $base_page = $base_page ? $base_page : 'bottomup_ideas';
        $base_common = ['page' => $base_page];
        if (!empty($active_level)) $base_common['level'] = $active_level;
        if ($fav_on) $base_common['fav'] = 1;
        if ($arch_on) $base_common['arch'] = 1;

        $cats = self::get_terms_cached(self::TAX_CAT, ['hide_empty'=>false,'orderby'=>'name','order'=>'ASC'], 20);
        $acts = self::get_terms_cached(self::TAX_ACT, ['hide_empty'=>false,'orderby'=>'name','order'=>'ASC'], 20);

        echo '<div class="bu-filterbars">';

        // Kategorien
        echo '<div class="bu-filterbar">';
        echo '  <div class="bu-filterbar-label">Kategorien</div>';
        echo '  <div class="bu-chip-row">';

        $all_args = $base_common;
        if (!empty($active_act)) $all_args['act'] = $active_act;
        $all_href = esc_url(add_query_arg($all_args, admin_url('admin.php')));
        echo '<a class="bu-chip'.(empty($active_cat)?' active':'').'" href="'.$all_href.'">Alle</a>';

        foreach ($cats as $t){
            $args = $base_common;
            if (!empty($active_act)) $args['act'] = $active_act;
            $is_active = ($active_cat === $t->slug);
            if (!$is_active) $args['cat'] = $t->slug; // aktive Kategorie erneut klicken => Filter entfernen
            $href = esc_url(add_query_arg($args, admin_url('admin.php')));
            echo '<a class="bu-chip'.($is_active?' active':'').'" href="'.$href.'">'.esc_html($t->name).'</a>';
        }
        echo '  </div>';
        echo '</div>';

        // Vorstösse/Aktionen
        echo '<div class="bu-filterbar">';
        echo '  <div class="bu-filterbar-label">Vorstösse/Aktionen</div>';
        echo '  <div class="bu-chip-row">';
        $all_args = $base_common;
        if (!empty($active_cat)) $all_args['cat'] = $active_cat;
        $all_href = esc_url(add_query_arg($all_args, admin_url('admin.php')));
        echo '<a class="bu-chip'.(empty($active_act)?' active':'').'" href="'.$all_href.'">Alle</a>';
        foreach ($acts as $t){
            $args = $base_common;
            if (!empty($active_cat)) $args['cat'] = $active_cat;
            $is_active = ($active_act === $t->slug);
            if (!$is_active) $args['act'] = $t->slug;
            $href = esc_url(add_query_arg($args, admin_url('admin.php')));
            echo '<a class="bu-chip'.($is_active?' active':'').'" href="'.$href.'">'.esc_html($t->name).'</a>';
        }
        echo '  </div>';
        echo '</div>';

        echo '</div>';
    }
/*** Performance: cache per-level category counts for dashboard daisy ***/
private static function get_daisy_counts_cached($cats, $level_term){
    $level_id = 0;
    if ($level_term && !is_wp_error($level_term)){
        $level_id = intval($level_term->term_id);
    }
    $cat_ids = [];
    if (is_array($cats)){
        foreach ($cats as $t){
            if (is_object($t) && isset($t->term_id)){
                $cat_ids[] = intval($t->term_id);
            }
        }
    }
    sort($cat_ids);
    $key = 'bu_daisy_counts_' . $level_id . '_' . md5(implode(',', $cat_ids));
    $cached = get_transient($key);
    if ($cached !== false && is_array($cached)){
        return $cached;
    }

    $map = [];
    if (!empty($cat_ids)){
        foreach ($cats as $t){
            if (!is_object($t) || !isset($t->term_id)) continue;
            $tax_q = [
                'relation' => 'AND',
                [
                    'taxonomy' => self::TAX_CAT,
                    'field'    => 'term_id',
                    'terms'    => [intval($t->term_id)],
                ]
            ];
            if ($level_term && !is_wp_error($level_term)){
                $tax_q[] = [
                    'taxonomy' => self::TAX_LVL,
                    'field'    => 'term_id',
                    'terms'    => [intval($level_term->term_id)],
                ];
            }
            // Only count rows (don't load all posts)
            $count_q = new \WP_Query([
                'post_type'      => self::CPT,
                'post_status'    => 'any',
                'fields'         => 'ids',
                'posts_per_page' => 1,
                'tax_query'      => $tax_q,
            ]);
            $map[intval($t->term_id)] = intval($count_q->found_posts);
        }
    }

    set_transient($key, $map, 30);
    return $map;
}

/*** Dashboard Daisy: Ebenen als Blüten (Root-Terme) ***/
private static function get_daisy_level_counts_cached($levels){
    $ids = [];
    if (is_array($levels)){
        foreach ($levels as $t){
            if (is_object($t) && isset($t->term_id)) $ids[] = intval($t->term_id);
        }
    }
    $ids = array_values(array_filter(array_unique($ids)));
    sort($ids);

    $last_terms = '';
    $last_posts = '';
    if (function_exists('wp_cache_get_last_changed')){
        $last_terms = (string) wp_cache_get_last_changed('terms');
        $last_posts = (string) wp_cache_get_last_changed('posts');
    } else {
        $lc = wp_cache_get('last_changed', 'terms');
        $last_terms = is_string($lc) ? $lc : '';
        $lc2 = wp_cache_get('last_changed', 'posts');
        $last_posts = is_string($lc2) ? $lc2 : '';
    }

    $key = 'bu_daisy_lvl_counts_' . md5(implode(',', $ids) . '|' . $last_terms . '|' . $last_posts);
    $cached = get_transient($key);
    if ($cached !== false && is_array($cached)){
        return $cached;
    }

    $map = [];
    foreach ($ids as $tid){
        // Ebenen: Kinder mitrechnen (Untergruppen)
        $map[$tid] = self::count_active_ideas_for_term(self::TAX_LVL, $tid, true);
    }
    set_transient($key, $map, 20);
    return $map;
}

private static function render_daisy_levels(){
    $levels = self::get_root_level_terms_ordered();
    $n = count($levels); $R = 160; $rx=70; $ry=26; $cx=220; $cy=220;
    $ideas_url = admin_url('admin.php?page=bottomup_ideas');
    $current_level = isset($_GET['level']) ? sanitize_text_field($_GET['level']) : '';

    $count_map = self::get_daisy_level_counts_cached($levels);

    echo '<div class="bu-daisy-wrap"><svg class="bu-daisy" viewBox="0 0 440 440" width="520" height="520">';
    echo '<circle class="bu-center" cx="'.$cx.'" cy="'.$cy.'" r="44"></circle>';
    echo '<text class="bu-center-text" x="'.$cx.'" y="'.($cy+5).'" text-anchor="middle">Ebenen</text>';

    for ($i=0; $i<$n; $i++){
        $t = $levels[$i];
        if (!is_object($t) || empty($t->slug)) continue;
        $count = (isset($t->term_id) && isset($count_map[intval($t->term_id)])) ? intval($count_map[intval($t->term_id)]) : 0;

        $angle = ($n>0) ? (360.0 * $i / $n) : 0.0; $rad = deg2rad($angle);
        $px = $cx + $R * cos($rad); $py = $cy + $R * sin($rad); $rot = $angle + 90;
        $is_current = ($current_level && $current_level === $t->slug);

        // zweiter Klick auf dasselbe Blatt: Ebene-Filter entfernen
        $href = $ideas_url;
        if (!$is_current){
            $href .= '&level=' . $t->slug;
        }

        echo '<a xlink:href="'.esc_url($href).'" href="'.esc_url($href).'">';
        echo '<g class="bu-petal" data-level="'.esc_attr($t->slug).'" style="cursor:pointer" onclick="window.location=\''.esc_js($href).'\';">';
        echo '<title>'.esc_html($t->name).' ('.$count.')</title>';
        echo '<ellipse class="bu-ellipse" cx="'.$px.'" cy="'.$py.'" rx="'.$rx.'" ry="'.$ry.'" transform="rotate('.$rot.' '.$px.' '.$py.')" />';
        echo '<text class="bu-txt" x="'.$px.'" y="'.($py-2).'" text-anchor="middle">'.esc_html($t->name).'</text>';
        echo '<text class="bu-cnt" x="'.$px.'" y="'.($py+14).'" text-anchor="middle">'.esc_html($count).'</text>';
        echo '</g></a>';
    }

    echo '</svg></div>';
}



    private static function render_daisy($active_level=''){
        $cats = self::get_terms_cached(self::TAX_CAT, ['hide_empty'=>false], 30);
        $n = count($cats); $R = 160; $rx=70; $ry=26; $cx=220; $cy=220;
        $ideas_url = admin_url('admin.php?page=bottomup_ideas');
        $slugs = self::find_level_terms_map();
        $active_level_real = $active_level;
        foreach ($slugs as $std=>$real){ if ($active_level===$std) $active_level_real=$real; }
        $current_cat = isset($_GET['cat']) ? sanitize_text_field($_GET['cat']) : '';
        echo '<div class="bu-daisy-wrap"><svg class="bu-daisy" viewBox="0 0 440 440" width="520" height="520">';
        echo '<circle class="bu-center" cx="'.$cx.'" cy="'.$cy.'" r="44"></circle>';
        echo '<text class="bu-center-text" x="'.$cx.'" y="'.($cy+5).'" text-anchor="middle">Ideen</text>';
        $level_term = null;
        if ($active_level_real){
            $level_term = get_term_by('slug', $active_level_real, self::TAX_LVL);
        }
        // Counts aus Cache (v2.44 Performance)
        $count_map = self::get_daisy_counts_cached($cats, $level_term);
        for ($i=0; $i<$n; $i++){
            $t = $cats[$i];
            $count = (is_object($t) && isset($t->term_id) && isset($count_map[intval($t->term_id)])) ? intval($count_map[intval($t->term_id)]) : 0;
            $angle = ($n>0) ? (360.0 * $i / $n) : 0.0; $rad = deg2rad($angle);
            $px = $cx + $R * cos($rad); $py = $cy + $R * sin($rad); $rot = $angle + 90;
            $is_current = ($current_cat && $current_cat === $t->slug);
            if ($is_current) {
                // zweiter Klick auf dasselbe Blatt: Kategorie-Filter entfernen, Ebene beibehalten
                $href = $ideas_url . ($active_level_real ? '&level=' . $active_level_real : '');
            } else {
                $href = $ideas_url . '&cat=' . $t->slug . ($active_level_real ? '&level=' . $active_level_real : '');
            }
            echo '<a xlink:href="'.esc_url($href).'" href="'.esc_url($href).'">';
            echo '<g class="bu-petal" data-cat="'.esc_attr($t->slug).'" style="cursor:pointer" onclick="window.location=\''.esc_js($href).'\';">';
            echo '<title>'.esc_html($t->name).' ('.$count.')</title>';
            echo '<ellipse class="bu-ellipse" cx="'.$px.'" cy="'.$py.'" rx="'.$rx.'" ry="'.$ry.'" transform="rotate('.$rot.' '.$px.' '.$py.')" />';
            echo '<text class="bu-txt" x="'.$px.'" y="'.($py-2).'" text-anchor="middle">'.esc_html($t->name).'</text>';
            echo '<text class="bu-cnt" x="'.$px.'" y="'.($py+14).'" text-anchor="middle">'.esc_html($count).'</text>';
            echo '</g></a>';
        }
        echo '</svg></div>';
    }

    /*** Tabelle ***/
    private static function render_table_html($rows){
        if (empty($rows)) return '<p>Keine Ideen gefunden.</p>';
        $favs = self::get_user_favorites();
        $fav_set = array_flip($favs);
        $back_val = '';
        if (isset($_SERVER['REQUEST_URI'])) {
            $req = wp_unslash($_SERVER['REQUEST_URI']);
            $parts = wp_parse_url($req);
            if (!empty($parts['query'])) {
                $back_val = rawurlencode(base64_encode($parts['query']));
            }
        }

        $cur_level = isset($_GET['level']) ? sanitize_text_field($_GET['level']) : '';
        $cur_cat   = isset($_GET['cat'])   ? sanitize_text_field($_GET['cat'])   : '';
        $cur_act   = isset($_GET['act'])   ? sanitize_text_field($_GET['act'])   : '';
        $cur_fav   = (isset($_GET['fav']) && $_GET['fav']=='1');
        $cur_arch  = (isset($_GET['arch']) && $_GET['arch']=='1');

        $common_args = ['page' => 'bottomup_ideas'];
        if ($cur_level) $common_args['level'] = $cur_level;
        if ($cur_cat)   $common_args['cat']   = $cur_cat;
        if ($cur_act)   $common_args['act']   = $cur_act;
        if ($cur_fav)   $common_args['fav']   = 1;
        if ($cur_arch)  $common_args['arch']  = 1;

        $h  = '<table class="widefat striped bu-table"><thead><tr>'
            . '<th class="sortable" data-key="id">ID</th>'
            . '<th class="sortable" data-key="title">Titel</th>'
            . '<th class="sortable" data-key="author">Autor</th>'
            . '<th class="sortable" data-key="date">Datum</th>'
            . '<th class="sortable" data-key="sk">SK-Wert</th>'
            . '<th class="sortable" data-key="vote">Abstimmung</th>'
            . '<th class="sortable" data-key="cat">Kategorien</th>'
            . '<th class="sortable" data-key="lvl">Ebenen</th>'
            . '<th class="sortable" data-key="act">Vorstösse/Aktionen</th>'
            . '<th class="sortable" data-key="round">Runden #</th>'
            . '<th class="bu-actions-cell"><span>Aktionen</span></th>'
            . '</tr>'
            . '<tr class="bu-filter-row">'
            . '<td><input type="search" class="bu-filter" data-name="id"     placeholder="ID…"></td>'
            . '<td><input type="search" class="bu-filter" data-name="title"  placeholder="Titel…"></td>'
            . '<td><input type="search" class="bu-filter" data-name="author" placeholder="Autor…"></td>'
            . '<td><input type="search" class="bu-filter" data-name="date"   placeholder="YYYY-MM-DD"></td>'
            . '<td><input type="search" class="bu-filter" data-name="sk"     placeholder="z.B. 7 oder 7.5"></td>'
            . '<td><input type="search" class="bu-filter" data-name="vote"   placeholder="z. B. 3/1"></td>'
            . '<td><input type="search" class="bu-filter" data-name="cat"    placeholder="Kategorien…"></td>'
            . '<td><input type="search" class="bu-filter" data-name="lvl"    placeholder="Ebenen…"></td>'
            . '<td><input type="search" class="bu-filter" data-name="act"    placeholder="Aktionen…"></td>'
            . '<td></td>'
            . '<td></td>'
            . '</tr></thead><tbody>';

        foreach ($rows as $r) {
            $date = substr($r['date'], 0, 10);
            $sk   = is_null($r['sk_avg']) ? '–' : (number_format($r['sk_avg'], 2, ',', '.') . ' (' . intval($r['sk_n'] ?? 0) . ')');
            $vote = intval($r['yes']).'/'.intval($r['no']) . ' (' . intval($r['vote_n'] ?? (intval($r['yes'])+intval($r['no']))) . ')';

            $cats = array();
            foreach ($r['cats_all'] as $c) {
                $args = $common_args;
                $args['cat'] = $c['slug'];
                $cats[] = '<a href="'.esc_url(add_query_arg($args, admin_url('admin.php'))).'">'.esc_html($c['name']).'</a>';
            }

            $lvls = array();
            foreach ($r['lvls_all'] as $l) {
                $args = $common_args;
                $args['level'] = $l['slug'];
                $lvls[] = '<a href="'.esc_url(add_query_arg($args, admin_url('admin.php'))).'">'.esc_html($l['name']).'</a>';
            }

            $acts = array();
            foreach (($r['acts_all'] ?? []) as $a) {
                $args = $common_args;
                $args['act'] = $a['slug'];
                $acts[] = '<a href="'.esc_url(add_query_arg($args, admin_url('admin.php'))).'">'.esc_html($a['name']).'</a>';
            }

            $query_args_view = ['page' => 'bottomup_view', 'post' => $r['id']];
            $query_args_print = ['page' => 'bottomup_print', 'post' => $r['id']];
            if (!empty($back_val)) {
                $query_args_view['ret'] = $back_val;
                $query_args_print['ret'] = $back_val;
            }
            $view  = esc_url(add_query_arg($query_args_view, admin_url('admin.php')));
            $edit  = esc_url(!empty($back_val) ? add_query_arg('ret', $back_val, get_edit_post_link($r['id'], '')) : get_edit_post_link($r['id'], ''));
            $print = esc_url(add_query_arg($query_args_print, admin_url('admin.php')));
            $tasks = esc_url(add_query_arg(['page'=>'bottomup_tasks_board','idea'=>$r['id']], admin_url('admin.php')));


            $state = isset($r['state']) && $r['state'] ? $r['state'] : 'active';
            $is_done = ($state === 'done');
            $is_arch = (isset($r['archived']) && ((string)$r['archived'] === '1'));
            $state_icon = $is_done ? '<span class="dashicons dashicons-yes-alt bu-state-icon bu-state-done" title="Abgeschlossen"></span>'
                                  : '<span class="dashicons dashicons-marker bu-state-icon bu-state-active" title="Offen"></span>';
            $arch_icon  = $is_arch ? '<span class="dashicons dashicons-archive bu-state-icon bu-arch-icon" title="Archiviert"></span>' : '';

            $is_fav = isset($fav_set[(int)$r['id']]);
            $star = $is_fav ? '<svg fill="#2e8b57" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87L18.18 22 12 18.56 5.82 22 7 14.14l-5-4.87 6.91-1.01L12 2z"/></svg>' : '<svg fill="#9aa0a6" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87L18.18 22 12 18.56 5.82 22 7 14.14l-5-4.87 6.91-1.01L12 2z"/></svg>';

            $round = isset($r['round']) ? intval($r['round']) : self::get_round_current(intval($r['id']));

            $h .= '<tr>'
                . '<td class="bu-id">'.intval($r['id']).'</td>'
                . '<td>'.esc_html($r['title']).'</td>'
                . '<td>'.esc_html($r['author']).'</td>'
                . '<td>'.esc_html($date).'</td>'
                . '<td>'.esc_html($sk).'</td>'
                . '<td>'.esc_html($vote).'</td>'
                . '<td>'.implode(', ', $cats).'</td>'
                . '<td>'.implode(', ', $lvls).'</td>'
                . '<td>'.implode(', ', $acts).'</td>'
                . '<td><span class="bu-round-badge" title="Runde #'.intval($round).'">'.intval($round).'</span></td>'
                . '<td class="bu-actions">'
                    . '<span class="bu-row-actions" style="display:inline-flex;gap:10px;align-items:center;visibility:visible;opacity:1;"><a href="#" class="bui-icon-link bu-fav-toggle" data-id="'.intval($r['id']).'" data-fav="'.($is_fav?'1':'0').'" title="Meine Favoriten" aria-label="Meine Favoriten" style="order:0;display:inline-flex;align-items:center;">'.$star.'</a>'
                        . '<a href="'.$view.'" title="Ansehen" aria-label="Ansehen" style="order:1;display:inline-flex;align-items:center;"><svg fill="#2271b1" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M12 5c-7 0-10 7-10 7s3 7 10 7 10-7 10-7-3-7-10-7zm0 12a5 5 0 1 1 0-10 5 5 0 0 1 0 10zm0-2.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z"/></svg></a>'
                        . '<a href="'.$edit.'" title="Bearbeiten" aria-label="Bearbeiten" style="order:2;display:inline-flex;align-items:center;"><svg fill="#dba617" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zm2.92 2.83H5v-.92l9.06-9.06.92.92L5.92 20.08zM20.71 7.04a1 1 0 0 0 0-1.41l-2.34-2.34a1 1 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg></a>'
                        . '<a href="'.$print.'" title="Drucken" aria-label="Drucken" style="order:3;display:inline-flex;align-items:center;"><svg fill="#2e8b57" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M6 9V3h12v6H6zm10-2V5H8v2h8zM6 19v-4h12v4H6zm14-10a3 3 0 0 1 3 3v5h-3v4H4v-4H1v-5a3 3 0 0 1 3-3h16zm1 6v-3a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v3h2v-2h14v2h2z"/></svg></a>'
                        . '<a href="'.$tasks.'" title="Tasks" style="order:4;display:inline-flex;align-items:center;"><span class="dashicons dashicons-clipboard" style="font-size:20px;line-height:20px;width:20px;height:20px;"></span></a>'
                        . $state_icon . $arch_icon
                        . ''
                    . '</span>'
                . '</td>'
                . '</tr>';
        }

        $h .= '</tbody></table>';
        $h .= '<div class="tablenav bottom"><div class="tablenav-pages bu-pager"></div></div>';
        return $h;
    }


/*** Daten holen ***/
    private static function query_ideas($level_slug, $cat_slug, $act_slug='', $fav_on=false, $arch_on=false){
        $tax_query = [];

        if ($cat_slug) {
            $tax_query[] = [
                'taxonomy' => self::TAX_CAT,
                'field'    => 'slug',
                'terms'    => $cat_slug,
            ];
        }

        if ($act_slug) {
            $tax_query[] = [
                'taxonomy' => self::TAX_ACT,
                'field'    => 'slug',
                'terms'    => $act_slug,
            ];
        }

        if ($level_slug) {
            // Mappe Standard-Slugs (national/kanton/stadt/lokal) auf echte Terms, falls nötig
            $slugs = self::find_level_terms_map();
            $level_real = $level_slug;
            if (isset($slugs[$level_slug])) {
                $level_real = $slugs[$level_slug];
            }
            $level_term = get_term_by('slug', $level_real, self::TAX_LVL);
            if ($level_term && !is_wp_error($level_term)) {
                $tax_query[] = [
                    'taxonomy' => self::TAX_LVL,
                    'field'    => 'term_id',
                    'terms'    => [$level_term->term_id],
                    'include_children' => true,
                ];
            }
        }

        $args = [
            'post_type'      => self::CPT,
            'post_status'    => 'any',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'no_found_rows'  => true,
        ];
        if (!empty($tax_query)) {
            $args['tax_query'] = $tax_query;
        }

        // Archiv-Filter: entweder nur Archiv oder nur Aktuell (default)
        if ($arch_on){
            $args['meta_query'] = [
                [
                    'key'     => self::META_ARCHIVED,
                    'value'   => '1',
                    'compare' => '=',
                ]
            ];
        } else {
            $args['meta_query'] = [
                'relation' => 'OR',
                [ 'key' => self::META_ARCHIVED, 'compare' => 'NOT EXISTS' ],
                [ 'key' => self::META_ARCHIVED, 'value' => '1', 'compare' => '!=' ],
            ];
        }

        // Favoritenfilter optional ergänzen
        $favs_for_filter = [];
        if ($fav_on) {
            $favs_for_filter = self::get_user_favorites();
            if (empty($favs_for_filter)) {
                return [];
            }
            $args['post__in'] = array_map('intval', $favs_for_filter);
            $args['orderby']  = 'post__in';
        } else {
            $args['orderby'] = 'date';
            $args['order']   = 'DESC';
        }

        $q = new \WP_Query($args);

        // Performance: Meta/Term Caches primen
        if (!empty($q->posts) && is_array($q->posts)){
            $ids = array_map('intval', $q->posts);
            if (!empty($ids)){
                update_meta_cache('post', $ids);
                update_object_term_cache($ids, self::CPT);
            }
        }

        // Alle Favoriten (für UI) holen
        $favs_all = self::get_user_favorites();
        $fav_set_all = array_flip(array_map('intval', $favs_all));

        $out = [];
        foreach ($q->posts as $pid){
            $pid_int = (int)$pid;
            if (!current_user_can('read_post', $pid_int)) continue;
            $round = self::get_round_current($pid_int);
            list($avg,$sk_n) = self::get_rating_stats($pid_int, $round);
            list($yes,$no,$vote_n,$undecided) = self::get_vote_stats($pid_int, $round);
            $cats_full = wp_get_post_terms($pid_int, self::TAX_CAT, ['fields'=>'all']);
            $lvls_full = wp_get_post_terms($pid_int, self::TAX_LVL, ['fields'=>'all']);
			$acts_full = wp_get_post_terms($pid_int, self::TAX_ACT, ['fields'=>'all']);
            $cats_all = [];
            foreach ($cats_full as $t){ $cats_all[] = ['slug'=>$t->slug,'name'=>$t->name]; }
            $lvls_all = [];
            foreach ($lvls_full as $t){ $lvls_all[] = ['slug'=>$t->slug,'name'=>$t->name]; }
			$acts_all = [];
			foreach ($acts_full as $t){ $acts_all[] = ['slug'=>$t->slug,'name'=>$t->name]; }

            $out[] = [
                'id'        => $pid_int,
                'title'     => get_the_title($pid_int),
                'author'    => get_the_author_meta('display_name', get_post_field('post_author',$pid_int)),
                'date'      => get_post_field('post_date',$pid_int),
                'round'     => $round,
                'sk_avg'    => is_null($avg) ? null : floatval(number_format($avg,4,'.','')),
                'sk_n'      => intval($sk_n),
                'yes'       => intval($yes),
                'no'        => intval($no),
                'vote_n'    => intval($vote_n),
                'cats_all'  => $cats_all,
				'lvls_all'  => $lvls_all,
				'acts_all'  => $acts_all,
                'edit_link' => get_edit_post_link($pid_int,''),
                'is_fav'    => isset($fav_set_all[$pid_int]),
                'state'     => (get_post_meta($pid_int, self::META_STATE, true) ?: 'active'),
                'archived'  => (get_post_meta($pid_int, self::META_ARCHIVED, true) ?: '0'),
            ];
        }

        return $out;
    }

	/**
	 * Zählt aktive (nicht-archivierte) Ideen, die einem bestimmten Term zugeordnet sind.
	 * Wird genutzt, um das Löschen von Taxonomie-Begriffen zu verhindern, solange noch aktive Ideen existieren.
	 */
	private static function count_active_ideas_for_term($tax, $term_id, $include_children=false){
		$term_id = intval($term_id);
		if (!$term_id || !taxonomy_exists($tax)) return 0;

		$meta_query = [
			'relation' => 'OR',
			['key' => self::META_ARCHIVED, 'compare' => 'NOT EXISTS'],
			['key' => self::META_ARCHIVED, 'value' => '1', 'compare' => '!='],
		];

		$args = [
			'post_type'      => self::CPT,
			'post_status'    => ['publish','pending','draft','future','private'],
			'posts_per_page' => 1,
			'fields'         => 'ids',
			'no_found_rows'  => false,
			'meta_query'     => $meta_query,
			'tax_query'      => [[
				'taxonomy'         => $tax,
				'field'            => 'term_id',
				'terms'            => [$term_id],
				'include_children' => $include_children ? true : false,
			]],
		];
		$q = new WP_Query($args);
		return isset($q->found_posts) ? intval($q->found_posts) : 0;
	}













    /*** Metaboxen ***/
    public static function metabox_info(){ add_meta_box('bu_info_box','Zusatzinformationen',[__CLASS__,'box_info'],self::CPT,'normal','default'); }
    public static function box_info($post){
        $summary=get_post_meta($post->ID,self::META_SUMMARY,true);
        $pro1=get_post_meta($post->ID,self::META_PRO1,true);
        $pro2=get_post_meta($post->ID,self::META_PRO2,true);
        $pro3=get_post_meta($post->ID,self::META_PRO3,true);
        $con1=get_post_meta($post->ID,self::META_CON1,true);
        $con2=get_post_meta($post->ID,self::META_CON2,true);
        $con3=get_post_meta($post->ID,self::META_CON3,true);
        echo '<table class="form-table"><tbody>';
        echo '<tr><th><label for="bu_summary">Zusammenfassung (max. 250)</label></th><td><textarea id="bu_summary" name="bu_summary" rows="3" maxlength="250" style="width:100%;">'.esc_textarea($summary).'</textarea></td></tr>';
        echo '<tr><th>Vorteile (je max. 100)</th><td>';
        echo '<input type="text" name="bu_pro1" maxlength="100" style="width:100%;margin-bottom:6px" value="'.esc_attr($pro1).'">';
        echo '<input type="text" name="bu_pro2" maxlength="100" style="width:100%;margin-bottom:6px" value="'.esc_attr($pro2).'">';
        echo '<input type="text" name="bu_pro3" maxlength="100" style="width:100%" value="'.esc_attr($pro3).'">';
        echo '</td></tr>';
        echo '<tr><th>Nachteile (je max. 100)</th><td>';
        echo '<input type="text" name="bu_con1" maxlength="100" style="width:100%;margin-bottom:6px" value="'.esc_attr($con1).'">';
        echo '<input type="text" name="bu_con2" maxlength="100" style="width:100%;margin-bottom:6px" value="'.esc_attr($con2).'">';
        echo '<input type="text" name="bu_con3" maxlength="100" style="width:100%" value="'.esc_attr($con3).'">';
        echo '</td></tr>';
        echo '</tbody></table>';
    }
    public static function save_meta_info($pid,$post){
        if ($post->post_type!==self::CPT) return;
        // Autosaves / Revisionen / auto-draft nicht hart validieren
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (wp_is_post_autosave($pid) || wp_is_post_revision($pid)) return;
        if (isset($post->post_status) && $post->post_status === 'auto-draft') return;

        // Für Benachrichtigungen: alte Werte merken (Favoriten-Änderungen)
        $old_summary = get_post_meta($pid, self::META_SUMMARY, true);
        $old_pro1 = get_post_meta($pid, self::META_PRO1, true);
        $old_pro2 = get_post_meta($pid, self::META_PRO2, true);
        $old_pro3 = get_post_meta($pid, self::META_PRO3, true);
        $old_con1 = get_post_meta($pid, self::META_CON1, true);
        $old_con2 = get_post_meta($pid, self::META_CON2, true);
        $old_con3 = get_post_meta($pid, self::META_CON3, true);

        $summary = isset($_POST['bu_summary']) ? wp_kses_post($_POST['bu_summary']) : '';
        $pro1 = isset($_POST['bu_pro1']) ? sanitize_text_field($_POST['bu_pro1']) : '';
        $pro2 = isset($_POST['bu_pro2']) ? sanitize_text_field($_POST['bu_pro2']) : '';
        $pro3 = isset($_POST['bu_pro3']) ? sanitize_text_field($_POST['bu_pro3']) : '';
        $con1 = isset($_POST['bu_con1']) ? sanitize_text_field($_POST['bu_con1']) : '';
        $con2 = isset($_POST['bu_con2']) ? sanitize_text_field($_POST['bu_con2']) : '';
        $con3 = isset($_POST['bu_con3']) ? sanitize_text_field($_POST['bu_con3']) : '';

        // Pflichtfelder prüfen: Titel, Beschreibung
        $missing = array();
        $title = isset($post->post_title) ? trim($post->post_title) : '';
        if ($title===''){
            $missing[] = 'Titel';
        }
        $content_plain = isset($post->post_content) ? trim(wp_strip_all_tags($post->post_content)) : '';
        if ($content_plain===''){
            $missing[] = 'Beschreibung';
        }
        if (!empty($missing)){
            $missing = array_unique($missing);
            $msg = 'Bitte füllen Sie alle Pflichtfelder aus: '.esc_html(implode(', ',$missing)).'.';
            wp_die($msg);
        }

        if (self::s_len($summary)>250) $summary = self::s_sub($summary,0,250);
        foreach (['pro1','pro2','pro3','con1','con2','con3'] as $k){
            $vv = isset($$k) ? $$k : '';
            if (self::s_len($vv)>100) $$k = self::s_sub($vv,0,100);
        }
        update_post_meta($pid,self::META_SUMMARY,$summary);
        update_post_meta($pid,self::META_PRO1,$pro1);
        update_post_meta($pid,self::META_PRO2,$pro2);
        update_post_meta($pid,self::META_PRO3,$pro3);
        update_post_meta($pid,self::META_CON1,$con1);
        update_post_meta($pid,self::META_CON2,$con2);
        update_post_meta($pid,self::META_CON3,$con3);

        // Favoriten-Notification nur einmal pro Save (Content/Meta)
        $changed_fields = [];
        if ((string)$old_summary !== (string)$summary) $changed_fields[] = 'Zusammenfassung';
        if ((string)$old_pro1 !== (string)$pro1) $changed_fields[] = 'Vorteil 1';
        if ((string)$old_pro2 !== (string)$pro2) $changed_fields[] = 'Vorteil 2';
        if ((string)$old_pro3 !== (string)$pro3) $changed_fields[] = 'Vorteil 3';
        if ((string)$old_con1 !== (string)$con1) $changed_fields[] = 'Nachteil 1';
        if ((string)$old_con2 !== (string)$con2) $changed_fields[] = 'Nachteil 2';
        if ((string)$old_con3 !== (string)$con3) $changed_fields[] = 'Nachteil 3';

        if (!empty($changed_fields)){
            $dedup_key = intval($pid);
            if (!self::notif_once('fav_content', $dedup_key)){
                self::notify_favorite_watchers($pid, 'Inhalt aktualisiert', get_current_user_id(), [
                    'fields' => implode(', ', $changed_fields),
                ]);
            }
        }
    }

    public static function metabox_side_tax(){
        // Kategorie & Ebene: als Dropdown-Metaboxen (auch im Block-Editor), damit User keine neuen Begriffe anlegen können.
        add_meta_box('bu_side_actions','Vorstösse/Aktionen',[__CLASS__,'box_side_actions'],self::CPT,'side','high');
        add_meta_box('bu_side_cat','Kategorie',[__CLASS__,'box_side_cat'],self::CPT,'side','high');
        add_meta_box('bu_side_level','Ebene',[__CLASS__,'box_side_level'],self::CPT,'side','high');
    }


    public static function box_side_actions($post){
        if (!$post || $post->post_type !== self::CPT) return;

        $terms = get_terms([
            'taxonomy'   => self::TAX_ACT,
            'hide_empty' => false,
            'orderby'    => 'name',
            'order'      => 'ASC',
        ]);

        $sel = wp_get_post_terms($post->ID, self::TAX_ACT, ['fields'=>'ids']);
        $selected = (is_array($sel) ? array_map('intval', $sel) : []);

        echo '<div class="bu-side-actions" style="margin:0;">';
        echo '<input type="hidden" name="bu_actions_present" value="1" />';
        if (is_wp_error($terms) || empty($terms)){
            $admin_url = esc_url(add_query_arg(['page'=>'bottomup_admin','tab'=>'actions'], admin_url('admin.php')));
            echo '<p style="margin:0 0 8px 0;">Keine Vorstösse/Aktionen vorhanden.</p>';
            echo '<p style="margin:0;"><a class="button" href="'.$admin_url.'">Im Admin anlegen</a></p>';
        } else {
            foreach ($terms as $t){
                $tid = intval($t->term_id);
                $checked = in_array($tid, $selected, true) ? 'checked' : '';
                echo '<label style="display:block; margin:0 0 6px 0;">';
                echo '<input type="checkbox" name="bu_actions[]" value="'.esc_attr($tid).'" '.$checked.' /> ';
                echo esc_html($t->name);
                echo '</label>';
            }
            echo '<p class="description" style="margin:8px 0 0 0; color:#646970;">Pflichtfeld: bitte mindestens eine Aktion auswählen (für aktive Ideen).</p>';
        }
        echo '</div>';
    }

    public static function box_side_level($post){
        // UX: 2-stufige Auswahl: (1) Hauptebene wie früher, (2) Untergruppe abhängig von Hauptebene
        $terms = get_terms([
            'taxonomy'   => self::TAX_LVL,
            'hide_empty' => false,
            'orderby'    => 'name',
            'order'      => 'ASC',
        ]);

        $sel = wp_get_post_terms($post->ID, self::TAX_LVL, ['fields'=>'ids']);
        $current = isset($sel[0]) ? intval($sel[0]) : 0;

        // Prefill: wenn aktuell eine Untergruppe gewählt ist, parent/child sauber setzen
        $parent_id = 0;
        $child_id  = 0;
        if ($current){
            $cur_term = get_term($current, self::TAX_LVL);
            if ($cur_term && !is_wp_error($cur_term)){
                if (!empty($cur_term->parent)){
                    $parent_id = intval($cur_term->parent);
                    $child_id  = intval($cur_term->term_id);
                } else {
                    $parent_id = intval($cur_term->term_id);
                }
            }
        }

        $parents = [];
        $children_map = []; // parent_id => [term,...]
        if (!is_wp_error($terms)){
            foreach($terms as $t){
                $p = intval($t->parent);
                if ($p === 0){
                    $parents[] = $t;
                } else {
                    if (!isset($children_map[$p])) $children_map[$p] = [];
                    $children_map[$p][] = $t;
                }
            }
            usort($parents, function($a,$b){ return strcasecmp($a->name, $b->name); });
            foreach($children_map as $p => $arr){
                usort($children_map[$p], function($a,$b){ return strcasecmp($a->name, $b->name); });
            }
        }

        echo '<div class="bu-level-2step">';
        echo '<select id="bu_level_parent" name="bu_level_parent" style="width:100%" required>';
        echo '<option value="">— wählen —</option>';
        foreach($parents as $t){
            echo '<option value="'.intval($t->term_id).'" '.selected($parent_id,$t->term_id,false).'>'.esc_html($t->name).'</option>';
        }
        echo '</select>';

        // Untergruppen-Select (wird per JS befüllt/angezeigt)
        echo '<div id="bu_level_child_wrap" style="margin-top:8px; display:none">';
        echo '<label for="bu_level_child" style="display:block; font-weight:600; margin-bottom:4px;">Untergruppe</label>';
        echo '<select id="bu_level_child" name="bu_level_child" style="width:100%" data-initial="'.esc_attr($child_id).'">';
        echo '<option value="">— keine —</option>';
        echo '</select>';
        echo '<p class="description" style="margin:6px 0 0;">Tipp: Im Feld kannst du tippen (z.B. ersten Buchstaben), um schnell zu springen.</p>';
        echo '</div>';
        echo '</div>';

        // JS Daten (nur 1 Ebene Untergruppen – parent => children)
        $map = [];
        foreach($children_map as $p => $arr){
            $map[intval($p)] = array_map(function($t){
                return ['id'=>intval($t->term_id), 'name'=>$t->name];
            }, $arr);
        }
        echo '<script>(function(){'
            .'var parentSel=document.getElementById("bu_level_parent");'
            .'var childWrap=document.getElementById("bu_level_child_wrap");'
            .'var childSel=document.getElementById("bu_level_child");'
            .'if(!parentSel||!childWrap||!childSel) return;'
            .'var map='.wp_json_encode($map).';'
            .'var initialChild=(childSel.getAttribute("data-initial")||"");'
            .'function rebuild(pid){'
                .'pid=parseInt(pid||"0",10)||0;'
                .'var list=(map[pid]||[]);'
                .'while(childSel.firstChild) childSel.removeChild(childSel.firstChild);'
                .'var o0=document.createElement("option"); o0.value=""; o0.textContent="— keine —"; childSel.appendChild(o0);'
                .'if(pid && list.length){'
                    .'list.forEach(function(it){ var o=document.createElement("option"); o.value=String(it.id); o.textContent=it.name; childSel.appendChild(o); });'
                    .'childWrap.style.display="";'
                    .'if(initialChild && list.some(function(it){return String(it.id)===String(initialChild);})){ childSel.value=String(initialChild); } else { childSel.value=""; }'
                    .'setTimeout(function(){ try{ childSel.focus(); }catch(e){} }, 0);'
                .'} else {'
                    .'childWrap.style.display="none";'
                    .'childSel.value="";'
                .'}'
            .'}'
            // Prefix-Search (robust, auch wenn Browser-Default nicht greift)
            .'var buf=""; var timer=null;'
            .'childSel.addEventListener("keydown", function(e){'
                .'if(e.ctrlKey||e.metaKey||e.altKey) return;'
                .'var k=e.key||"";'
                .'if(k==="Backspace"){ buf=""; return; }'
                .'if(k.length===1){'
                    .'buf += k.toLowerCase();'
                    .'if(timer) window.clearTimeout(timer);'
                    .'timer=window.setTimeout(function(){ buf=""; }, 700);'
                    .'var opts=Array.prototype.slice.call(childSel.options);'
                    .'var found=null;'
                    .'for(var i=0;i<opts.length;i++){'
                        .'var o=opts[i];'
                        .'if(!o.value) continue;'
                        .'if((o.textContent||"").toLowerCase().indexOf(buf)===0){ found=o; break; }'
                    .'}'
                    .'if(found){ childSel.value=found.value; e.preventDefault(); }'
                .'}'
            .'});'
            .'parentSel.addEventListener("change", function(){ initialChild=""; rebuild(parentSel.value); });'
            .'rebuild(parentSel.value);'
            .'})();</script>';
    }
    public static function box_side_cat($post){
        $terms = get_terms(['taxonomy'=>self::TAX_CAT,'hide_empty'=>false]);
        $sel = wp_get_post_terms($post->ID, self::TAX_CAT, ['fields'=>'ids']);
        $current = isset($sel[0]) ? intval($sel[0]) : 0;
        echo '<select required name="bu_cat_term" style="width:100%">';
        echo '<option value="">— wählen —</option>';
        if (!is_wp_error($terms)){
            foreach($terms as $t){ echo '<option value="'.intval($t->term_id).'"'.selected($current,$t->term_id,false).'>'.esc_html($t->name).'</option>'; }
        }
        echo '</select>';
    }
    public static function save_side_tax($pid,$post){
        if ($post->post_type!==self::CPT) return;

        // v2.21: Robustheit – in Autosave/Revisionen nichts überschreiben/leer setzen
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (wp_is_post_autosave($pid) || wp_is_post_revision($pid)) return;
        if (isset($post->post_status) && $post->post_status === 'auto-draft') return;
        if (!current_user_can('edit_post', $pid)) return;

        // Für Benachrichtigungen: alte Werte merken (vor Änderungen an Taxonomien)
        $old_lvl = wp_get_post_terms($pid, self::TAX_LVL, ['fields' => 'ids']);
        $old_cat = wp_get_post_terms($pid, self::TAX_CAT, ['fields' => 'ids']);
        $old_act = wp_get_post_terms($pid, self::TAX_ACT, ['fields' => 'ids']);
        if (is_wp_error($old_lvl) || !is_array($old_lvl)) $old_lvl = [];
        if (is_wp_error($old_cat) || !is_array($old_cat)) $old_cat = [];
        if (is_wp_error($old_act) || !is_array($old_act)) $old_act = [];

        // Neue Werte (nur wenn im Request vorhanden; sonst bleibt null => keine Benachrichtigung)
        $new_lvl = null;
        $new_cat = null;
        $new_act = null;

        // Neu ab 2.15: 2-stufige Ebenen-Auswahl (Hauptebene + Untergruppe)
        // Speichern: bevorzugt Untergruppe, sonst Hauptebene. Fallback: altes Feld bu_level_term.
        $level_present = (isset($_POST['bu_level_child']) || isset($_POST['bu_level_parent']) || isset($_POST['bu_level_term']));
        if ($level_present){
            $chosen_level = 0;
            if (isset($_POST['bu_level_child']) || isset($_POST['bu_level_parent'])){
                $p_raw = isset($_POST['bu_level_parent']) ? wp_unslash($_POST['bu_level_parent']) : '';
                $c_raw = isset($_POST['bu_level_child']) ? wp_unslash($_POST['bu_level_child']) : '';
                $p_id  = ($p_raw !== '' ? intval($p_raw) : 0);
                $c_id  = ($c_raw !== '' ? intval($c_raw) : 0);
                $chosen_level = ($c_id ? $c_id : $p_id);
            } elseif (isset($_POST['bu_level_term'])){
                $raw = wp_unslash($_POST['bu_level_term']);
                $chosen_level = ($raw !== '' ? intval($raw) : 0);
            }

            $new_lvl = ($chosen_level ? [intval($chosen_level)] : []);

            if ($chosen_level){
                wp_set_post_terms($pid, [intval($chosen_level)], self::TAX_LVL, false);
            } else {
                wp_set_post_terms($pid, [], self::TAX_LVL, false);
            }
        }

        // Kategorie (Dropdown)
        if (isset($_POST['bu_cat_term'])){
            $raw = wp_unslash($_POST['bu_cat_term']);
            $tid = ($raw !== '' ? [intval($raw)] : []);
            $new_cat = $tid;
            wp_set_post_terms($pid, $tid, self::TAX_CAT, false);
        }

        // Vorstösse/Aktionen (Mehrfach-Auswahl) – unabhängig von Kategorie speichern
        // Update nur, wenn die Metabox im Request vorhanden war (sonst nichts verändern).
        if (isset($_POST['bu_actions_present'])){
            if (isset($_POST['bu_actions']) && is_array($_POST['bu_actions'])){
                $ids = array_values(array_unique(array_map('intval', wp_unslash($_POST['bu_actions']))));
                $ids = array_filter($ids, function($v){ return $v > 0; });
                $new_act = $ids;
                wp_set_post_terms($pid, $ids, self::TAX_ACT, false);
            } else {
                $new_act = [];
                wp_set_post_terms($pid, [], self::TAX_ACT, false);
            }
        }

        // Mussfeld: Vorstösse/Aktionen (nur für aktive Ideen; Archiv darf unvollständig sein)
        if (isset($_POST['bu_actions_present'])) {
            $post_obj = get_post($pid);
            $is_autodraft = ($post_obj && !is_wp_error($post_obj) && isset($post_obj->post_status) && $post_obj->post_status === 'auto-draft');

            if (!$is_autodraft) {
                $is_arch = false;
                if (isset($_POST['bu_archived']) && strval($_POST['bu_archived']) === '1') {
                    $is_arch = true;
                } else {
                    $arch_meta = get_post_meta($pid, self::META_ARCHIVED, true);
                    $is_arch = (strval($arch_meta) === '1');
                }

                // Nur erzwingen, wenn es überhaupt Aktionen gibt
                $has_actions = !empty(get_terms(['taxonomy'=>self::TAX_ACT,'hide_empty'=>false,'number'=>1]));
                if ($has_actions && empty($new_act) && !$is_arch) {
                    wp_die('Bitte mindestens eine Aktion auswählen (Pflichtfeld).');
                }
            }
        }

        // Benachrichtigung an Nutzer, die diese Idee als Favorit markiert haben (Änderungen an Ebene/Kategorie/Aktionen)
        $changed_fields = [];
        $norm = function($arr){
            if (!is_array($arr)) $arr = [];
            $arr = array_values(array_unique(array_filter(array_map('intval', $arr))));
            sort($arr);
            return $arr;
        };
        if ($new_lvl !== null && $norm($old_lvl) !== $norm($new_lvl)) $changed_fields[] = 'Ebene';
        if ($new_cat !== null && $norm($old_cat) !== $norm($new_cat)) $changed_fields[] = 'Kategorie';
        if ($new_act !== null && $norm($old_act) !== $norm($new_act)) $changed_fields[] = 'Vorstösse/Aktionen';

        if (!empty($changed_fields)) {
            $dedup_key = intval($pid);
            if (!self::notif_once('fav_meta', $dedup_key)) {
                self::notify_favorite_watchers($pid, 'Metadaten aktualisiert', get_current_user_id(), [
                    'fields' => implode(', ', $changed_fields),
                ]);
            }
        }

    }




    public static function enforce_single_level($pid, $post){
        if ($post->post_type!==self::CPT) return;
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (wp_is_post_autosave($pid) || wp_is_post_revision($pid)) return;
        if (isset($post->post_status) && $post->post_status === 'auto-draft') return;

        $ids = wp_get_post_terms($pid, self::TAX_LVL, ['fields'=>'ids']);
        if (is_wp_error($ids)) return;

        // Keine automatische Ebene setzen – nur sicherstellen, dass max. 1 Ebene gespeichert ist
        if (count($ids) > 1){
            wp_set_post_terms($pid, [intval($ids[0])], self::TAX_LVL, false);
        }


    }
    public static function validate_required_taxonomies($pid, $post){
        if ($post->post_type!==self::CPT) return;
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (wp_is_post_autosave($pid) || wp_is_post_revision($pid)) return;
        if (isset($post->post_status) && $post->post_status === 'auto-draft') return;

        // In manchen Save-Flows (v.a. Gutenberg/Meta-Box-Saves) sind Taxonomies im Request vorhanden,
        // während wp_get_post_terms() während des Insert/Update-Zyklus temporär leer sein kann.
        $posted_tax = isset($_POST['tax_input']) && is_array($_POST['tax_input']) ? wp_unslash($_POST['tax_input']) : [];

        $cats_posted = [];
        if (isset($posted_tax[self::TAX_CAT])) $cats_posted = (array)$posted_tax[self::TAX_CAT];
        $cats_posted = array_values(array_filter(array_map('intval', $cats_posted)));

        $lvls_posted = [];
        if (isset($posted_tax[self::TAX_LVL])) $lvls_posted = (array)$posted_tax[self::TAX_LVL];
        $lvls_posted = array_values(array_filter(array_map('intval', $lvls_posted)));

        $cats = wp_get_post_terms($pid, self::TAX_CAT, ['fields'=>'ids']);
        $lvls = wp_get_post_terms($pid, self::TAX_LVL, ['fields'=>'ids']);
        if (is_wp_error($cats) || is_wp_error($lvls)) return;

        // Zusätzlich: unsere Custom-Dropdowns (bu_cat_term / bu_level_parent|child / bu_level_term)
        $cats_custom = 0;
        if (isset($_POST['bu_cat_term'])){
            $raw = wp_unslash($_POST['bu_cat_term']);
            $cats_custom = ($raw !== '' ? intval($raw) : 0);
        }

        $lvl_custom = 0;
        if (isset($_POST['bu_level_child']) || isset($_POST['bu_level_parent'])){
            $p_raw = isset($_POST['bu_level_parent']) ? wp_unslash($_POST['bu_level_parent']) : '';
            $c_raw = isset($_POST['bu_level_child']) ? wp_unslash($_POST['bu_level_child']) : '';
            $p_id  = ($p_raw !== '' ? intval($p_raw) : 0);
            $c_id  = ($c_raw !== '' ? intval($c_raw) : 0);
            $lvl_custom = ($c_id ? $c_id : $p_id);
        } elseif (isset($_POST['bu_level_term'])){
            $raw = wp_unslash($_POST['bu_level_term']);
            $lvl_custom = ($raw !== '' ? intval($raw) : 0);
        }

        $has_cats = (!empty($cats_posted) || !empty($cats) || !empty($cats_custom));
        $has_lvls = (!empty($lvls_posted) || !empty($lvls) || !empty($lvl_custom));

        $missing = [];
        if (!$has_cats) $missing[] = 'Kategorie';
        if (!$has_lvls) $missing[] = 'Ebene';

        if (!empty($missing)){
            // IMPORTANT: Do not block saving (especially via Gutenberg/REST), otherwise the editor
            // shows "Updating failed" even if the post is already saved.
            // We keep this as a soft validation only.
            return;
        }
    }



    public static function metabox_side_state(){
        add_meta_box('bu_side_state','Status & Archiv',[__CLASS__,'box_side_state'],self::CPT,'side','low');
    }

    public static function box_side_state($post){
        if (!$post || $post->post_type !== self::CPT) return;
        wp_nonce_field('bu_side_state','bu_side_state_nonce');

        $state = get_post_meta($post->ID, self::META_STATE, true);
        if (!$state) $state = 'active';
        $arch  = get_post_meta($post->ID, self::META_ARCHIVED, true);
        $arch_on = ($arch==='1' || $arch===1);

        echo '<div class="bu-side-section">';
        echo '<div class="bu-side-label"><strong>Status</strong></div>';
        echo '<label class="bu-radio"><input type="radio" name="bu_state" value="active" '.checked($state,'active',false).'> Offen</label><br>';
        echo '<label class="bu-radio"><input type="radio" name="bu_state" value="done" '.checked($state,'done',false).'> Abgeschlossen</label>';
        echo '</div>';

        echo '<hr style="margin:12px 0;">';

        echo '<div class="bu-side-section">';
        echo '<div class="bu-side-label"><strong>Archiv</strong></div>';
        echo '<label class="bu-switch">';
        echo '<input type="checkbox" name="bu_archived" value="1" '.checked($arch_on,true,false).'>';
        echo '<span class="bu-slider" aria-hidden="true"></span>';
        echo '</label> ';
        echo '<span class="bu-switch-text">'.($arch_on ? 'Archiviert' : 'Aktuell').'</span>';
        echo '<p class="description" style="margin-top:8px;">Archiv ≠ Abgeschlossen. Archiv blendet Ideen aus der aktuellen Liste aus.</p>';
        echo '</div>';
    }

    public static function save_side_state($post_id, $post){
        if (!is_object($post) || $post->post_type !== self::CPT) return;
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (wp_is_post_revision($post_id)) return;
        if (isset($post->post_status) && $post->post_status === 'auto-draft') return;
        if (!isset($_POST['bu_side_state_nonce']) || !wp_verify_nonce(sanitize_text_field($_POST['bu_side_state_nonce']), 'bu_side_state')) return;
        if (!current_user_can('edit_post', $post_id)) return;

        $old_arch  = get_post_meta($post_id, self::META_ARCHIVED, true);
        $old_state = get_post_meta($post_id, self::META_STATE, true);

        $state = isset($_POST['bu_state']) ? sanitize_key(wp_unslash($_POST['bu_state'])) : 'active';
        if (!in_array($state, ['active','done'], true)) $state = 'active';
        update_post_meta($post_id, self::META_STATE, $state);

        $arch = (isset($_POST['bu_archived']) && $_POST['bu_archived']=='1') ? '1' : '0';
        update_post_meta($post_id, self::META_ARCHIVED, $arch);

        $changes = [];
        if ((string)$old_state !== (string)$state){
            $changes[] = 'Status: '.($state === 'done' ? 'Abgeschlossen' : 'Offen');
        }
        if ((string)$old_arch !== (string)$arch){
            $changes[] = 'Archiv: '.($arch === '1' ? 'Archiviert' : 'Aktuell');
        }

        if (!empty($changes)){
            $dedup_key = intval($post_id);
            if (self::notif_once('fav_state', $dedup_key)) return;
            self::notify_favorite_watchers($post_id, 'Status/Archiv geändert', get_current_user_id(), [
                'fields' => implode(', ', $changes),
            ]);
        }
}



    public static function render_admin(){
        if (!current_user_can('manage_options')) wp_die('Keine Berechtigung.');
        self::pm_ensure_tables(); // harmless; keeps db checks consistent

        $tab = isset($_GET['tab']) ? sanitize_key($_GET['tab']) : 'export';
        if (!in_array($tab, ['export','levels','categories','actions','templates','process'], true)) $tab = 'export';

        echo '<div class="wrap"><h1>BottomUp Admin</h1>';
        self::kiosk_top_links();

        echo '<h2 class="nav-tab-wrapper">';
        echo '<a class="nav-tab '.($tab==='export'?'nav-tab-active':'').'" href="'.esc_url(add_query_arg(['page'=>'bottomup_admin','tab'=>'export'], admin_url('admin.php'))).'">CSV Export</a>';
        echo '<a class="nav-tab '.($tab==='levels'?'nav-tab-active':'').'" href="'.esc_url(add_query_arg(['page'=>'bottomup_admin','tab'=>'levels'], admin_url('admin.php'))).'">Ebenen</a>';
        echo '<a class="nav-tab '.($tab==='categories'?'nav-tab-active':'').'" href="'.esc_url(add_query_arg(['page'=>'bottomup_admin','tab'=>'categories'], admin_url('admin.php'))).'">Kategorien</a>';
        echo '<a class="nav-tab '.($tab==='actions'?'nav-tab-active':'').'" href="'.esc_url(add_query_arg(['page'=>'bottomup_admin','tab'=>'actions'], admin_url('admin.php'))).'">Vorstösse/Aktionen</a>';
        echo '<a class="nav-tab '.($tab==='templates'?'nav-tab-active':'').'" href="'.esc_url(add_query_arg(['page'=>'bottomup_admin','tab'=>'templates'], admin_url('admin.php'))).'">Templates</a>';
        echo '<a class="nav-tab '.($tab==='process'?'nav-tab-active':'').'" href="'.esc_url(add_query_arg(['page'=>'bottomup_admin','tab'=>'process'], admin_url('admin.php'))).'">Prozess</a>';
        echo '</h2>';

        settings_errors('bu_admin');

        if ($tab === 'export'){
            // Download trigger
            if (isset($_GET['do']) && $_GET['do']==='download'){
                self::export_csv();
                return;
            }

            $dl_url_all  = esc_url(add_query_arg(['page'=>'bottomup_admin','tab'=>'export','do'=>'download'], admin_url('admin.php')));
            $dl_url_list = esc_url(add_query_arg(['page'=>'bottomup_admin','tab'=>'export','do'=>'download','list'=>1], admin_url('admin.php')));

            echo '<div class="postbox" style="max-width:860px;margin-top:12px;"><div class="postbox-header"><h2>CSV Export</h2></div><div class="inside">';
            echo '<p>Exportiert Ideen als CSV-Datei.</p>';
            echo '<p><a class="button button-primary" href="'.$dl_url_all.'">CSV herunterladen (alle Ideen)</a> ';
            echo '<a class="button" href="'.$dl_url_list.'">CSV herunterladen (nur Listenansicht)</a></p>';
            echo '<p class="description">Hinweis: Filter (Ebene/Kategorie/Favoriten/Archiv) können wir bei Bedarf in einem nächsten Schritt in dieses Admin-Tab übernehmen.</p>';
            echo '</div></div>';
        } elseif ($tab === 'templates'){
            self::render_admin_templates();
        } elseif ($tab === 'process'){
            self::render_admin_process();
        } elseif ($tab === 'levels'){
            self::render_admin_taxonomy(self::TAX_LVL, true);
        } elseif ($tab === 'actions'){
            self::render_admin_taxonomy(self::TAX_ACT, false);
        } else {
            self::render_admin_taxonomy(self::TAX_CAT, false);
        }

        echo '</div>';
    }


    private static function render_admin_templates(){
        if (!current_user_can('manage_options')) return;

        // Save templates
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bu_tpl_nonce']) && wp_verify_nonce(sanitize_text_field($_POST['bu_tpl_nonce']), 'bu_tpl_save')){
            $tpl = get_option('bu_notify_templates', []);
            if (!is_array($tpl)) $tpl = [];

            // Validierung: unbekannte Platzhalter melden (Templates bleiben reiner Text)
            $allowed_ph = [
                'site_name','recipient_name','idea_title','idea_url',
                'actor_name','action','fields','level','category',
                'activity','sk_value','vote_value','comment',
            ];
            $unknown_ph = [];
            $scan_ph = function($text) use ($allowed_ph, &$unknown_ph){
                if (!is_string($text) || $text === '') return;
                if (preg_match_all('/\{([a-zA-Z0-9_\-]+)\}/', $text, $m)){
                    if (!empty($m[1])){
                        foreach ($m[1] as $name){
                            $name = (string)$name;
                            if ($name === '') continue;
                            if (!in_array($name, $allowed_ph, true)){
                                $unknown_ph[$name] = true;
                            }
                        }
                    }
                }
            };

            $keys = ['fav_changes','new_idea','my_idea_activity'];
            foreach ($keys as $k){
                $subj_key = 'tpl_'.$k.'_subject';
                $body_key = 'tpl_'.$k.'_body';
                $subject = isset($_POST[$subj_key]) ? sanitize_text_field(wp_unslash($_POST[$subj_key])) : '';
                $body    = isset($_POST[$body_key]) ? sanitize_textarea_field(wp_unslash($_POST[$body_key])) : '';

                $scan_ph($subject);
                $scan_ph($body);

                if (!isset($tpl[$k]) || !is_array($tpl[$k])) $tpl[$k] = [];
                $tpl[$k]['subject'] = $subject;
                $tpl[$k]['body']    = $body;
            }

            update_option('bu_notify_templates', $tpl);

            // Optional: Absender überschreiben (nur für BottomUp-Benachrichtigungen)
            $from_name  = isset($_POST['bu_notify_from_name']) ? sanitize_text_field(wp_unslash($_POST['bu_notify_from_name'])) : '';
            $from_email = isset($_POST['bu_notify_from_email']) ? sanitize_email(wp_unslash($_POST['bu_notify_from_email'])) : '';
            update_option('bu_notify_from_name', $from_name);
            update_option('bu_notify_from_email', $from_email);

            add_settings_error('bu_admin','bu_tpl_saved','Templates gespeichert.','updated');

            if (!empty($unknown_ph)){
                $list = array_map(function($n){ return '{'.$n.'}'; }, array_keys($unknown_ph));
                add_settings_error('bu_admin','bu_tpl_unknown','Unbekannte Platzhalter gefunden: '.implode(' ', $list).'. Diese werden beim Versand ignoriert.','error');
            }
        }

        self::ensure_notification_templates();
        $tpl  = self::get_notification_templates();
        $defs = self::default_notification_templates();

        $placeholders = [
            '{site_name}','{recipient_name}','{idea_title}','{idea_url}',
            '{actor_name}','{action}','{fields}','{level}','{category}',
            '{activity}','{sk_value}','{vote_value}','{comment}',
        ];

        echo '<div class="postbox" style="max-width:900px;margin-top:12px;">';
        echo '<div class="postbox-header"><h2>Templates – Benachrichtigungen</h2></div>';
        echo '<div class="inside">';
        echo '<p>Hier kannst du die E-Mail Templates für Benachrichtigungen erstellen und pflegen. Platzhalter werden in geschweiften Klammern angegeben (z.B. <code>{idea_title}</code>).</p>';
        echo '<p><strong>Verfügbare Platzhalter:</strong> '.implode(' ', array_map(function($p){ return '<code>'.esc_html($p).'</code>'; }, $placeholders)).'</p>';

        $from_name_val  = (string)get_option('bu_notify_from_name', '');
        $from_email_val = (string)get_option('bu_notify_from_email', '');

        echo '<form method="post">';
        echo '<input type="hidden" name="bu_tpl_nonce" value="'.esc_attr(wp_create_nonce('bu_tpl_save')).'">';

        echo '<h3 style="margin-top:0;">Absender (optional)</h3>';
        echo '<p class="description" style="margin-top:0;">Wenn leer, verwendet WordPress den Standard-Absender. Für bessere Zustellbarkeit empfiehlt sich oft eine Domain-Adresse (SMTP).</p>';
        echo '<table class="form-table" style="max-width:780px;"><tbody>';
        echo '<tr><th style="width:180px;"><label for="bu_notify_from_name">Name</label></th><td><input id="bu_notify_from_name" name="bu_notify_from_name" type="text" class="regular-text" value="'.esc_attr($from_name_val).'" placeholder="'.esc_attr(get_bloginfo('name')).'"></td></tr>';
        echo '<tr><th><label for="bu_notify_from_email">E-Mail</label></th><td><input id="bu_notify_from_email" name="bu_notify_from_email" type="email" class="regular-text" value="'.esc_attr($from_email_val).'" placeholder="z.B. noreply@deine-domain.ch"></td></tr>';
        echo '</tbody></table>';
        echo '<hr style="margin:16px 0;">';

        $sections = self::notification_template_sections();

        foreach ($sections as $k => $label){
            $subject = isset($tpl[$k]['subject']) ? (string)$tpl[$k]['subject'] : ($defs[$k]['subject'] ?? '');
            $body    = isset($tpl[$k]['body']) ? (string)$tpl[$k]['body'] : ($defs[$k]['body'] ?? '');

            echo '<hr style="margin:18px 0;">';
            echo '<h3 style="margin:0 0 8px 0;">'.esc_html($label).'</h3>';

            echo '<p style="margin:0 0 6px 0;"><label><strong>Betreff</strong><br>';
            echo '<input type="text" name="tpl_'.$k.'_subject" value="'.esc_attr($subject).'" style="width:100%;max-width:820px;"></label></p>';

            echo '<p style="margin:0 0 6px 0;"><label><strong>Text</strong><br>';
            echo '<textarea name="tpl_'.$k.'_body" rows="7" style="width:100%;max-width:820px;">'.esc_textarea($body).'</textarea></label></p>';

            echo '<p class="description" style="margin-top:0;">Standardwerte werden automatisch ergänzt, falls Felder leer sind.</p>';
        }

        echo '<p><button type="submit" class="button button-primary">Templates speichern</button></p>';
        echo '</form>';

        echo '</div></div>';
    }


    
private static function render_admin_process(){
    if (!current_user_can('manage_options')) return;

    // Save / reset
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bu_proc_nonce']) && wp_verify_nonce(sanitize_text_field($_POST['bu_proc_nonce']), 'bu_proc_save')){
        if (isset($_POST['bu_proc_reset']) && sanitize_text_field(wp_unslash($_POST['bu_proc_reset'])) === '1'){
            delete_option('bu_process_steps');
            add_settings_error('bu_admin','bu_proc_reset','Prozessschritte wurden auf Standard zurückgesetzt.','updated');
        } else {
            $raw = isset($_POST['bu_proc']) ? (array) wp_unslash($_POST['bu_proc']) : [];
            $order = isset($_POST['bu_proc_order']) ? sanitize_text_field(wp_unslash($_POST['bu_proc_order'])) : '';
            $ids = array_filter(array_map(function($v){ return sanitize_key(trim((string)$v)); }, explode(',', (string)$order)));
            if (empty($ids)){
                $ids = array_map('sanitize_key', array_keys($raw));
            }

            $out = [];
            $n = 1;
            foreach ($ids as $id){
                if (!isset($raw[$id]) || !is_array($raw[$id])) continue;
                $s = $raw[$id];
                $out[$id] = [
                    'n'          => $n,
                    'title'      => isset($s['title']) ? sanitize_text_field($s['title']) : '',
                    'short'      => isset($s['short']) ? sanitize_text_field($s['short']) : '',
                    'what'       => isset($s['what']) ? sanitize_textarea_field($s['what']) : '',
                    'who'        => isset($s['who']) ? sanitize_textarea_field($s['who']) : '',
                    'system'     => isset($s['system']) ? sanitize_textarea_field($s['system']) : '',
                    'rules'      => isset($s['rules']) ? sanitize_textarea_field($s['rules']) : '',
                    'link'       => isset($s['link']) ? esc_url_raw($s['link']) : '',
                    'link_label' => isset($s['link_label']) ? sanitize_text_field($s['link_label']) : '',
                ];
                $n++;
            }

            if (empty($out)){
                // Keep default active if user removed everything
                delete_option('bu_process_steps');
                add_settings_error('bu_admin','bu_proc_empty','Keine Schritte gespeichert – Standard bleibt aktiv.','updated');
            } else {
                update_option('bu_process_steps', $out, false);
                add_settings_error('bu_admin','bu_proc_saved','Prozessschritte gespeichert.','updated');
            }
        }
    }

    $steps = self::get_process_steps();
    $order = implode(',', array_keys($steps));

    echo '<div class="postbox" style="max-width:980px;margin-top:12px;"><div class="postbox-header"><h2>Prozess (Dashboard)</h2></div><div class="inside">';
    echo '<p class="description">Hier kann der Admin die Prozess-Kacheln fürs Dashboard pflegen (Reihenfolge, Inhalte und Links). Änderungen wirken sofort im Dashboard.</p>';

    echo '<form method="post" action="">';
    wp_nonce_field('bu_proc_save', 'bu_proc_nonce');
    echo '<input type="hidden" id="bu-proc-order" name="bu_proc_order" value="'.esc_attr($order).'" />';

    echo '<ul id="bu-proc-admin-list" class="bu-proc-admin-list">';
    foreach ($steps as $id=>$s){
        self::render_admin_process_item($id, $s);
    }
    echo '</ul>';

    echo '<p><button type="button" class="button" id="bu-proc-add">+ Schritt hinzufügen</button></p>';

    echo '<p style="display:flex;gap:8px;align-items:center;">';
    echo '  <button type="submit" class="button button-primary">Speichern</button>';
    echo '  <button type="submit" class="button" name="bu_proc_reset" value="1" onclick="return confirm(\'Prozessschritte wirklich auf Standard zurücksetzen?\');">Auf Standard zurücksetzen</button>';
    echo '</p>';

    echo '</form>';

    // JS template (new step)
    echo '<script type="text/template" id="bu-proc-item-tpl">'.self::get_admin_process_item_template().'</script>';

    echo '</div></div>';
}

private static function render_admin_process_item($id, $s){
    $id = sanitize_key($id);
    if ($id === '') return;
    $n = isset($s['n']) ? intval($s['n']) : 0;

    echo '<li class="bu-proc-admin-item" data-id="'.esc_attr($id).'">';
    echo '  <div class="bu-proc-admin-head">';
    echo '    <span class="dashicons dashicons-menu bu-proc-handle" aria-hidden="true"></span>';
    echo '    <span class="bu-proc-admin-num">'.esc_html($n ?: '').'</span>';
    echo '    <code class="bu-proc-admin-id">'.esc_html($id).'</code>';
    echo '    <button type="button" class="button-link-delete bu-proc-remove">Entfernen</button>';
    echo '  </div>';

    echo '  <div class="bu-proc-admin-grid">';
    echo '    <label>Titel<br><input type="text" class="regular-text bu-proc-title" name="bu_proc['.esc_attr($id).'][title]" value="'.esc_attr(isset($s['title'])?$s['title']:'').'" /></label>';
    echo '    <label>Kurztext<br><input type="text" class="regular-text" name="bu_proc['.esc_attr($id).'][short]" value="'.esc_attr(isset($s['short'])?$s['short']:'').'" /></label>';
    echo '    <label>Link Label<br><input type="text" class="regular-text" name="bu_proc['.esc_attr($id).'][link_label]" value="'.esc_attr(isset($s['link_label'])?$s['link_label']:'').'" /></label>';
    echo '    <label>Link URL<br><input type="text" class="regular-text" name="bu_proc['.esc_attr($id).'][link]" value="'.esc_attr(isset($s['link'])?$s['link']:'').'" /></label>';
    echo '    <label class="bu-proc-span-2">Was passiert?<br><textarea rows="3" class="large-text" name="bu_proc['.esc_attr($id).'][what]">'.esc_textarea(isset($s['what'])?$s['what']:'').'</textarea></label>';
    echo '    <label class="bu-proc-span-2">Wer?<br><textarea rows="2" class="large-text" name="bu_proc['.esc_attr($id).'][who]">'.esc_textarea(isset($s['who'])?$s['who']:'').'</textarea></label>';
    echo '    <label class="bu-proc-span-2">Im System<br><textarea rows="2" class="large-text" name="bu_proc['.esc_attr($id).'][system]">'.esc_textarea(isset($s['system'])?$s['system']:'').'</textarea></label>';
    echo '    <label class="bu-proc-span-2">Regeln<br><textarea rows="2" class="large-text" name="bu_proc['.esc_attr($id).'][rules]">'.esc_textarea(isset($s['rules'])?$s['rules']:'').'</textarea></label>';
    echo '  </div>';
    echo '</li>';
}

/** HTML-Template für neue Items (Platzhalter: __ID__ und __NUM__). */
private static function get_admin_process_item_template(){
    $tpl = ''
    . '<li class="bu-proc-admin-item" data-id="__ID__">'
    . '  <div class="bu-proc-admin-head">'
    . '    <span class="dashicons dashicons-menu bu-proc-handle" aria-hidden="true"></span>'
    . '    <span class="bu-proc-admin-num">__NUM__</span>'
    . '    <code class="bu-proc-admin-id">__ID__</code>'
    . '    <button type="button" class="button-link-delete bu-proc-remove">Entfernen</button>'
    . '  </div>'
    . '  <div class="bu-proc-admin-grid">'
    . '    <label>Titel<br><input type="text" class="regular-text bu-proc-title" name="bu_proc[__ID__][title]" value="" /></label>'
    . '    <label>Kurztext<br><input type="text" class="regular-text" name="bu_proc[__ID__][short]" value="" /></label>'
    . '    <label>Link Label<br><input type="text" class="regular-text" name="bu_proc[__ID__][link_label]" value="" /></label>'
    . '    <label>Link URL<br><input type="text" class="regular-text" name="bu_proc[__ID__][link]" value="" /></label>'
    . '    <label class="bu-proc-span-2">Was passiert?<br><textarea rows="3" class="large-text" name="bu_proc[__ID__][what]"></textarea></label>'
    . '    <label class="bu-proc-span-2">Wer?<br><textarea rows="2" class="large-text" name="bu_proc[__ID__][who]"></textarea></label>'
    . '    <label class="bu-proc-span-2">Im System<br><textarea rows="2" class="large-text" name="bu_proc[__ID__][system]"></textarea></label>'
    . '    <label class="bu-proc-span-2">Regeln<br><textarea rows="2" class="large-text" name="bu_proc[__ID__][rules]"></textarea></label>'
    . '  </div>'
    . '</li>';
    return $tpl;
}

private static function render_admin_taxonomy($tax, $hierarchical){
        if (!taxonomy_exists($tax)){
            echo '<p>Taxonomie nicht gefunden.</p>';
            return;
        }

        $tab = ($tax === self::TAX_LVL) ? 'levels' : (($tax === self::TAX_ACT) ? 'actions' : 'categories');

        $action  = isset($_GET['action']) ? sanitize_key($_GET['action']) : '';
        $term_id = isset($_GET['term_id']) ? intval($_GET['term_id']) : 0;

        // Hinweis: Löschen verhindert (aktive Ideen vorhanden)
        if (isset($_GET['bu_notice']) && sanitize_key($_GET['bu_notice']) === 'term_in_use') {
            $n_tax = isset($_GET['bu_notice_tax']) ? sanitize_text_field($_GET['bu_notice_tax']) : '';
            $n_tid = isset($_GET['bu_notice_term']) ? intval($_GET['bu_notice_term']) : 0;
            if ($n_tax === $tax && $n_tid) {
                $term_obj = get_term($n_tid, $tax);
                $term_name = ($term_obj && !is_wp_error($term_obj)) ? $term_obj->name : ('#'.$n_tid);
                $count = self::count_active_ideas_for_term($tax, $n_tid, ($tax === self::TAX_LVL));
                if ($count > 0) {
                    if ($tax === self::TAX_CAT) {
                        $msg = 'Es gibt noch '.$count.' aktive Idee(n) in dieser Kategorie "'.$term_name.'". Bitte zuerst verschieben oder archivieren.';
                    } elseif ($tax === self::TAX_LVL) {
                        $msg = 'Es gibt noch '.$count.' aktive Idee(n) auf dieser Ebene "'.$term_name.'". Bitte zuerst verschieben oder archivieren.';
                    } else {
                        $msg = 'Es gibt noch '.$count.' aktive Idee(n) mit dieser Aktion "'.$term_name.'". Bitte zuerst verschieben oder archivieren.';
                    }
                    // Wichtig: Im Kiosk-Modus werden WordPress-Notices per CSS ausgeblendet.
                    // Daher eigene, sehr gut sichtbare Warnbox (auch im Kiosk-Modus sichtbar).
                    $dismiss_url = esc_url(remove_query_arg(['bu_notice','bu_notice_tax','bu_notice_term']));
                    echo '<div class="bu-alert bu-alert--danger bu-alert--sticky" role="alert">'
                        . '<div class="bu-alert__icon" aria-hidden="true">⚠</div>'
                        . '<div class="bu-alert__body">'
                        .   '<div class="bu-alert__title">Löschen nicht möglich</div>'
                        .   '<div class="bu-alert__text">'.esc_html($msg).'</div>'
                        . '</div>'
                        . '<div class="bu-alert__actions">'
                        .   '<a class="button button-secondary" href="'.$dismiss_url.'">OK</a>'
                        . '</div>'
                        . '</div>';
                }
            }
        }

        // Delete (GET)
        if ($action === 'delete' && $term_id){
            check_admin_referer('bu_tax_delete_'.$tax.'_'.$term_id);
            $in_use = self::count_active_ideas_for_term($tax, $term_id, ($tax === self::TAX_LVL));
            if ($in_use > 0) {
                // Sofort sichtbare Fehlermeldung nach Redirect (unabhängig von WordPress settings_errors Mechanik)
                $redirect = remove_query_arg(['action','term_id','_wpnonce','bu_notice','bu_notice_tax','bu_notice_term']);
                $redirect = add_query_arg([
                    'bu_notice'      => 'term_in_use',
                    'bu_notice_tax'  => $tax,
                    'bu_notice_term' => $term_id,
                ], $redirect);
                wp_safe_redirect($redirect);
                exit;
            }
            $res = wp_delete_term($term_id, $tax);
            if (is_wp_error($res)){
                add_settings_error('bu_admin','bu_tax_del','Löschen fehlgeschlagen: '.$res->get_error_message(),'error');
            } else {
                add_settings_error('bu_admin','bu_tax_del_ok','Gelöscht.','updated');
            }
            wp_safe_redirect(remove_query_arg(['action','term_id','_wpnonce']));
            exit;
        }

        // Bulk add Untergruppen (POST) – nur für Ebenen; jede Zeile = eine Untergruppe (wie Google Ads Keywords)
        if ($tax === self::TAX_LVL && $hierarchical && !empty($_POST) && isset($_POST['bu_tax_bulk_nonce']) && wp_verify_nonce(sanitize_text_field($_POST['bu_tax_bulk_nonce']), 'bu_tax_bulk_'.$tax)){
            $bulk_parent = isset($_POST['bulk_parent']) ? intval($_POST['bulk_parent']) : 0;
            $bulk_raw    = isset($_POST['bulk_terms']) ? wp_unslash($_POST['bulk_terms']) : '';
            $bulk_raw    = trim($bulk_raw);
            $nat = get_term_by('slug','national', self::TAX_LVL);
            if (!$nat) $nat = get_term_by('name','National', self::TAX_LVL);
            $nat_id = ($nat && !is_wp_error($nat)) ? intval($nat->term_id) : 0;

            if (!$bulk_parent){
                add_settings_error('bu_admin','bu_bulk_parent','Bitte eine Ebene auswählen (nicht National).','error');
            } else if ($nat_id && $bulk_parent === $nat_id){
                add_settings_error('bu_admin','bu_bulk_national','Für National sind keine Untergruppen erlaubt.','error');
            } else if ($bulk_raw === ''){
                add_settings_error('bu_admin','bu_bulk_empty','Bitte mindestens eine Zeile eingeben.','error');
            } else {
                $lines_in = preg_split('/\r\n|\r|\n/', $bulk_raw);
                $names = [];
                foreach ($lines_in as $ln){
                    $nm = trim($ln);
                    if ($nm==='') continue;
                    $names[$nm] = true;
                }
                $names = array_keys($names);
                $created = 0; $skipped = 0; $failed = 0;

                $pterm = get_term($bulk_parent, $tax);
                $pslug = ($pterm && !is_wp_error($pterm)) ? $pterm->slug : '';

                foreach ($names as $nm){
                    $exists = term_exists($nm, $tax, $bulk_parent);
                    if ($exists){ $skipped++; continue; }
                    $slug_child = sanitize_title($nm);
                    $slug_full  = $pslug ? sanitize_title($pslug.'-'.$slug_child) : $slug_child;
                    $res = wp_insert_term($nm, $tax, ['parent'=>$bulk_parent, 'slug'=>$slug_full]);
                    if (is_wp_error($res)) $failed++; else $created++;
                }

                $redir = remove_query_arg(['action','term_id','bu_bulk','created','skipped','failed','_wpnonce']);
                $redir = add_query_arg(['bu_bulk'=>1,'created'=>$created,'skipped'=>$skipped,'failed'=>$failed], $redir);
                wp_safe_redirect($redir);
                exit;
            }
        }

        // Add/Edit (POST)
        if (!empty($_POST) && isset($_POST['bu_tax_nonce']) && wp_verify_nonce(sanitize_text_field($_POST['bu_tax_nonce']), 'bu_tax_'.$tax)){
            $name   = isset($_POST['name']) ? sanitize_text_field(wp_unslash($_POST['name'])) : '';
            $slug   = isset($_POST['slug']) ? sanitize_title(wp_unslash($_POST['slug'])) : '';
            $parent = ($hierarchical && isset($_POST['parent'])) ? intval($_POST['parent']) : 0;

            $block_national = false;
            // Keine Untergruppen für National erlauben (Ebene-Taxonomie)
            if ($tax === self::TAX_LVL && $hierarchical && $parent){
                $nat = get_term_by('slug','national', self::TAX_LVL);
                if (!$nat) $nat = get_term_by('name','National', self::TAX_LVL);
                $nat_id = ($nat && !is_wp_error($nat)) ? intval($nat->term_id) : 0;
                if ($nat_id && $parent === $nat_id){
                    add_settings_error('bu_admin','bu_tax_national','Für National sind keine Untergruppen erlaubt.','error');
                    $block_national = true;
                }
            }

            if ($block_national){
                // ungültig – keine Aktion
            } else if ($name === ''){
                add_settings_error('bu_admin','bu_tax_name','Bitte einen Namen angeben.','error');
            } else {
                if (isset($_POST['term_id']) && intval($_POST['term_id']) > 0){
                    $tid = intval($_POST['term_id']);
                    $args = ['name'=>$name];
                    if ($slug) $args['slug'] = $slug;
                    if ($hierarchical) $args['parent'] = $parent;
                    $res = wp_update_term($tid, $tax, $args);
                    if (is_wp_error($res)){
                        add_settings_error('bu_admin','bu_tax_upd','Speichern fehlgeschlagen: '.$res->get_error_message(),'error');
                    } else {
                        add_settings_error('bu_admin','bu_tax_upd_ok','Gespeichert.','updated');
                        wp_safe_redirect(remove_query_arg(['action','term_id']));
                        exit;
                    }
                } else {
                    $args = [];
                    if ($slug) $args['slug'] = $slug;
                    if ($hierarchical) $args['parent'] = $parent;
                    $res = wp_insert_term($name, $tax, $args);
                    if (is_wp_error($res)){
                        add_settings_error('bu_admin','bu_tax_add','Anlegen fehlgeschlagen: '.$res->get_error_message(),'error');
                    } else {
                        add_settings_error('bu_admin','bu_tax_add_ok','Angelegt.','updated');
                        wp_safe_redirect(remove_query_arg(['action','term_id']));
                        exit;
                    }
                }
            }
        }

        $title = ($tax === self::TAX_LVL) ? 'Ebenen' : (($tax === self::TAX_ACT) ? 'Vorstösse/Aktionen' : 'Kategorien');

        // Ergebnis-Hinweis für Masseneintrag
        if (isset($_GET['bu_bulk'])){
            $created = isset($_GET['created']) ? intval($_GET['created']) : 0;
            $skipped = isset($_GET['skipped']) ? intval($_GET['skipped']) : 0;
            $failed  = isset($_GET['failed']) ? intval($_GET['failed']) : 0;
            $msg = 'Masseneintrag Untergruppen: '.$created.' angelegt, '.$skipped.' übersprungen, '.$failed.' Fehler.';
            $cls = ($failed>0) ? 'notice notice-warning' : 'notice notice-success';
            echo '<div class="'.$cls.'"><p>'.esc_html($msg).'</p></div>';
        }

        echo '<div style="display:flex;gap:24px;margin-top:16px;align-items:flex-start;">';

        // List
        $terms = get_terms([
            'taxonomy'   => $tax,
            'hide_empty' => false,
            'orderby'    => 'name',
            'order'      => 'ASC',
        ]);

        echo '<div style="flex:2;min-width:520px;">';
        echo '<h2 style="margin-top:0;">'.esc_html($title).'</h2>';
        echo '<table class="widefat striped"><thead><tr>';
        echo '<th>Name</th><th>Slug</th><th>Anzahl</th><th>Aktionen</th>';
        echo '</tr></thead><tbody>';

        if (is_wp_error($terms) || empty($terms)){
            echo '<tr><td colspan="4"><em>Keine Einträge.</em></td></tr>';
        } else {
            foreach ($terms as $t){
                $edit_url = esc_url(add_query_arg([
                    'page'    => 'bottomup_admin',
                    'tab'     => $tab,
                    'action'  => 'edit',
                    'term_id' => $t->term_id,
                ], admin_url('admin.php')));

                $del_url = wp_nonce_url(
                    add_query_arg([
                        'page'    => 'bottomup_admin',
                        'tab'     => $tab,
                        'action'  => 'delete',
                        'term_id' => $t->term_id,
                    ], admin_url('admin.php')),
                    'bu_tax_delete_'.$tax.'_'.$t->term_id
                );

                echo '<tr>';
                echo '<td>'.esc_html($t->name).'</td>';
                echo '<td><code>'.esc_html($t->slug).'</code></td>';
                echo '<td>'.intval($t->count).'</td>';
                echo '<td>';
                echo '<a class="button button-small" href="'.$edit_url.'">Bearbeiten</a> ';
                echo '<a class="button button-small" href="'.esc_url($del_url).'" data-confirm="Diese Taxonomie wirklich löschen?" >Löschen</a>';
                echo '</td>';
                echo '</tr>';
            }
        }

        echo '</tbody></table>';
        echo '</div>';

        // Form
        $is_edit = ($action === 'edit' && $term_id);
        $term = null;
        if ($is_edit){
            $term = get_term($term_id, $tax);
            if (!$term || is_wp_error($term)) $is_edit = false;
        }

        $name_val   = $is_edit ? $term->name : '';
        $slug_val   = $is_edit ? $term->slug : '';
        $parent_val = ($hierarchical && $is_edit) ? intval($term->parent) : 0;

        echo '<div style="flex:1;min-width:320px;">';
        echo '<h2 style="margin-top:0;">'.($is_edit ? 'Bearbeiten' : 'Neu anlegen').'</h2>';
        echo '<form method="post">';
        echo '<input type="hidden" name="bu_tax_nonce" value="'.esc_attr(wp_create_nonce('bu_tax_'.$tax)).'">';
        if ($is_edit) echo '<input type="hidden" name="term_id" value="'.intval($term_id).'">';
        echo '<p><label><strong>Name</strong><br><input type="text" name="name" class="regular-text" value="'.esc_attr($name_val).'" required></label></p>';
        echo '<p><label><strong>Slug</strong> <span class="description">(optional)</span><br><input type="text" name="slug" class="regular-text" value="'.esc_attr($slug_val).'"></label></p>';

        if ($hierarchical){
            $parent_terms = get_terms(['taxonomy'=>$tax,'hide_empty'=>false,'orderby'=>'name','order'=>'ASC']);
            echo '<p><label><strong>Parent</strong><br><select name="parent" class="regular-text">';
            echo '<option value="0">— Keine —</option>';
            if (!is_wp_error($parent_terms)){
                foreach ($parent_terms as $pt){
                    if ($is_edit && intval($pt->term_id) === intval($term_id)) continue;
                    echo '<option value="'.intval($pt->term_id).'" '.selected($parent_val, $pt->term_id, false).'>'.esc_html($pt->name).'</option>';
                }
            }
            echo '</select></label></p>';
        }

        echo '<p><button type="submit" class="button button-primary">'.($is_edit ? 'Speichern' : 'Anlegen').'</button> ';
        if ($is_edit){
            $back = esc_url(remove_query_arg(['action','term_id']));
            echo '<a class="button" href="'.$back.'">Abbrechen</a>';
        }
        echo '</p>';

        echo '</form>';
        // Masseneintrag Untergruppen (nur Ebenen; National ausgeschlossen)
        if ($tax === self::TAX_LVL && $hierarchical && !$is_edit){
            $parent_terms = get_terms([
                'taxonomy'   => $tax,
                'hide_empty' => false,
                'parent'     => 0,
                'orderby'    => 'name',
                'order'      => 'ASC',
            ]);

            echo '<hr style="margin:18px 0;">';
            echo '<h2 style="margin-top:0;">Masseneintrag Untergruppen</h2>';
            echo '<p class="description">Jede neue Zeile wird als neue Untergruppe angelegt (ähnlich Google Ads Keywords). <strong>National</strong> ist ausgeschlossen.</p>';
            echo '<form method="post">';
            echo '<input type="hidden" name="bu_tax_bulk_nonce" value="'.esc_attr(wp_create_nonce('bu_tax_bulk_'.$tax)).'">';

            echo '<p><label><strong>Ebene</strong><br><select name="bulk_parent" required style="width:100%;">';
            echo '<option value="">— wählen —</option>';
            if (!is_wp_error($parent_terms)){
                foreach ($parent_terms as $pt){
                    $sl = strtolower($pt->slug);
                    $nm = strtolower($pt->name);
                    if ($sl==='national' || $nm==='national') continue;
                    echo '<option value="'.intval($pt->term_id).'">'.esc_html($pt->name).'</option>';
                }
            }
            echo '</select></label></p>';

            echo '<p><label><strong>Untergruppen (eine pro Zeile)</strong><br>';
            echo '<textarea name="bulk_terms" rows="10" style="width:100%;font-family:monospace" placeholder="Zürich&#10;Bern&#10;Basel"></textarea>';
            echo '</label></p>';

            echo '<p><button type="submit" class="button">Untergruppen anlegen</button></p>';
            echo '</form>';
        }
        echo '</div>';

        echo '</div>';
    }


    /*** Back-Buttons ***/
    public static function render_back_bar($post){
        if (!is_object($post) || !isset($post->post_type) || $post->post_type!==self::CPT) return;
        $url = self::get_back_url();
        $iid = intval($post->ID);
        $round = self::get_round_current($iid);
        $readonly = self::is_idea_archived($iid);

        $dl_html = '';
        $dl = self::get_round_deadline($iid, $round);
        if ($dl){
            $dl_txt = self::fmt_round_deadline($dl);
            if ($dl_txt){
                $expired = self::deadline_is_expired($dl);
                $cls = $expired ? ' bu-deadline-expired' : '';
                $title = $expired ? ' title="verstrichen"' : '';
                $dl_html = '<span class="bu-round-deadline'.$cls.'"'.$title.' style="margin-left:8px;color:#444">Runde #'.$round.' läuft bis '.esc_html($dl_txt).'</span>';
            }
        }

        $start_btn = '';
        if (!$readonly && current_user_can('edit_post', $iid)){
            $start_url = wp_nonce_url(admin_url('admin-post.php?action=bu_start_round&post='.$iid), 'bu_start_round_'.$iid);
            $next_dl = self::get_round_deadline($iid, $round + 1);
            $next_dl_date = '';
            $next_dl_time = '';
            if ($next_dl){
                try {
                    $tz = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone(get_option('timezone_string') ?: 'UTC');
                    $dt = new DateTime($next_dl, $tz);
                    $next_dl_date = $dt->format('d.m.Y');
                    $next_dl_time = $dt->format('H:i');
                } catch (Exception $e) { $next_dl_date = ''; $next_dl_time = ''; }
            }
            $start_btn = '<a class="button bu-start-round" style="margin-right:6px" href="'.esc_url($start_url).'" data-url="'.esc_attr($start_url).'" data-next-deadline-date="'.esc_attr($next_dl_date).'" data-next-deadline-time="'.esc_attr($next_dl_time).'">🔁 Neue Runde starten</a>';
        }
        echo '<div class="notice notice-info bu-backbar"><p>'
            .'<a class="button bu-backbtn" style="margin-right:6px" href="'.esc_url($url).'">← Zurück zur Liste</a>'
            .$start_btn
            .'<button type="button" class="button" id="bu-open-versions" data-idea="'.$iid.'" style="margin-right:6px">🕘 Versionen</button>'
            .'<span class="bu-round-badge" title="Aktuelle Runde">Runde #'.$round.'</span>'.$dl_html
            .'</p></div>';
    }
    public static function admin_footer_back_button(){
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if (!$screen || $screen->base!=='post' || $screen->post_type!==self::CPT) return;
        $url = self::get_back_url();
        echo '<script>document.addEventListener("DOMContentLoaded",function(){function addBtn(){var bar=document.querySelector(".edit-post-header__toolbar");if(!bar){setTimeout(addBtn,400);return;}if(document.getElementById("bu-back-top"))return;var a=document.createElement("a");a.id="bu-back-top";a.className="components-button is-secondary";a.href="'.esc_js($url).'";a.textContent="← Zurück zur Liste";bar.prepend(a);}addBtn();});</script>';
    }
    public static function adminbar_back($wp_admin_bar){
        if (!is_admin()) return;
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if (!$screen || $screen->base!=='post' || $screen->post_type!==self::CPT) return;
        $wp_admin_bar->add_node([
            'id'    => 'bu-back',
            'title' => '← Zurück zur Liste',
            'href'  => self::get_back_url(),
            'meta'  => ['class'=>'bu-backbar-ab']
        ]);
    }
    public static function lock_side_sortables(){
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if (!$screen || $screen->post_type!==self::CPT) return;
        echo '<style>#side-sortables .postbox .hndle{cursor:default}#side-sortables .handle-actions, #side-sortables .postbox .handle-order-higher, #side-sortables .postbox .handle-order-lower{display:none!important}</style>';
        echo "<script>try{jQuery(function($){ $('#side-sortables, #normal-sortables, #advanced-sortables').sortable('disable'); });}catch(e){}</script>";
        // Screen Options dürfen unsere Boxen nicht verstecken
        add_filter('get_user_option_metaboxhidden_'.self::CPT, function($hidden){
            if (!is_array($hidden)) return [];
            $keep = ['bu_side_actions','bu_side_level','bu_side_cat','bu_side_state','submitdiv'];
            return array_values(array_diff($hidden, $keep));
        });
    }

    /*** Selftest ***/
    public static function maybe_selftest_on_our_pages($screen){
        if (!is_admin() || !current_user_can('read')) return;
        $ok_pages = ['bottomup_dashboard','bottomup_ideas','bottomup_view','bottomup_export'];
        $page = isset($_GET['page']) ? sanitize_key($_GET['page']) : '';
        if (!in_array($page, $ok_pages, true)) return;
        foreach ([self::TAX_CAT, self::TAX_LVL, self::TAX_ACT] as $tax){
            if ( ! taxonomy_exists($tax) ){ self::$selftest_errors[] = 'Taxonomy fehlt: '.$tax; }
        }
        if ( ! post_type_exists(self::CPT) ){ self::$selftest_errors[] = 'Post Type fehlt: '.self::CPT; }
    }

    /*** Activation ***/
    public static function on_activate(){
        self::register_taxonomies();
        self::ensure_levels_exist();
                self::ensure_actions_exist();
add_option('bu_activated_1710g', time());
        self::pm_install_tables();
        self::versions_install_tables();
        update_option('bu_idea_versions_db_ver', intval(self::VERS_DB_VER));
    }












    private static function is_bottomup_page(){
        if (!is_admin()) return false;
        $page = isset($_GET['page']) ? sanitize_key($_GET['page']) : '';
        if ($page === 'bottomup_dashboard') return true;
        if ($page && strpos($page, 'bottomup_') === 0) return true;
        return false;
    }

    public static function suppress_admin_notices(){
        // Only suppress on BottomUp pages and only in kiosk mode
        if (!self::is_kiosk_enabled()) return;
        if (!self::is_bottomup_page()) return;

        global $wp_filter;
        $hooks = ['admin_notices','all_admin_notices','network_admin_notices','user_admin_notices'];

        foreach ($hooks as $hook){
            if (empty($wp_filter[$hook])) continue;
            $filter = $wp_filter[$hook];
            if (!is_object($filter) || empty($filter->callbacks)) continue;

            foreach ($filter->callbacks as $prio => $cbs){
                foreach ($cbs as $id => $cb){
                    $fn = $cb['function'] ?? null;
                    $keep = false;

                    // Keep our own notices (from this class) if any
                    if (is_array($fn)){
                        if ($fn[0] === __CLASS__) $keep = true;
                        elseif (is_object($fn[0]) && get_class($fn[0]) === __CLASS__) $keep = true;
                    } elseif (is_string($fn)){
                        if (strpos($fn, 'BU_Ideas') !== false) $keep = true;
                    }

                    if (!$keep){
                        unset($wp_filter[$hook]->callbacks[$prio][$id]);
                    }
                }
            }
        }

        // Also hide footer text/version to keep UI clean
        add_filter('admin_footer_text', '__return_empty_string', 999);
        add_filter('update_footer', '__return_empty_string', 999);
    }

    public static function suppress_admin_notice_css(){
        if (!self::is_kiosk_enabled()) return;
        if (!self::is_bottomup_page()) return;
        echo '<style>
            #wpbody-content > .notice,
            #wpbody-content > .updated,
            #wpbody-content > .error,
            #wpbody-content > .update-nag,
            #wpbody-content > .updated-message,
            .notice,
            .update-nag,
            .wp-admin-notice { display:none !important; }
        </style>';
    }







    public static function activation_notice(){
        $ts = get_option('bu_activated_1710g');
        if ($ts){
            delete_option('bu_activated_1710g');
            echo '<div class="notice notice-success is-dismissible"><p><strong>Bottom Up Ideas v1.7.10h</strong> wurde aktiviert.</p></div>';
        }
    }
}
endif;
