(function($){
  function getIds(){
    var ids = [];
    $('#bu-proc-admin-list .bu-proc-admin-item').each(function(){
      var id = $(this).data('id');
      if (id) ids.push(String(id));
    });
    return ids;
  }

  function updateOrder(){
    var ids = getIds();
    $('#bu-proc-order').val(ids.join(','));
    $('#bu-proc-admin-list .bu-proc-admin-item').each(function(i){
      $(this).find('.bu-proc-admin-num').text(i + 1);
    });
  }

  function makeId(){
    // Simple unique-ish key; server will sanitize_key() again
    return 'step_' + Math.random().toString(36).slice(2, 8) + '_' + Date.now().toString(36).slice(-4);
  }

  function addItem(){
    var $list = $('#bu-proc-admin-list');
    var tpl = $('#bu-proc-item-tpl').html() || '';
    if (!tpl) return;

    var id = makeId();
    // Avoid collisions
    while ($list.find('.bu-proc-admin-item[data-id="' + id + '"]').length){
      id = makeId();
    }

    tpl = tpl.replace(/__ID__/g, id).replace(/__NUM__/g, String($list.children().length + 1));
    $list.append(tpl);
    updateOrder();
    $list.find('.bu-proc-admin-item[data-id="' + id + '"] .bu-proc-title').trigger('focus');
  }

  $(function(){
    var $list = $('#bu-proc-admin-list');
    if (!$list.length) return;

    $list.sortable({
      handle: '.bu-proc-handle',
      placeholder: 'bu-proc-sort-placeholder',
      forcePlaceholderSize: true,
      update: updateOrder
    });

    // Remove
    $list.on('click', '.bu-proc-remove', function(e){
      e.preventDefault();
      var msg = (window.BU_PROC_ADMIN && BU_PROC_ADMIN.confirm_remove) ? BU_PROC_ADMIN.confirm_remove : 'Schritt wirklich löschen?';
      if (!confirm(msg)) return;
      $(this).closest('.bu-proc-admin-item').remove();
      updateOrder();
    });

    // Add
    $('#bu-proc-add').on('click', function(e){
      e.preventDefault();
      addItem();
    });

    updateOrder();
  });
})(jQuery);
