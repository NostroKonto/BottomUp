(function($){
  $(function(){
    var $form = $('#bu-rate-form');
    if(!$form.length || typeof BU_LIST==='undefined' || !BU_LIST.rest) return;

    var postId = parseInt($form.data('postid'), 10) || 0;
    if(!postId) return;

    function setMsg(msg, ok){
      var $m = $('#bu-rate-msg');
      if(!$m.length) return;
      $m.text(msg || '');
      $m.css('color', ok ? '#2b7a2b' : '#b32d2e');
    }

    function apiGet(url, signal){
      // Cache buster avoids stale REST responses on some hosts/browsers
      url = (url || '') + ((String(url).indexOf('?')>=0) ? '&' : '?') + '_=' + Date.now();
      return fetch(url, {
        method: 'GET',
        signal: signal,
        headers: {
          'X-WP-Nonce': ((BU_LIST.nonces && BU_LIST.nonces.rest) ? BU_LIST.nonces.rest : BU_LIST.nonce),
          'Cache-Control': 'no-cache'
        },
        credentials: 'same-origin',
        cache: 'no-store'
      }).then(function(r){ return r.json(); });
    }

    function apiPost(url, data){
      return fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type':'application/json',
          'X-WP-Nonce': ((BU_LIST.nonces && BU_LIST.nonces.rest) ? BU_LIST.nonces.rest : BU_LIST.nonce),
          'Cache-Control': 'no-cache'
        },
        credentials: 'same-origin',
        cache: 'no-store',
        body: JSON.stringify(data || {})
      }).then(function(r){ return r.json(); });
    }

    function applyState(st){
      if(!st || st.ok!==true) return;

      // Stats
      if($('#bu_stat_sk_avg').length){
        $('#bu_stat_sk_avg').text((st.avg===null || typeof st.avg==='undefined') ? '–' : st.avg);
        $('#bu_stat_sk_n').text(st.sk_n || 0);
        $('#bu_stat_yes').text(st.yes || 0);
        $('#bu_stat_no').text(st.no || 0);
        $('#bu_stat_vote_n').text(st.vote_n || 0);
        if($('#bu_stat_undecided').length) $('#bu_stat_undecided').text(st.undecided || 0);
      }

      // Objections (SK>=8 and/or "Nein" with comments)
      if($('#bu-objections').length && typeof st.objections_html==='string'){
        $('#bu-objections').html(st.objections_html);
        // visual feedback so users see that the list really updated
        $('#bu-objections').addClass('bu-flash');
        window.setTimeout(function(){ $('#bu-objections').removeClass('bu-flash'); }, 600);
      }

      // Remember current values for overwrite warning + change detection
      if(st.my){
        $form.attr('data-my-sk', (st.my.sk===null || typeof st.my.sk==='undefined') ? '' : String(st.my.sk));
        $form.attr('data-my-sk-comment', st.my.sk_comment || '');
        $form.attr('data-my-vote', st.my.vote || '');
        $form.attr('data-my-vote-comment', st.my.vote_comment || '');
      }
    }

    var _buStateSeq = 0;
    var _buStateCtrl = null;

    function refreshState(){
      var seq = ++_buStateSeq;

      // Abort previous request if supported
      try{
        if (_buStateCtrl && typeof _buStateCtrl.abort === 'function'){
          _buStateCtrl.abort();
        }
      } catch(e){}

      _buStateCtrl = (typeof AbortController !== 'undefined') ? new AbortController() : null;
      var sig = _buStateCtrl ? _buStateCtrl.signal : undefined;

      return apiGet(BU_LIST.rest + 'state/' + postId, sig).then(function(st){
        if (seq !== _buStateSeq) return null; // outdated response
        applyState(st);
        return st;
      }).catch(function(err){
        if (err && err.name === 'AbortError') return null;
        return null;
      });
    }

    // Initial: make sure objections + stats are current
    refreshState();

    // --- Custom modal (avoid native browser prompt/confirm) ---
    function buModal(opts){
      opts = opts || {};
      return new Promise(function(resolve){
        var $ov = $('<div class="bu-modal-overlay" />');
        var $m  = $('<div class="bu-modal" role="dialog" aria-modal="true" />');
        var $head = $('<div class="bu-modal-head" />');
        var $title = $('<div class="bu-modal-title" />').text(opts.title || '');
        var $close = $('<button type="button" class="bu-modal-close" aria-label="Schließen">×</button>');
        $head.append($title).append($close);
        var $body = $('<div class="bu-modal-body" />');
        if (opts.body){
          if (typeof opts.body === 'string') $body.html(opts.body);
          else $body.append(opts.body);
        }
        if (typeof opts.render === 'function') opts.render($body);
        var $foot = $('<div class="bu-modal-foot" />');
        var buttons = Array.isArray(opts.buttons) ? opts.buttons : [{text:'OK', value:true, primary:true}];
        buttons.forEach(function(b){
          var $btn = $('<button type="button" class="button" />').text(b.text || 'OK');
          if (b.primary) $btn.addClass('button-primary');
          $btn.on('click', function(){
            if (typeof b.onClick === 'function'){
              var v = b.onClick({overlay:$ov, modal:$m, body:$body, close:close});
              if (v === false) return; // validation failed
              close(v);
            } else {
              close(b.value);
            }
          });
          $foot.append($btn);
        });

        function close(val){
          $ov.remove();
          resolve(val);
        }
        $close.on('click', function(){ close(null); });
        $ov.on('click', function(e){ if (e.target === $ov[0]) close(null); });

        $m.append($head).append($body).append($foot);
        $ov.append($m);
        $('body').append($ov);
      });
    }
    function modalConfirm(msg){
      return buModal({
        title: 'Bestätigung',
        body: '<p>' + String(msg || '') + '</p>',
        buttons: [
          {text:'Abbrechen', value:false},
          {text:'Überschreiben', value:true, primary:true}
        ]
      });
    }
    function modalComments(opts){
      opts = opts || {};
      var needSk = !!opts.needSk;
      var needNo = !!opts.needNo;
      return buModal({
        title: 'Kommentar(e) eingeben',
        render: function($body){
          if (needSk){
            $body.append('<p><strong>Kommentar zum SK-Einwand</strong> <span class="description">(Pflicht, max. 280 Zeichen)</span></p>');
            $body.append('<textarea id="bu_modal_sk" maxlength="280" />');
            $body.find('#bu_modal_sk').val(opts.preSk || '');
          }
          if (needNo){
            $body.append('<p style="margin-top:12px"><strong>Kommentar zum "Nein"</strong> <span class="description">(Pflicht, max. 280 Zeichen)</span></p>');
            $body.append('<textarea id="bu_modal_no" maxlength="280" />');
            $body.find('#bu_modal_no').val(opts.preNo || '');
          }
          $body.append('<div class="bu-modal-help">Tipp: Du kannst auch Zeilenumbrüche verwenden.</div>');
        },
        buttons: [
          {text:'Abbrechen', value:null},
          {
            text:'OK',
            primary:true,
            onClick: function(ctx){
              var sk = needSk ? String(ctx.body.find('#bu_modal_sk').val() || '').trim() : '';
              var no = needNo ? String(ctx.body.find('#bu_modal_no').val() || '').trim() : '';
              if (needSk && !sk){
                ctx.body.find('#bu_modal_sk').focus();
                return false;
              }
              if (needNo && !no){
                ctx.body.find('#bu_modal_no').focus();
                return false;
              }
              if (sk.length > 280 || no.length > 280){
                return false;
              }
              return {skComment: sk, noComment: no};
            }
          }
        ]
      });
    }

    $form.on('submit', function(e){
      e.preventDefault();
      setMsg('', true);

      var skStr = ($('#bu_sk_value_view').val() || '').toString();
      var skVal = (skStr==='') ? null : parseInt(skStr, 10);
      var voteVal = ($form.find('input[name="vote"]:checked').val() || '').toString();

      if(skStr==='' && !voteVal){
        setMsg('Bitte SK-Wert und/oder Abstimmung wählen.', false);
        return;
      }

      refreshState().then(function(prev){
        prev = prev || { my: {} };
        var prevSk = (prev.my && typeof prev.my.sk!=='undefined') ? prev.my.sk : null;
        var prevSkComment = (prev.my && typeof prev.my.sk_comment!=='undefined') ? (prev.my.sk_comment || '') : '';
        var prevVote = (prev.my && prev.my.vote) ? prev.my.vote : '';
        var prevVoteComment = (prev.my && typeof prev.my.vote_comment!=='undefined') ? (prev.my.vote_comment || '') : '';

        // Collect required comments via custom modal (no browser prompt)
        var needSkComment = (skVal!==null && skVal>=8);
        var needNoComment = (voteVal==='no');

        // Defaults
        var defaultSk = (prevSkComment || '');
        var skComment = (skVal!==null && skVal<8) ? defaultSk : '';
        var noComment = '';

        var commentsPromise;
        if (needSkComment || needNoComment){
          commentsPromise = modalComments({
            needSk: needSkComment,
            needNo: needNoComment,
            preSk: (prev.my && prev.my.sk_comment) ? prev.my.sk_comment : '',
            preNo: (prev.my && prev.my.vote_comment) ? prev.my.vote_comment : ''
          });
        } else {
          commentsPromise = Promise.resolve({skComment: skComment, noComment: noComment});
        }

        return commentsPromise.then(function(comments){
          if (comments===null){ throw 'cancelled'; }

          if (needSkComment){ skComment = (comments.skComment || '').trim(); }
          if (needNoComment){ noComment = (comments.noComment || '').trim(); }

          // Detect overwrite / no-change (incl. comment changes)
          var skWill = (skVal!==null);
          var voteWill = !!voteVal;
          var skIsNew = skWill && (prevSk===null || typeof prevSk==='undefined');
          var voteIsNew = voteWill && (!prevVote);

          var skChanged = skWill && !skIsNew && (String(prevSk)!==String(skVal) || String(prevSkComment||'')!==String(skComment||''));
          var voteChanged = voteWill && !voteIsNew && (String(prevVote)!==String(voteVal) || String(prevVoteComment||'')!==String((voteVal==='no'?noComment:'')));
          var anyChanged = skIsNew || voteIsNew || skChanged || voteChanged;
          if(!anyChanged){
            setMsg('Keine Änderungen.', true);
            throw 'cancelled';
          }

          var overwriteAttempt = (skWill && !skIsNew) || (voteWill && !voteIsNew);
          return Promise.resolve(true).then(function(){
            if (!overwriteAttempt) return true;
            return modalConfirm('Du hast in dieser Runde bereits eine Bewertung/Abstimmung abgegeben. Möchtest du sie überschreiben?');
          }).then(function(ok){
            if (!ok){ throw 'cancelled'; }
            return {skComment: skComment, noComment: noComment};
          });
        }).then(function(comments){
          skComment = comments.skComment || '';
          noComment = comments.noComment || '';

          var chain = Promise.resolve();
          var didSomething = false;

          if(skVal!==null){
            didSomething = true;
            chain = chain.then(function(){
              return apiPost(BU_LIST.rest + 'rate/' + postId, { value: String(skVal), comment: skComment });
            }).then(function(res){
              if(!res || res.ok!==true){
                setMsg((res && res.message) ? res.message : 'Fehler beim Speichern der SK-Bewertung.', false);
                throw 'cancelled';
              }
            });
          }

          if(voteVal){
            didSomething = true;
            chain = chain.then(function(){
              return apiPost(BU_LIST.rest + 'vote/' + postId, { value: voteVal, comment: (voteVal==='no'?noComment:'') });
            }).then(function(res){
              if(!res || res.ok!==true){
                setMsg((res && res.message) ? res.message : 'Fehler beim Speichern der Abstimmung.', false);
                throw 'cancelled';
              }
            });
          }

          if(!didSomething) throw 'cancelled';

          return chain.then(function(){
            return refreshState();
          }).then(function(){
            setMsg('Gespeichert.', true);
          });
        });
      }).catch(function(err){
        // keep existing message
        if(err==='cancelled') return;
        setMsg('Unerwarteter Fehler.', false);
      });
    });

  });
})(jQuery);
