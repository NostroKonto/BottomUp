
(function($){
  function findPostIdFromRow($row){
    if(!$row || !$row.length) return null;
    var id=null;
    var rid = $row.attr('id')||''; var m = rid.match(/(\d+)/); if(m) id = m[1];
    if(!id){
      var d = $row.data('id')||$row.data('postId')||$row.data('post-id'); if(d) id = d;
    }
    if(!id){
      // look for a link with post=ID in same row
      var a = $row.find('a[href*="post="]').first().attr('href')||''; var mm=a.match(/[?&]post=(\d+)/); if(mm) id = mm[1];
    }
    return id;
  }
  function ensurePrintHref(el, id){
    try{
      var u = new URL(el.getAttribute('href'), window.location.origin);
      if(u.searchParams.get('page')!=='bottomup_print') return;
      if(id) u.searchParams.set('post', id);
      el.setAttribute('href', u.toString());
    }catch(e){}
  }
  $(function(){
    var params = new URLSearchParams(window.location.search||'');

    // On ideas list page: remember last printed ID and fix print href.
    if(params.get('page')==='bottomup_ideas'){
      document.addEventListener('click', function(e){
        var a = e.target.closest('a'); if(!a) return;
        var href = a.getAttribute('href')||'';
        if(href.indexOf('bottomup_print')===-1 && !a.classList.contains('bui-print')) return;
        var $row = $(a).closest('tr, .item, .row, .entry, li, div');
        var id = findPostIdFromRow($row);
        if(id){
          try{ localStorage.setItem('bu_last_print_id', String(id)); }catch(e){}
          ensurePrintHref(a, id);
        }
      }, { capture:true });
    }

    // Custom modal (avoid native browser prompt/confirm)
    function buModal(opts){
      opts = opts || {};
      return new Promise(function(resolve){
        var $ov = $('<div class="bu-modal-overlay" />');
        var $m  = $('<div class="bu-modal" role="dialog" aria-modal="true" />');
        var $head = $('<div class="bu-modal-head" />');
        var $title = $('<div class="bu-modal-title" />').text(opts.title || '');
        var $close = $('<button type="button" class="bu-modal-close" aria-label="Schließen">×</button>');
        $head.append($title).append($close);
        var $body = $('<div class="bu-modal-body" />');
        if (opts.body){
          if (typeof opts.body === 'string') $body.html(opts.body);
          else $body.append(opts.body);
        }
        if (typeof opts.render === 'function') opts.render($body);
        var $foot = $('<div class="bu-modal-foot" />');
        (opts.buttons || [{text:'OK', value:true, primary:true}]).forEach(function(b){
          var $btn = $('<button type="button" class="button" />').text(b.text || 'OK');
          if (b.primary) $btn.addClass('button-primary');
          $btn.on('click', function(){
            if (typeof b.onClick === 'function'){
              var v = b.onClick({overlay:$ov, modal:$m, body:$body, close:close});
              if (v === false) return;
              close(v);
            } else {
              close(b.value);
            }
          });
          $foot.append($btn);
        });
        function close(val){ $ov.remove(); resolve(val); }
        $close.on('click', function(){ close(null); });
        $ov.on('click', function(e){ if (e.target === $ov[0]) close(null); });
        $m.append($head).append($body).append($foot);
        $ov.append($m);
        $('body').append($ov);
      });
    }

    // Start new round: optional deadline input after clicking the button (works in view + list)
    $(document).on('click', 'a.bu-start-round', function(e){
      e.preventDefault();
      var url = $(this).attr('data-url') || $(this).attr('href');
      if(!url) return;

      var preDate = ($(this).attr('data-next-deadline-date') || '').toString().trim();
      var preTime = ($(this).attr('data-next-deadline-time') || '').toString().trim();
      buModal({
        title: 'Neue Runde starten',
        render: function($body){
          $body.append('<p>Der aktuelle Stand wird als Version gespeichert und eine neue Runde beginnt.</p>');
          $body.append('<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;align-items:end;margin-top:10px">'
            + '<div><label style="display:block;font-weight:600;margin:0 0 6px">Deadline Datum (optional)</label>'
            + '<input type="text" id="bu_modal_deadline_date" placeholder="dd.mm.yyyy" inputmode="numeric" style="width:100%" /></div>'
            + '<div><label style="display:block;font-weight:600;margin:0 0 6px">Uhrzeit (optional)</label>'
            + '<input type="text" id="bu_modal_deadline_time" placeholder="HH:MM (00:00-24:00)" inputmode="numeric" style="width:100%" /></div>'
            + '</div>');
          if (preDate) $body.find('#bu_modal_deadline_date').val(preDate);
          if (preTime) $body.find('#bu_modal_deadline_time').val(preTime);
          $body.append('<div id="bu_modal_deadline_err" class="bu-modal-help" style="margin-top:8px;color:#b32d2e;display:none"></div>');
          $body.append('<div class="bu-modal-help" style="margin-top:8px">Format: dd.mm.yyyy und Uhrzeit HH:MM (24h). Leer lassen = keine Deadline.</div>');
        },
        buttons: [
          {text:'Abbrechen', value:null},
          {text:'Starten', primary:true, onClick:function(ctx){
            var date = String(ctx.body.find('#bu_modal_deadline_date').val() || '').trim();
            var time = String(ctx.body.find('#bu_modal_deadline_time').val() || '').trim();
            var $err = ctx.body.find('#bu_modal_deadline_err');
            $err.hide().text('');

            if (!date && !time){
              return {deadline_date:'', deadline_time:''};
            }
            if (date && !time) time = '00:00';
            if (!date && time){
              $err.text('Bitte Datum angeben (dd.mm.yyyy) oder beide Felder leer lassen.').show();
              return false;
            }

            if (!/^\d{2}\.\d{2}\.\d{4}$/.test(date)){
              $err.text('Bitte Datum im Format dd.mm.yyyy eingeben.').show();
              return false;
            }
            if (!/^\d{2}:\d{2}$/.test(time)){
              $err.text('Bitte Uhrzeit im Format HH:MM eingeben.').show();
              return false;
            }
            var hh = parseInt(time.slice(0,2),10);
            var mm = parseInt(time.slice(3,5),10);
            if (isNaN(hh) || isNaN(mm) || mm<0 || mm>59 || hh<0 || hh>24 || (hh===24 && mm!==0)){
              $err.text('Uhrzeit muss zwischen 00:00 und 24:00 liegen.').show();
              return false;
            }

            return {deadline_date: date, deadline_time: time};
          }}
        ]
      }).then(function(res){
        if(!res) return;
        var date = (res.deadline_date || '').trim();
        var time = (res.deadline_time || '').trim();
        if(date){
          var sep = (url.indexOf('?')>=0) ? '&' : '?';
          url = url + sep + 'deadline_date=' + encodeURIComponent(date) + '&deadline_time=' + encodeURIComponent(time || '00:00');
        }
        window.location.href = url;
      });
    });

  });
})(jQuery);
