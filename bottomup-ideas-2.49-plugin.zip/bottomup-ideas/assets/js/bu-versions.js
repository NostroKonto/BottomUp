(function($){
  function ensureUI(){
    if(document.getElementById('bu-vers-overlay')) return;

    $('body').append(
      '<div id="bu-vers-overlay" class="bu-vers-overlay" style="display:none"></div>' +
      '<div id="bu-vers-drawer" class="bu-vers-drawer" style="display:none">' +
        '<div class="bu-vers-head">' +
          '<div><strong>Versionen</strong> <span class="bu-vers-sub" id="bu-vers-sub"></span></div>' +
          '<div class="bu-vers-head-actions">' +
            '<a href="#" class="button button-small" id="bu-vers-refresh">Aktualisieren</a>' +
            '<a href="#" class="button button-small" id="bu-vers-close">Schließen</a>' +
          '</div>' +
        '</div>' +
        '<div class="bu-vers-body">' +
          '<div class="bu-vers-empty" id="bu-vers-empty" style="display:none">Keine Versionen gespeichert.</div>' +
          '<ul class="bu-vers-list" id="bu-vers-list"></ul>' +
          '<div class="bu-vers-hint">Tipp: Mit „Neue Runde starten“ wird der aktuelle Stand gespeichert.</div>' +
        '</div>' +
      '</div>' +
      '<div id="bu-diff-modal" class="bu-diff-modal" style="display:none">' +
        '<div class="bu-diff-inner">' +
          '<div class="bu-diff-modal-head">' +
            '<strong>Vergleich</strong>' +
            '<a href="#" class="button button-small" id="bu-diff-close">Schließen</a>' +
          '</div>' +
          '<div class="bu-diff-content" id="bu-diff-content"></div>' +
        '</div>' +
      '</div>'
    );
  }

  function openDrawer(){
    ensureUI();
    $('#bu-vers-overlay').show();
    $('#bu-vers-drawer').show();
    loadVersions();
  }

  function closeDrawer(){
    $('#bu-vers-drawer').hide();
    $('#bu-vers-overlay').hide();
  }

  function openModal(html){
    ensureUI();
    $('#bu-diff-content').html(html || '');
    $('#bu-diff-modal').show();
    $('#bu-vers-overlay').show();
  }

  function closeModal(){
    $('#bu-diff-modal').hide();
  }

  function loadVersions(){
    if(!window.BU_VERS || !BU_VERS.idea){
      $('#bu-vers-empty').show().text('Keine Idee ausgewählt.');
      return;
    }
    $('#bu-vers-list').empty();
    $('#bu-vers-empty').hide();
    $('#bu-vers-sub').text('…');

    $.post(BU_VERS.ajax_url, { action:'bu_versions_list', nonce:((BU_VERS.nonces && BU_VERS.nonces.ajax) ? BU_VERS.nonces.ajax : BU_VERS.nonce), idea:BU_VERS.idea }, function(resp){
      if(!resp || !resp.success){
        $('#bu-vers-sub').text('');
        $('#bu-vers-empty').show().text((resp && resp.data && resp.data.message) ? resp.data.message : 'Fehler beim Laden.');
        return;
      }
      var versions = resp.data.versions || [];
      var curRound = resp.data.current_round || 1;
      $('#bu-vers-sub').text('Aktuell: Runde #' + curRound);

      if(!versions.length){
        $('#bu-vers-empty').show();
        return;
      }

      versions.forEach(function(v){
        var r = v.round || 0;
        var ts = v.ts || '';
        var item = $('<li class="bu-vers-item"></li>');
        var a = $('<a href="#" class="bu-vers-link"></a>');
        a.text('Runde #' + r);
        a.attr('data-round', r);
        var meta = $('<div class="bu-vers-meta"></div>').text(ts);
        item.append(a).append(meta);
        $('#bu-vers-list').append(item);
      });
    });
  }

  function loadDiff(round){
    if(!window.BU_VERS || !BU_VERS.idea) return;
    openModal('<p><em>Lade Vergleich…</em></p>');
    $.post(BU_VERS.ajax_url, { action:'bu_version_diff', nonce:((BU_VERS.nonces && BU_VERS.nonces.ajax) ? BU_VERS.nonces.ajax : BU_VERS.nonce), idea:BU_VERS.idea, round: round }, function(resp){
      if(!resp || !resp.success){
        var msg = (resp && resp.data && resp.data.message) ? resp.data.message : 'Fehler beim Laden.';
        $('#bu-diff-content').html('<div class="notice notice-error" style="margin:0"><p><strong>'+msg+'</strong></p></div>');
        return;
      }
      $('#bu-diff-content').html(resp.data.html || '');
    });
  }

  $(function(){
    $(document).on('click', '#bu-open-versions', function(e){
      e.preventDefault();
      openDrawer();
    });

    $(document).on('click', '#bu-vers-close', function(e){
      e.preventDefault();
      closeModal();
      closeDrawer();
    });

    $(document).on('click', '#bu-vers-overlay', function(e){
      e.preventDefault();
      closeModal();
      closeDrawer();
    });

    $(document).on('click', '#bu-vers-refresh', function(e){
      e.preventDefault();
      loadVersions();
    });

    $(document).on('click', '#bu-diff-close', function(e){
      e.preventDefault();
      closeModal();
    });

    $(document).on('click', '.bu-vers-link', function(e){
      e.preventDefault();
      var round = parseInt($(this).data('round') || '0', 10);
      if(round > 0) loadDiff(round);
    });
  });
})(jQuery);
