
(function($){
  $(function(){
    try{
      var params = new URLSearchParams(window.location.search||'');
      if (params.get('page')!=='bottomup_ideas') return;
      var $toolbar = $('.bu-list-toolbar.bu-v2');
      if (!$toolbar.length) $toolbar = $('.bu-list-toolbar');
      if (!$toolbar.length){
        $toolbar = $('<div class="bu-list-toolbar bu-v2" style="display:none"></div>').appendTo($('.wrap').first());
      }
      var $btn = $toolbar.find('.bu-new-idea-btn');
      if (!$btn.length){
        $btn = $('<a class="bu-new-idea-btn" href="post-new.php?post_type=bu_idea">+ Neue Idee</a>').appendTo($toolbar);
      } else {
        $btn.text('+ Neue Idee');
      }
      var href = $btn.attr('href');
      var $tabs = $('.nav-tab-wrapper, .bu-level-tabs, .bu-daisy-tabs, .bu-tabs, .level-tabs, .tab-wrapper, .subsubsub').filter(':visible').first();
      if (!$tabs.length){
        var labels=['national','kanton','stadt','lokal']; $('body *:visible').each(function(){
          var $el=$(this), t=$el.text().toLowerCase(), c=0; for(var i=0;i<labels.length;i++){if(t.indexOf(labels[i])!==-1)c++;}
          if(c>=2 && $el.width()>200 && $el.height()<140){ $tabs=$el; return false; }
        });
      }
      if ($tabs && $tabs.length){
        var $lastA = $tabs.find('a:visible').last();
        var cls = ($lastA.attr('class')||'nav-tab').replace(/\bnav-tab-active\b/g,'');
        if ($tabs.is('ul')){
          var $li=$('<li class="bu-new-idea-pill-li"></li>').append($('<a/>',{ 'class': cls+' bu-new-idea-pill', href: href, text: '+ Neue Idee' }));
          $tabs.append($li);
        } else {
          $('<a/>',{ 'class': cls+' bu-new-idea-pill', href: href, text: '+ Neue Idee' }).appendTo($tabs);
        }
        $tabs.addClass('bu-has-new');
        $toolbar.remove();
      } else {
        var $cont=$('#bu-ideas-container'); if($cont.length) $toolbar.prependTo($cont);
      }
    }catch(e){}
  });
})(jQuery);
