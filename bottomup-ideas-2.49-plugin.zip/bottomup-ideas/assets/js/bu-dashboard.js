(function($){
  function parseData(){
    try { return JSON.parse($('#bu-ssr-data').text() || '[]'); } catch(e){ return []; }
  }
  function renderPaged(rows, page, perPage){ var start=(page-1)*perPage, end=start+perPage; return rows.slice(start,end); }
  function contains(val,q){ if(!q) return true; return (val||'').toString().toLowerCase().indexOf(q.toLowerCase())!==-1; }
  function matchFilter(row, f){
    if(f.id){
      var sid = (row.id==null? '' : String(row.id));
      if(sid.indexOf(String(f.id))===-1) return false;
    }
    if(!contains(row.title, f.title)) return false;
    if(!contains(row.author, f.author)) return false;
    if(f.date && (row.date||'').substring(0,10).indexOf(f.date)===-1) return false;
    if(f.sk){
      var sk = (row.sk_avg==null)?'':(row.sk_avg+'');
      if(sk.indexOf(f.sk)===-1) return false;
    }
    if(f.vote){
      var v=(row.yes|0)+'/'+(row.no|0);
      if(v.indexOf(f.vote)===-1) return false;
    }
    if(f.cat){
      var ok=false; (row.cats_all||[]).forEach(function(c){ if((c.name||'').toLowerCase().indexOf(f.cat.toLowerCase())!==-1) ok=true; });
      if(!ok) return false;
    }
    if(f.lvl){
      var ok2=false; (row.lvls_all||[]).forEach(function(l){ if((l.name||'').toLowerCase().indexOf(f.lvl.toLowerCase())!==-1) ok2=true; });
      if(!ok2) return false;
    }
    if(f.act){
      var ok3=false; (row.acts_all||[]).forEach(function(a){ if((a.name||'').toLowerCase().indexOf(f.act.toLowerCase())!==-1) ok3=true; });
      if(!ok3) return false;
    }
    return true;
  }

  // --- Custom modal helper (avoid native alert/prompt) ---
  function buModal(opts){
    opts = opts || {};
    return new Promise(function(resolve){
      var $ov = $('<div class="bu-modal-overlay" />');
      var $m  = $('<div class="bu-modal" role="dialog" aria-modal="true" />');
      var $head = $('<div class="bu-modal-head" />');
      var $title = $('<div class="bu-modal-title" />').text(opts.title || '');
      var $close = $('<button type="button" class="bu-modal-close" aria-label="Schließen">×</button>');
      $head.append($title).append($close);
      var $body = $('<div class="bu-modal-body" />');
      if (opts.body){
        if (typeof opts.body === 'string') $body.html(opts.body);
        else $body.append(opts.body);
      }
      if (typeof opts.render === 'function') opts.render($body);
      var $foot = $('<div class="bu-modal-foot" />');
      var buttons = Array.isArray(opts.buttons) ? opts.buttons : [{text:'OK', value:true, primary:true}];
      buttons.forEach(function(b){
        var $btn = $('<button type="button" class="button" />').text(b.text || 'OK');
        if (b.primary) $btn.addClass('button-primary');
        $btn.on('click', function(){
          if (typeof b.onClick === 'function'){
            var v = b.onClick({overlay:$ov, modal:$m, body:$body, close:close});
            if (v === false) return;
            close(v);
          } else {
            close(b.value);
          }
        });
        $foot.append($btn);
      });
      function close(val){ $ov.remove(); resolve(val); }
      $close.on('click', function(){ close(null); });
      $ov.on('click', function(e){ if (e.target === $ov[0]) close(null); });
      $m.append($head).append($body).append($foot);
      $ov.append($m);
      $('body').append($ov);
    });
  }
  function modalAlert(msg, title){
    var safe = $('<div>').text(msg || '').html();
    return buModal({
      title: title || 'Hinweis',
      body: '<p>' + safe + '</p>',
      buttons: [{text:'OK', value:true, primary:true}]
    });
  }
  function modalConfirm(msg, title, okText){
    var safe = $('<div>').text(msg || '').html();
    return buModal({
      title: title || 'Bestätigung',
      body: '<p>' + safe + '</p>',
      buttons: [
        {text:'Abbrechen', value:false},
        {text: (okText || 'OK'), value:true, primary:true}
      ]
    });
  }

  function buildBody(rows){
    var h='';
    rows.forEach(function(r){
      var date=(r.date||'').substring(0,10);
      var sk=(r.sk_avg===null)?'–':(parseFloat(r.sk_avg).toLocaleString('de-DE',{minimumFractionDigits:2,maximumFractionDigits:2}));
      var vote=(r.yes|0)+'/'+(r.no|0);
      var cats=(r.cats_all||[]).map(function(c){ return '<a class="bu-cat-link" href="'+BU_LIST.ideas_url+'&cat='+encodeURIComponent(c.slug)+'">'+$('<div>').text(c.name).html()+'</a>'; }).join(', ');
      var lvls=(r.lvls_all||[]).map(function(l){ return '<a class="bu-lvl-link" href="'+BU_LIST.ideas_url+'&level='+encodeURIComponent(l.slug)+'">'+$('<div>').text(l.name).html()+'</a>'; }).join(', ');
      var acts=(r.acts_all||[]).map(function(a){ return '<a class="bu-act-link" href="'+BU_LIST.ideas_url+'&act='+encodeURIComponent(a.slug)+'">'+$('<div>').text(a.name).html()+'</a>'; }).join(', ');
      var round = (r.round==null)?1:parseInt(r.round,10);
      var view=BU_LIST.view_base+'&post='+r.id;
      var edit=r.edit_link||('#');
      var printUrl=BU_LIST.view_base.replace('bottomup_view','bottomup_print')+'&post='+r.id;
      var tasksUrl=BU_LIST.view_base.replace('bottomup_view','bottomup_tasks_board')+'&idea='+r.id;
      var state=(r.state||'active');
      var isDone=(state==='done');
      var isArch=(String(r.archived||'')==='1');
      var stateIcon=isDone ? '<span class="dashicons dashicons-yes-alt bu-state-icon bu-state-done" title="Abgeschlossen"></span>'
                          : '<span class="dashicons dashicons-marker bu-state-icon bu-state-active" title="Offen"></span>';
      var archIcon=isArch ? '<span class="dashicons dashicons-archive bu-state-icon bu-arch-icon" title="Archiviert"></span>' : '';
      h+='<tr>'
        +'<td class="bu-id">'+ $('<div>').text(r.id||'').html() +'</td>'
        +'<td>'+ $('<div>').text(r.title||'').html() +'</td>'
        +'<td>'+ $('<div>').text(r.author||'').html() +'</td>'
        +'<td>'+ $('<div>').text(date).html() +'</td>'
        +'<td>'+ $('<div>').text(sk).html() +'</td>'
        +'<td>'+ $('<div>').text(vote).html() +'</td>'
        +'<td>'+ cats +'</td>'
        +'<td>'+ lvls +'</td>'
        +'<td>'+ acts +'</td>'
        +'<td><span class="bu-round-badge" title="Runde #'+round+'">'+round+'</span></td>'
        +'<td class="bu-actions"><span class="bu-row-actions" style="display:inline-flex;gap:10px;align-items:center;visibility:visible;opacity:1;">'+'<a href="'+view+'" title="Ansehen" aria-label="Ansehen" style="order:1;display:inline-flex;align-items:center;"><svg fill="#2271b1" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M12 5c-7 0-10 7-10 7s3 7 10 7 10-7 10-7-3-7-10-7zm0 12a5 5 0 1 1 0-10 5 5 0 0 1 0 10zm0-2.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z"/></svg></a>'+'<a href="'+edit+'" title="Bearbeiten" aria-label="Bearbeiten" style="order:2;display:inline-flex;align-items:center;"><svg fill="#dba617" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zm2.92 2.83H5v-.92l9.06-9.06.92.92L5.92 20.08zM20.71 7.04a1 1 0 0 0 0-1.41l-2.34-2.34a1 1 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg></a>'+'<a href="'+printUrl+'" title="Drucken" aria-label="Drucken" style="order:3;display:inline-flex;align-items:center;"><svg fill="#2e8b57" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M6 9V3h12v6H6zm10-2V5H8v2h8zM6 19v-4h12v4H6zm14-10a3 3 0 0 1 3 3v5h-3v4H4v-4H1v-5a3 3 0 0 1 3-3h16zm1 6v-3a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v3h2v-2h14v2h2z"/></svg></a>'
          +'<a href="'+tasksUrl+'" title="Tasks" aria-label="Tasks" style="order:4;display:inline-flex;align-items:center;"><span class="dashicons dashicons-clipboard" style="font-size:20px;line-height:20px;"></span></a>'+stateIcon+archIcon+(r.is_fav?'<a href="#" class="bu-fav-toggle" data-id="'+r.id+'" data-fav="1" title="Meine Favoriten" aria-label="Meine Favoriten" style="display:inline-flex;align-items:center;"><svg fill="#2e8b57" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87L18.18 22 12 18.56 5.82 22 7 14.14l-5-4.87 6.91-1.01L12 2z"/></svg></a>':'<a href="#" class="bu-fav-toggle" data-id="'+r.id+'" data-fav="0" title="Meine Favoriten" aria-label="Meine Favoriten" style="display:inline-flex;align-items:center;"><svg fill="#9aa0a6" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87L18.18 22 12 18.56 5.82 22 7 14.14l-5-4.87 6.91-1.01L12 2z"/></svg></a>')+'</span></td>'+'</tr>';
    });
    return h;
  }
  function sortRows(rows, key, dir){
    var m = dir==='desc' ? -1 : 1;
    return rows.slice().sort(function(a,b){
      var va, vb;
      if(key==='sk'){ va = (a.sk_avg==null? -Infinity : a.sk_avg); vb = (b.sk_avg==null? -Infinity : b.sk_avg); }
      else if(key==='vote'){ va=(a.yes|0)-(a.no|0); vb=(b.yes|0)-(b.no|0); }
      else if(key==='date'){ va = a.date||''; vb = b.date||''; }
      else if(key==='author'){ va = (a.author||'').toLowerCase(); vb = (b.author||'').toLowerCase(); }
      else if(key==='id'){ va = (a.id==null?0:parseInt(a.id,10)); vb=(b.id==null?0:parseInt(b.id,10)); }
      else if(key==='title'){ va = (a.title||'').toLowerCase(); vb = (b.title||'').toLowerCase(); }
      else if(key==='cat'){ va=(a.cats_all||[]).map(function(x){return (x.name||'').toLowerCase();}).join(','); vb=(b.cats_all||[]).map(function(x){return (x.name||'').toLowerCase();}).join(','); }
      else if(key==='lvl'){ va=(a.lvls_all||[]).map(function(x){return (x.name||'').toLowerCase();}).join(','); vb=(b.lvls_all||[]).map(function(x){return (x.name||'').toLowerCase();}).join(','); }
      else if(key==='act'){ va=(a.acts_all||[]).map(function(x){return (x.name||'').toLowerCase();}).join(','); vb=(b.acts_all||[]).map(function(x){return (x.name||'').toLowerCase();}).join(','); }
      else if(key==='round'){ va=(a.round==null?1:parseInt(a.round,10)); vb=(b.round==null?1:parseInt(b.round,10)); }
      if(va<vb) return -1*m; if(va>vb) return 1*m; return 0;
    });
  }
  function applyPagination($table, rows, perPage){
    var $pager = $('.bu-pager');
    var total = Math.max(1, Math.ceil(rows.length / perPage));
    var page = 1;
    function render(){
      var pageRows = renderPaged(rows, page, perPage);
      $table.find('tbody').html(buildBody(pageRows));
      var parts=[];
      parts.push('<span class="displaying-num">'+rows.length+' Einträge</span>');
      parts.push(' <span class="pagination-links">');
      parts.push('<a class="first-page button'+(page<=1?' disabled':'')+'">«</a>');
      parts.push('<a class="prev-page button'+(page<=1?' disabled':'')+'">‹</a>');
      parts.push('<span class="paging-input">'+page+' von <span class="total-pages">'+total+'</span></span>');
      parts.push('<a class="next-page button'+(page>=total?' disabled':'')+'">›</a>');
      parts.push('<a class="last-page button'+(page>=total?' disabled':'')+'">»</a>');
      parts.push('</span>');
      $pager.html(parts.join(''));
    }
    $pager.off('click').on('click','a',function(e){
      e.preventDefault();
      if($(this).hasClass('disabled')) return;
      var cls=$(this).attr('class');
      if(cls.indexOf('first-page')>-1) page=1;
      else if(cls.indexOf('prev-page')>-1) page=Math.max(1,page-1);
      else if(cls.indexOf('next-page')>-1) page=Math.min(total,page+1);
      else if(cls.indexOf('last-page')>-1) page=total;
      render();
    });
    render();
  }

  function gatherFilters(){
    return {
      id:     $('.bu-filter[data-name="id"]').val()     || '',
      title:  $('.bu-filter[data-name="title"]').val()  || '',
      author: $('.bu-filter[data-name="author"]').val() || '',
      date:   $('.bu-filter[data-name="date"]').val()   || '',
      sk:     $('.bu-filter[data-name="sk"]').val()     || '',
      vote:   $('.bu-filter[data-name="vote"]').val()   || '',
      cat:    $('.bu-filter[data-name="cat"]').val()    || '',
      lvl:    $('.bu-filter[data-name="lvl"]').val()    || '',
      act:    $('.bu-filter[data-name="act"]').val()    || ''
    };
  }

  $(function(){
    // data-confirm: native confirm ersetzen (Link oder Formular-Button)
    $(document).on('click', '[data-confirm]', function(e){
      var msg = $(this).attr('data-confirm') || '';
      if(!msg) return;
      e.preventDefault();
      var el = this;
      modalConfirm(msg, 'Bestätigung', 'OK').then(function(ok){
        if(!ok) return;
        var $form = $(el).closest('form');
        if($form.length && (el.tagName||'').toLowerCase() !== 'a'){
          try { $form[0].submit(); } catch(err) {}
          return;
        }
        var href = $(el).attr('href');
        if(href) window.location.href = href;
      });
    });

    // Favoriten toggle
    $(document).on('click', '.bu-fav-toggle', function(e){
      e.preventDefault();
      var $a = $(this);
      var pid = parseInt($a.data('id'), 10);
      if(!pid) return;
      $.post(BU_LIST.ajax_url, {
        action: 'bu_toggle_favorite',
        post_id: pid,
        nonce: ((BU_LIST.nonces && BU_LIST.nonces.favorite) ? BU_LIST.nonces.favorite : BU_LIST.fav_nonce),
        _ajax_nonce: ((BU_LIST.nonces && BU_LIST.nonces.favorite) ? BU_LIST.nonces.favorite : BU_LIST.fav_nonce)
      }).done(function(resp){
        if(resp && resp.success && resp.data){
          var on = !!resp.data.is_fav;
          $a.attr('data-fav', on ? '1' : '0');
          $a.html(on ? '<svg fill="#2e8b57" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87L18.18 22 12 18.56 5.82 22 7 14.14l-5-4.87 6.91-1.01L12 2z"/></svg>' : '<svg fill="#9aa0a6" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87L18.18 22 12 18.56 5.82 22 7 14.14l-5-4.87 6.91-1.01L12 2z"/></svg>');

	          // Keep client-side pagination data in sync (otherwise the count at the bottom stays stale)
	          // and the star state may jump back on the next refresh.
	          try {
	            if (window.BU_IDEAS_ROWS && Array.isArray(window.BU_IDEAS_ROWS)) {
	              for (var i = 0; i < window.BU_IDEAS_ROWS.length; i++) {
	                var rid = parseInt(window.BU_IDEAS_ROWS[i].id, 10);
	                if (rid === pid) { window.BU_IDEAS_ROWS[i].is_fav = on; break; }
	              }
	
	              var sp = new URLSearchParams(window.location.search || '');
	              var onFavList = (sp.get('fav') === '1');
	              if (!on && onFavList) {
	                // Remove from dataset and refresh table so counts/pagination update immediately.
	                for (var j = window.BU_IDEAS_ROWS.length - 1; j >= 0; j--) {
	                  var rid2 = parseInt(window.BU_IDEAS_ROWS[j].id, 10);
	                  if (rid2 === pid) { window.BU_IDEAS_ROWS.splice(j, 1); }
	                }
	                if (typeof window.BU_IDEAS_REFRESH === 'function') {
	                  window.BU_IDEAS_REFRESH();
	                  return;
	                }
	              }
	            }
	          } catch (e) {}

	          // Fallback for non-ideas pages: remove the row from the DOM when favorites filter is active.
	          if(!on && ((window.location.search||'').indexOf('fav=1')>-1)){
	            $a.closest('tr').fadeOut(150, function(){ $(this).remove(); });
	          }
        }
      }).fail(function(xhr){
        if(window.console) console.warn('Favorite toggle failed', xhr);
        modalAlert('Favorit konnte nicht gespeichert werden.');
      });
    });

    // Reset
    $('#bu-reset').on('click', function(){
      if (typeof BU_LIST !== 'undefined' && BU_LIST.ideas_url){ window.location = BU_LIST.ideas_url; }
    });

    // CSV: sichere URL mit page=bottomup_export + list=1 + Filterparam
    $('#bu-export-top').on('click', function(e){
      var base = (BU_LIST && BU_LIST.export_url) ? BU_LIST.export_url : (BU_LIST.ideas_url || window.location.href);
      try { var u = new URL(base); } catch(err) { var u = new URL(base, window.location.origin); }
      
      u.searchParams.set('list','1');
      var f = gatherFilters();
      ['id','title','author','date','sk','vote','cat','lvl','act'].forEach(function(k){
        if(f[k]) u.searchParams.set('flt_'+k, f[k]);
      });
      var url = new URL(window.location.href);
      var level = url.searchParams.get('level')||'';
      var cat   = url.searchParams.get('cat')||'';
      var act   = url.searchParams.get('act')||'';
      var fav   = url.searchParams.get('fav')||'';
      var arch  = url.searchParams.get('arch')||'';
      if(level) u.searchParams.set('level', level);
      if(cat)   u.searchParams.set('cat', cat);
      if(act)   u.searchParams.set('act', act);
      if(fav)   u.searchParams.set('fav', fav);
      if(arch)  u.searchParams.set('arch', arch);
      $(this).attr('href', u.toString());
    });

    if(typeof BU_LIST!=='undefined' && BU_LIST.where==='bottomup_ideas'){
      var rows = parseData();
      var $wrap = $('#bu-ideas-container');
      var $table = $wrap.find('table.bu-table');
      var perPage = parseInt($('#bu-per-page').val()||'10',10);
      var filters = {id:'',title:'',author:'',date:'',sk:'',vote:'',cat:'',lvl:'',act:''};
      var sortedKey='', sortedDir='asc';

      function refresh(){
        var filtered = rows.filter(function(r){ return matchFilter(r, filters); });
        if(sortedKey){
          filtered = sortRows(filtered, sortedKey, sortedDir);
          $table.find('th.sortable').removeClass('sorted-asc sorted-desc');
          $table.find('th.sortable[data-key="'+sortedKey+'"]').addClass(sortedDir==='asc'?'sorted-asc':'sorted-desc');
        }
        applyPagination($table, filtered, perPage);
      }

      // Expose list state so the favorites toggle can update counts/pagination immediately
      // (important when the list is filtered to favorites).
      window.BU_IDEAS_ROWS = rows;
      window.BU_IDEAS_REFRESH = refresh;

      $wrap.on('input', '.bu-filter', function(){ filters[$(this).data('name')] = $(this).val(); 
      // expose dataset + refresh for favorite-toggle so pagination counters stay in sync
      window.BU_IDEAS_ROWS = rows;
      window.BU_IDEAS_REFRESH = function(){ refresh(); };
refresh(); });
      $('#bu-per-page').on('change', function(){ perPage = parseInt($(this).val()||'10',10); refresh(); });
      $table.on('click','th.sortable', function(){
        var k = $(this).data('key');
        if(sortedKey===k){ sortedDir = (sortedDir==='asc')?'desc':'asc'; } else { sortedKey=k; sortedDir='asc'; }
        refresh();
      });

      refresh();
    }
  
  // --- Tab toggle behavior (active levels / favorites) ---
  $(document).on('click', '.bu-tab a', function(e){
    try {
      var $li = $(this).closest('.bu-tab');
      if(!$li.hasClass('bu-tab--active')) return; // only toggle if clicking active tab
      var href = $(this).attr('href') || '';
      if(!href) return;
      var current = new URL(window.location.href);
      var target = new URL(href, window.location.origin);

      // If user clicks the currently active "Active levels" or "Favorites" tab again,
      // go back to the unfiltered "All levels" view while keeping other params.
      var isActiveTab = target.searchParams.get('level') === 'active';
      var isFavTab = target.searchParams.get('fav') === '1';

      if(isActiveTab || isFavTab){
        e.preventDefault();
        var next = new URL(window.location.href);
        next.searchParams.delete('level');
        next.searchParams.delete('fav');
        // keep tab param if present (so same dashboard stays selected)
        window.location.href = next.toString();
      }
    } catch(err){
      // fail open
    }
  });

});
})(jQuery);