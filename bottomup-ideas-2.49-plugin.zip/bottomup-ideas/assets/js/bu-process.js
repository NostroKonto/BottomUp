(function($){
  // Modal helper (uses existing admin.css .bu-modal styles)
  function buModal(opts){
    opts = opts || {};
    return new Promise(function(resolve){
      var $ov = $('<div class="bu-modal-overlay" />');
      var $m  = $('<div class="bu-modal" role="dialog" aria-modal="true" />');
      var $head = $('<div class="bu-modal-head" />');
      var $title = $('<div class="bu-modal-title" />').text(opts.title || '');
      var $close = $('<button type="button" class="bu-modal-close" aria-label="Schließen">×</button>');
      $head.append($title).append($close);
      var $body = $('<div class="bu-modal-body" />');
      if (opts.body){
        if (typeof opts.body === 'string') $body.html(opts.body);
        else $body.append(opts.body);
      }
      if (typeof opts.render === 'function') opts.render($body);
      var $foot = $('<div class="bu-modal-foot" />');
      var buttons = Array.isArray(opts.buttons) ? opts.buttons : [{text:'OK', value:true, primary:true}];
      buttons.forEach(function(b){
        var $btn = $('<button type="button" class="button" />').text(b.text || 'OK');
        if (b.primary) $btn.addClass('button-primary');
        $btn.on('click', function(){ close(b.value); });
        $foot.append($btn);
      });
      function close(val){ $ov.remove(); resolve(val); }
      $close.on('click', function(){ close(null); });
      $ov.on('click', function(e){ if (e.target === $ov[0]) close(null); });
      $m.append($head).append($body).append($foot);
      $ov.append($m);
      $('body').append($ov);
    });
  }

  function escHtml(s){ return $('<div>').text(s == null ? '' : String(s)).html(); }

  function openStep(stepId){
    var steps = (window.BU_PROCESS && window.BU_PROCESS.steps) ? window.BU_PROCESS.steps : {};
    var s = steps[stepId];
    if (!s) return;

    var body = ''
      + '<div class="bu-proc-modal">'
      +   '<h3>' + escHtml(s.title) + '</h3>'
      +   '<dl class="bu-proc-meta">'
      +     '<dt>Was passiert?</dt><dd>' + escHtml(s.what) + '</dd>'
      +     '<dt>Wer?</dt><dd>' + escHtml(s.who) + '</dd>'
      +     '<dt>Im System</dt><dd>' + escHtml(s.system) + '</dd>'
      +     '<dt>Regeln</dt><dd>' + escHtml(s.rules) + '</dd>'
      +   '</dl>';

    if (s.link && s.link_label){
      body += '<div class="bu-proc-actions">'
            +  '<a class="button button-primary" href="' + escHtml(s.link) + '">' + escHtml(s.link_label) + '</a>'
            +  '</div>';
    }
    body += '</div>';

    buModal({
      title: 'Prozessschritt',
      body: body,
      buttons: [{text:'Schließen', value:true, primary:true}]
    });
  }

  function bindTriggers(){
    $(document).on('click', '.bu-proc-trigger', function(e){
      e.preventDefault();
      var id = $(this).data('step');
      if (id) openStep(id);
    });

    // keyboard accessibility for non-button triggers
    $(document).on('keydown', '.bu-proc-trigger', function(e){
      if (e.key === 'Enter' || e.key === ' '){
        e.preventDefault();
        $(this).trigger('click');
      }
    });
  }

  $(function(){
    if (typeof window.BU_PROCESS === 'undefined') return;
    bindTriggers();
  });
})(jQuery);
