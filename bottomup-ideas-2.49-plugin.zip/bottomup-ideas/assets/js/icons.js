(function($){
  function iconifyLink($a, icon, sr){
    if(!$a.length) return;
    if($a.attr('data-bui-iconified')==='1') return;
    $a.attr('data-bui-iconified','1')
      .addClass('bui-icon-link')
      .empty()
      .append($('<span/>',{class:'dashicons '+icon}))
      .append($('<span/>',{class:'screen-reader-text',text:sr}));
  }
  function ensurePrintLink($row){
    var id = 0;
    $row.find('a[href*="post="], a[href*="post_id="], a[href*="post.php?action=edit&post="]').each(function(){
      var m = this.href.match(/[?&](?:post|post_id)=(\d+)/);
      if(m){ id = parseInt(m[1],10); return false; }
    });
    if(!id) return;
    var exists = $row.find('a[href*="admin.php?page=bottomup_print&post='+id+'"]').length>0;
    if(!exists){
      var base = (window.ajaxurl||'').replace('admin-ajax.php','admin.php');
      if(!base){ base = (document.location.origin + '/wp-admin/admin.php'); }
      var url = base + '?page=bottomup_print&post='+id;
      var $anchorAfter = $row.find('a[href*="admin.php?page=bottomup_view&post='+id+'"]').first();
      var $container = $row.find('.row-actions').first();
      var $a = $('<a/>',{href:url, text:'Drucken', style:'margin-left:8px'});
      if($anchorAfter.length){ $anchorAfter.after($a); }
      else if($container.length){ $container.append($a); }
      else { $row.find('a').first().after($a); }
      iconifyLink($a,'dashicons-media-document','Drucken');
    }
  }
  function applyIcons(){
    var params = new URLSearchParams(window.location.search);
    var onCustom = (params.get('page')==='bottomup_ideas');
    var onNative = (params.get('post_type')==='bu_idea' && location.pathname.indexOf('/edit.php')!==-1);
    if(onCustom || onNative){
      var $rows = $('table.widefat tbody tr, table.wp-list-table tbody tr');
      $rows.each(function(){
        var $row=$(this);
        $row.find('a[href*="admin.php?page=bottomup_view&post="]').each(function(){
          iconifyLink($(this),'dashicons-visibility','Ansehen');
        });
        $row.find('a[href*="post.php"][href*="action=edit"], a[href*="post.php?action=edit"]').each(function(){
          iconifyLink($(this),'dashicons-edit','Bearbeiten');
        });
        $row.find('a[href*="admin.php?page=bottomup_print&post="]').each(function(){
          iconifyLink($(this),'dashicons-media-document','Drucken');
        });
        ensurePrintLink($row);
      });
    }
  }
  $(applyIcons);
  $(document).ajaxComplete(function(){ applyIcons(); });
})(jQuery);
