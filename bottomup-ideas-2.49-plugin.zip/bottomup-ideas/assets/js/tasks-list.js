(function($){
  $(function(){
    var $container = $('#bu-tasks-container');
    if(!$container.length) return;

    var $table = $container.find('table');
    var $rows = $table.find('tbody tr[data-id]');
    if(!$rows.length) return;

    var allowed = [10,20,50];
    var per = parseInt(localStorage.getItem('bu_tasks_per_page') || '10', 10);
    if(allowed.indexOf(per) === -1) per = 10;
    var page = 1;

    $('#bu-tasks-per-page').val(String(per));

    function gatherFilters(){
      return {
        id: ($('.bu-task-filter[data-name="id"]').val() || '').trim(),
        title: ($('.bu-task-filter[data-name="title"]').val() || '').trim().toLowerCase()
      };
    }

    function renderPager(total, pages){
      var $p = $('.bu-tasks-pager');
      if(!$p.length) return;

      if(total === 0){
        $p.html('<span class="displaying-num">0 Einträge</span>');
        return;
      }

      var disableFirst = (page <= 1) ? ' disabled' : '';
      var disableLast  = (page >= pages) ? ' disabled' : '';

      var html = '';
      html += '<span class="displaying-num">'+total+' Einträge</span> ';
      html += '<span class="pagination-links">';
      html += '<a class="first-page button'+disableFirst+'" href="#" data-page="1">«</a> ';
      html += '<a class="prev-page button'+disableFirst+'" href="#" data-page="'+Math.max(1,page-1)+'">‹</a> ';
      html += '<span class="paging-input">'+page+' von <span class="total-pages">'+pages+'</span></span> ';
      html += '<a class="next-page button'+disableLast+'" href="#" data-page="'+Math.min(pages,page+1)+'">›</a> ';
      html += '<a class="last-page button'+disableLast+'" href="#" data-page="'+pages+'">»</a>';
      html += '</span>';

      $p.html(html);
    }

    function apply(){
      var f = gatherFilters();
      var filtered = $rows.filter(function(){
        var $r = $(this);
        var id = String($r.data('id')||'');
        var title = String($r.data('title')||'');
        if(f.id && id.indexOf(f.id) !== 0) return false;
        if(f.title && title.indexOf(f.title) === -1) return false;
        return true;
      });

      $rows.hide();

      var total = filtered.length;
      var pages = Math.max(1, Math.ceil(total / per));
      if(page > pages) page = pages;

      var start = (page-1) * per;
      filtered.slice(start, start + per).show();

      renderPager(total, pages);
    }

    $(document).on('click', '.bu-tasks-pager a.button', function(e){
      e.preventDefault();
      if($(this).hasClass('disabled')) return;
      page = parseInt($(this).data('page') || '1', 10);
      apply();
    });

    $('#bu-tasks-per-page').on('change', function(){
      per = parseInt($(this).val() || '10', 10);
      if(allowed.indexOf(per) === -1) per = 10;
      localStorage.setItem('bu_tasks_per_page', String(per));
      page = 1;
      apply();
    });

    $('.bu-task-filter').on('input', function(){
      page = 1;
      apply();
    });

    $('#bu-tasks-reset').on('click', function(){
      if (window.BU_TASKS_URL){ window.location = window.BU_TASKS_URL; return; }
      $('.bu-task-filter').val('');
      page = 1;
      apply();
    });

    apply();
  });
})(jQuery);
