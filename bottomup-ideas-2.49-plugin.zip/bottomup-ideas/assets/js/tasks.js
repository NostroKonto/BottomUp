(function($){
  const READONLY = (typeof BU_TASKS !== 'undefined' && String(BU_TASKS.readonly||'0') === '1');

  // --- Custom modal helper (avoid native alert/prompt) ---
  function buModal(opts){
    opts = opts || {};
    return new Promise(function(resolve){
      var $ov = $('<div class="bu-modal-overlay" />');
      var $m  = $('<div class="bu-modal" role="dialog" aria-modal="true" />');
      var $head = $('<div class="bu-modal-head" />');
      var $title = $('<div class="bu-modal-title" />').text(opts.title || '');
      var $close = $('<button type="button" class="bu-modal-close" aria-label="Schließen">×</button>');
      $head.append($title).append($close);
      var $body = $('<div class="bu-modal-body" />');
      if (opts.body){
        if (typeof opts.body === 'string') $body.html(opts.body);
        else $body.append(opts.body);
      }
      if (typeof opts.render === 'function') opts.render($body);
      var $foot = $('<div class="bu-modal-foot" />');
      var buttons = Array.isArray(opts.buttons) ? opts.buttons : [{text:'OK', value:true, primary:true}];
      buttons.forEach(function(b){
        var $btn = $('<button type="button" class="button" />').text(b.text || 'OK');
        if (b.primary) $btn.addClass('button-primary');
        $btn.on('click', function(){
          if (typeof b.onClick === 'function'){
            var v = b.onClick({overlay:$ov, modal:$m, body:$body, close:close});
            if (v === false) return; // validation failed
            close(v);
          } else {
            close(b.value);
          }
        });
        $foot.append($btn);
      });
      function close(val){ $ov.remove(); resolve(val); }
      $close.on('click', function(){ close(null); });
      $ov.on('click', function(e){ if (e.target === $ov[0]) close(null); });
      $m.append($head).append($body).append($foot);
      $ov.append($m);
      $('body').append($ov);
    });
  }

  function modalAlert(msg, title){
    var safe = $('<div>').text(msg || '').html();
    return buModal({
      title: title || 'Hinweis',
      body: '<p>' + safe + '</p>',
      buttons: [{text:'OK', value:true, primary:true}]
    });
  }

  function modalPrompt(opts){
    opts = opts || {};
    return buModal({
      title: opts.title || 'Eingabe',
      render: function($body){
        if (opts.label){
          var $p = $('<p style="margin:0 0 8px 0;"><strong></strong></p>');
          $p.find('strong').text(opts.label);
          $body.append($p);
        }
        var $in = $('<input type="text" id="bu_modal_input" style="width:100%" />');
        $in.val(opts.defaultValue || '');
        $body.append($in);
        window.setTimeout(function(){ try{ $in.trigger('focus'); $in[0].select(); }catch(e){} }, 50);
      },
      buttons: [
        {text:'Abbrechen', value:null},
        {text:'OK', primary:true, onClick: function(ctx){
          var v = String(ctx.body.find('#bu_modal_input').val() || '').trim();
          if (!v){
            ctx.body.find('#bu_modal_input').trigger('focus');
            return false;
          }
          return v;
        }}
      ]
    });
  }



  function reorderPayload($board){
    const payload = {todo:[], doing:[], done:[]};
    $board.find('.bu-col-body').each(function(){
      const st = $(this).data('status');
      $(this).find('.bu-card').each(function(){ payload[st].push($(this).data('task')); });
    });
    return payload;
  }

  function postReorder($board){
    if (READONLY) return;
    const payload = reorderPayload($board);
    $.post(BU_TASKS.ajax_url, {action:'bu_task_reorder', nonce:((BU_TASKS.nonces && BU_TASKS.nonces.ajax) ? BU_TASKS.nonces.ajax : BU_TASKS.nonce), idea: (BU_TASKS.idea||0), payload: JSON.stringify(payload)}, function(){}, 'json');
  }

  $(document).on('click', '.bu-task-open', function(){
    if (READONLY){
      const tid = $(this).data('task');
      $('.bu-task-panel[data-task="'+tid+'"]').toggle();
      return;
    }
    const tid = $(this).data('task');
    const $panel = $('.bu-task-panel[data-task="'+tid+'"]');
    const $card = $('.bu-card[data-task="'+tid+'"]');
    const willShow = $panel.is(':hidden');
    $panel.toggle();
    $card.attr('draggable', willShow ? 'false' : 'true');
  });

$(document).on('click', '.bu-task-cancel', function(){
    if (READONLY){
      const tid = $(this).data('task');
      $('.bu-task-panel[data-task="'+tid+'"]').hide();
      return;
    }
    const tid = $(this).data('task');
    const $panel = $('.bu-task-panel[data-task="'+tid+'"]');
    $panel.hide();
    $('.bu-card[data-task="'+tid+'"]').attr('draggable','true');
  });

$(document).on('click', '.bu-task-save', function(){
    if (READONLY) return;
    const tid = $(this).data('task');
    const $panel = $('.bu-task-panel[data-task="'+tid+'"]');
    const fields = $panel.find('.bu-task-field');
    const requests = [];
    fields.each(function(){
      const field = $(this).data('field');
      const val = $(this).val();
      requests.push($.post(BU_TASKS.ajax_url, {action:'bu_task_update', nonce:((BU_TASKS.nonces && BU_TASKS.nonces.ajax) ? BU_TASKS.nonces.ajax : BU_TASKS.nonce), task:tid, field:field, value:val}, null, 'json'));
    });
    $.when.apply($, requests).done(function(){
      location.reload();
    });
  });

  $(document).on('click', '.bu-task-add', function(){
    if (READONLY) return;
    const $board = $('.bu-board');
    const iid = $board.data('idea');
    const status = $(this).data('status');
    modalPrompt({title:'Task erstellen', label:'Task Titel', defaultValue:'Neuer Task'}).then(function(title){
      if (!title) return;
      $.post(BU_TASKS.ajax_url, {action:'bu_task_create', nonce:((BU_TASKS.nonces && BU_TASKS.nonces.ajax) ? BU_TASKS.nonces.ajax : BU_TASKS.nonce), idea:iid, status:status, title:title}, function(res){
        if (res && res.success){ location.reload(); }
        else modalAlert((res && res.data && res.data.message) ? res.data.message : 'Fehler', 'Fehler');
      }, 'json');
    });
  });

  $(document).on('click', '.bu-task-add-comment', function(){
    if (READONLY) return;
    const tid = $(this).data('task');
    const $panel = $('.bu-task-panel[data-task="'+tid+'"]');
    const $txt = $panel.find('.bu-task-comment-text');
    const text = $txt.val();
    if (!text.trim()) return;
    $.post(BU_TASKS.ajax_url, {action:'bu_task_add_comment', nonce:((BU_TASKS.nonces && BU_TASKS.nonces.ajax) ? BU_TASKS.nonces.ajax : BU_TASKS.nonce), task:tid, text:text}, function(res){
      if (res && res.success){ location.reload(); }
    }, 'json');
  });

  // Drag & Drop
  let dragTaskId = null;
  $(document).on('dragstart', '.bu-card-top, .bu-card-title', function(e){
    if (READONLY) return false;
    dragTaskId = $(this).data('task');
    $(this).closest('.bu-card').addClass('dragging');
    e.originalEvent.dataTransfer.setData('text/plain', String(dragTaskId));
  });
  $(document).on('dragend', '.bu-card-top, .bu-card-title', function(){
    $(this).closest('.bu-card').removeClass('dragging');
    dragTaskId = null;
    $('.bu-col-body').removeClass('dragover');
  });

  $(document).on('dragover', '.bu-col-body', function(e){
    if (READONLY) return false;
    if (READONLY) return false;
    e.preventDefault();
    $(this).addClass('dragover');
  });
  $(document).on('dragleave', '.bu-col-body', function(){
    $(this).removeClass('dragover');
  });

  $(document).on('drop', '.bu-col-body', function(e){
    if (READONLY) return false;
    e.preventDefault();
    const tid = Number(e.originalEvent.dataTransfer.getData('text/plain'));
    if (!tid) return;
    const $card = $('.bu-card[data-task="'+tid+'"]');
    const toStatus = String($(this).data('status')||'');
    $(this).append($card);
    if (toStatus){ $card.attr('data-status', toStatus).data('status', toStatus); }
    $(this).removeClass('dragover');
    postReorder($('.bu-board'));
  });


  $(function(){
    if (!READONLY) return;
    $('.bu-board-wrap').addClass('bu-readonly');
    // Kein Drag&Drop
    $('.bu-card-title, .bu-card-top').attr('draggable','false');
    // UI auf Anzeige setzen
    $('.bu-task-add').remove();
    $('.bu-task-save').remove();
    $('.bu-task-add-comment').remove();
    $('.bu-task-comment-text').remove();
    $('.bu-task-open').text('Ansehen');
    // Felder sperren (readonly/disabled) aber Text bleibt kopierbar
    $('.bu-task-field').each(function(){
      const tag = (this.tagName||'').toLowerCase();
      if (tag === 'select') $(this).prop('disabled', true);
      else $(this).prop('readonly', true);
    });
  });

})(jQuery);

