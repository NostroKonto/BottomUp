
(function($){
  function getParam(name){
    var p = new URLSearchParams(window.location.search||''); return p.get(name);
  }
  function setParam(url, key, val){
    try{ var u = new URL(url, window.location.origin); u.searchParams.set(key, val); return u.toString(); }catch(e){ return url; }
  }
  function scrollToContent(){
    var el = document.querySelector('#bu-print-root, .wrap h1, .wrap h2, .bu-print, .entry-title, .postbox');
    if(el && el.scrollIntoView){ el.scrollIntoView({behavior:'auto', block:'start'}); window.scrollBy(0, -8); }
  }
  $(function(){
    var params = new URLSearchParams(window.location.search||''); if(params.get('page')!=='bottomup_print') return;

    // Ensure correct post id based on last clicked value from list (if mismatch)
    var qPost = getParam('post');
    var last = null; try{ last = localStorage.getItem('bu_last_print_id'); }catch(e){}
    if(last && (!qPost || qPost !== last)){
      var tried = sessionStorage.getItem('bu_tried_sync')==='1';
      if(!tried){
        sessionStorage.setItem('bu_tried_sync','1');
        window.location.replace(setParam(window.location.href, 'post', last));
        return;
      }
    }
    sessionStorage.removeItem('bu_tried_sync');

    // ensure Back button present in case server toolbar is hidden
    if(!document.querySelector('.bu-print-toolbar')){
      var back = (function(){ try{ return new URL('admin.php?page=bottomup_ideas', window.location.origin).toString(); }catch(e){ return 'admin.php?page=bottomup_ideas'; } })();
      var bar = document.createElement('div');
      bar.className = 'bu-print-toolbar';
      bar.style.cssText = 'position:sticky;top:0;z-index:1000;background:#fff;padding:8px 0;margin:0 0 8px 0;border-bottom:1px solid #ddd;';
      bar.innerHTML = '<a class="button" href="'+back+'">&larr; Zurück zur Liste</a>';
      var wrap = document.querySelector('.wrap') || document.body;
      wrap.insertBefore(bar, wrap.firstChild);
    }

    // Snap into place (avoid empty top area)
    scrollToContent();
    setTimeout(scrollToContent, 150);
  });
})(jQuery);
