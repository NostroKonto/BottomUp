
(function($){
  function unlockScroll(){
    try{
      document.documentElement.style.overflow='';
      document.body.style.overflow='';
      document.documentElement.style.position='';
      document.body.style.position='';
      document.documentElement.style.height='';
      document.body.style.height='';
      document.body.classList.remove('modal-open','is-locked');
      document.documentElement.classList.remove('modal-open','is-locked');
    }catch(e){}
  }
  function triggerDownloadBlob(blob, filename){
    var url=URL.createObjectURL(blob), a=document.createElement('a');
    a.href=url; a.download=filename||('ideen-'+new Date().toISOString().slice(0,10)+'.csv');
    document.body.appendChild(a); a.click();
    setTimeout(function(){ URL.revokeObjectURL(url); document.body.removeChild(a); }, 300);
  }
  function pickFilename(res){
    try{
      var cd = res.headers.get('Content-Disposition') || res.headers.get('content-disposition');
      if(cd){
        var m = cd.match(/filename\*=UTF-8''([^;]+)|filename="?([^\";]+)"?/i);
        if(m){
          var f = decodeURIComponent(m[1]||m[2]||'').trim();
          if(f) return f;
        }
      }
    }catch(e){}
    return 'ideen-export.csv';
  }
  function fetchDownload(href, scrollY){
    return fetch(href, { credentials:'same-origin', cache:'no-store' })
      .then(function(res){ if(!res.ok) throw new Error('HTTP '+res.status); var fname=pickFilename(res); return res.blob().then(function(b){return{blob:b, fname:fname};}); })
      .then(function(pkg){ unlockScroll(); window.scrollTo(0, scrollY); triggerDownloadBlob(pkg.blob, pkg.fname); })
      .catch(function(){ unlockScroll(); window.scrollTo(0, scrollY); // fallback: iframe
        try{
          var ifr = document.createElement('iframe'); ifr.style.display='none'; ifr.src = href; document.body.appendChild(ifr);
          setTimeout(function(){ try{ document.body.removeChild(ifr);}catch(e){} }, 5000);
        }catch(e){ window.open(href,'_blank'); }
      });
  }
  function onClick(e){
    var el=e.target.closest('a'); if(!el) return;
    var href = el.getAttribute('href'); if(!href) return;
    var t = href.toLowerCase();
    if(t.indexOf('csv')===-1 && t.indexOf('export')===-1) return;
    e.preventDefault(); e.stopPropagation();
    var y = window.pageYOffset || document.documentElement.scrollTop || 0;
    fetchDownload(href, y);
  }
  function onSubmit(e){
    var form = e.target; if(!form || form.tagName!=='FORM') return;
    var action = (form.getAttribute('action')||'').toLowerCase();
    var hasCsvField = form.querySelector('[name*="csv"], [name="export"][value*="csv"], [value*="csv"]');
    if(action.indexOf('csv')===-1 && !hasCsvField) return;
    e.preventDefault(); e.stopPropagation();
    var y = window.pageYOffset || document.documentElement.scrollTop || 0;
    var fd = new FormData(form);
    var url = action || window.location.href;
    fetch(url, { method:'POST', credentials:'same-origin', body:fd })
      .then(function(res){ if(!res.ok) throw new Error('HTTP '+res.status); var fname=pickFilename(res); return res.blob().then(function(b){return{blob:b,fname:fname};}); })
      .then(function(pkg){ unlockScroll(); window.scrollTo(0,y); triggerDownloadBlob(pkg.blob,pkg.fname); })
      .catch(function(){ unlockScroll(); window.scrollTo(0,y); });
  }
  $(function(){
    var params = new URLSearchParams(window.location.search||''); if(params.get('page')!=='bottomup_ideas') return;
    unlockScroll();
    document.addEventListener('click', onClick, { capture:true });
    document.addEventListener('submit', onSubmit, { capture:true });
  });
})(jQuery);
